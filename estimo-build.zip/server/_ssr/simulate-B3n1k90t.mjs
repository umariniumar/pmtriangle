import { n as __toESM } from "../_runtime.mjs";
import { c as performance_default } from "../_libs/h3+rou3+srvx+unenv.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as EstimoLogo } from "./client-DeQjJImR.mjs";
import { n as getLogoAssetUrl, t as getAppUrl } from "./app-url-CLRlHFQi.mjs";
import { g as require_react_dom, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Share2, d as Clock, f as ClipboardList, h as ArrowLeft, i as Sparkles, l as ListChecks, n as Trash2, o as RotateCcw, p as CalendarRange, s as Plus, t as Wallet, u as Copy } from "../_libs/lucide-react.mjs";
import { a as trackShareCardDownloaded, c as trackSimulationStarted, i as trackShareActionFailed, l as trackSummaryCopied, o as trackSimulationAbandoned, s as trackSimulationCompleted, t as ThemeToggle } from "./theme-toggle-CLTwLtfM.mjs";
import { t as toBlob } from "../_libs/html-to-image.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/simulate-B3n1k90t.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom());
/** Lacak pengguna yang meninggalkan /simulate tanpa menyelesaikan simulasi. */
function useSimulationAbandonTracking(simulationCompletedRef) {
	const abandonTrackedRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		abandonTrackedRef.current = false;
		const maybeTrackAbandon = () => {
			if (simulationCompletedRef.current || abandonTrackedRef.current) return;
			abandonTrackedRef.current = true;
			trackSimulationAbandoned();
		};
		window.addEventListener("pagehide", maybeTrackAbandon);
		return () => {
			window.removeEventListener("pagehide", maybeTrackAbandon);
			maybeTrackAbandon();
		};
	}, [simulationCompletedRef]);
}
var COST_ATTENTION_THRESHOLD = 1e7;
var SCALE_LABELS = {
	ringan: "Ringan",
	menengah: "Menengah",
	besar: "Besar",
	sangat_besar: "Sangat Besar"
};
var SCALE_CHIP_CLASSES = {
	ringan: "bg-success/12 text-success",
	menengah: "bg-primary/12 text-primary",
	besar: "bg-warning/15 text-warning-foreground",
	sangat_besar: "bg-destructive/12 text-destructive"
};
function classifyProjectScale(totalHours) {
	if (totalHours <= 8) return "ringan";
	if (totalHours <= 40) return "menengah";
	if (totalHours <= 120) return "besar";
	return "sangat_besar";
}
function pickRecommendation(scale, workingDays) {
	if (scale === "ringan") return "Masih realistis untuk dikerjakan oleh satu freelancer.";
	if (scale === "menengah") {
		if (workingDays <= 5) return "Cocok dikerjakan sendiri jika jadwal cukup longgar.";
		return "Usahakan selesai per tahap agar progress mudah dipantau.";
	}
	if (scale === "besar") return "Pertimbangkan membagi pekerjaan menjadi beberapa tahap.";
	return "Proyek sebaiknya dikerjakan lebih dari satu orang.";
}
function pickWatchOut(scale, bufferHours, totalCost) {
	if (bufferHours >= 8) return `Tambahkan sekitar ${bufferHours} jam cadangan di luar estimasi utama.`;
	if (totalCost >= COST_ATTENTION_THRESHOLD) return "Pastikan klien paham ruang lingkup sebelum mulai, agar biaya tidak membengkak.";
	if (scale === "besar" || scale === "sangat_besar") return "Deadline ketat bisa membuat jadwal terasa mepet — siapkan rencana cadangan.";
	return "Sisihkan buffer waktu agar revisi tidak mengganggu jadwal.";
}
function pickNextStep(scale, totalCost) {
	if (scale === "ringan") {
		if (totalCost >= COST_ATTENTION_THRESHOLD) return "Sepakati harga, ruang lingkup, dan tenggat waktu secara tertulis sebelum mulai.";
		return "Sepakati harga dan tenggat waktu dengan klien, lalu mulai pengerjaan.";
	}
	if (scale === "menengah") return "Buat urutan pekerjaan per hari atau per minggu sebelum mulai.";
	if (scale === "besar") return "Tentukan tahap pengerjaan dan kapan setiap bagian selesai.";
	return "Rencanakan siapa mengerjakan apa, lalu setujui jadwal bersama tim.";
}
function buildProjectSummary(ctx) {
	const scale = classifyProjectScale(ctx.totalHours);
	return {
		scale,
		scaleLabel: SCALE_LABELS[scale],
		scaleChipClass: SCALE_CHIP_CLASSES[scale],
		recommendation: pickRecommendation(scale, ctx.workingDays),
		watchOut: pickWatchOut(scale, ctx.bufferHours, ctx.totalCost),
		nextStep: pickNextStep(scale, ctx.totalCost)
	};
}
function formatMoney(amount) {
	return `Rp${Math.round(amount).toLocaleString("id-ID")}`;
}
function itemCost(item) {
	return (item.hours || 0) * (item.rate || 0);
}
function formatDuration(hours) {
	if (hours <= 0) {
		if (hours === 0) return "0 Jam";
		return "—";
	}
	const hoursPerWeek = 40;
	if (hours < 8) return `${Math.round(hours)} Jam`;
	if (hours < hoursPerWeek) return `${Math.ceil(hours / 8)} Hari`;
	const fullDays = Math.floor(hours / 8);
	const weeks = Math.floor(fullDays / 5);
	const days = fullDays % 5;
	const parts = [];
	if (weeks > 0) parts.push(`${weeks} Minggu`);
	if (days > 0) parts.push(`${days} Hari`);
	return parts.join(" ");
}
function simulate(items) {
	const totalHours = items.reduce((sum, i) => sum + (i.hours || 0), 0);
	const totalCost = items.reduce((sum, i) => sum + itemCost(i), 0);
	const averageRate = totalHours > 0 ? totalCost / totalHours : 0;
	const workingDays = totalHours > 0 ? Math.ceil(totalHours / 8) : 0;
	const bufferHours = Math.round(totalHours * .15);
	const idealHours = totalHours + bufferHours;
	let riskLevel = "low";
	if (workingDays > 40) riskLevel = "high";
	else if (workingDays >= 10) riskLevel = "moderate";
	return {
		totalHours,
		totalCost,
		averageRate,
		workingDays,
		durationLabel: formatDuration(totalHours),
		riskLevel,
		projectSummary: buildProjectSummary({
			totalHours,
			workingDays,
			totalCost,
			bufferHours
		}),
		bufferHours,
		idealHours
	};
}
var DIVIDER = "────────────────────────";
function buildDocumentBody(input) {
	return [
		input.projectName.trim() || "Proyek",
		"",
		"Estimasi Proyek",
		"",
		DIVIDER,
		"",
		"Skala Proyek",
		input.scaleLabel,
		"",
		"Estimasi Durasi",
		input.durationLabel,
		"",
		"Estimasi Biaya",
		formatMoney(input.totalCost),
		"",
		"Rekomendasi",
		input.recommendation,
		"",
		DIVIDER
	].join("\n");
}
/** Versi klien — tanpa branding, URL, atau timestamp. */
function formatClientShareText(input) {
	return buildDocumentBody(input);
}
async function copyToClipboard(text) {
	try {
		if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
			await navigator.clipboard.writeText(text);
			return true;
		}
	} catch {}
	return false;
}
function buildShareCardData(projectName, summary, durationLabel, totalCost) {
	return {
		projectName: projectName.trim() || "Proyek",
		scaleLabel: summary.scaleLabel,
		scale: summary.scale,
		durationLabel,
		costLabel: formatMoney(totalCost),
		recommendation: summary.recommendation,
		appUrl: getAppUrl(),
		logoUrl: getLogoAssetUrl()
	};
}
function shareCardFilename(projectName) {
	return `estimo-${projectName.trim().toLowerCase().replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "") || "proyek"}.png`;
}
/** Warna hex untuk ekspor PNG — tidak memakai oklch agar html-to-image konsisten. */
var SHARE_CARD_SIZE = {
	width: 1080,
	height: 1350
};
var shareCardTheme = {
	canvas: { background: "linear-gradient(165deg, #f7faf8 0%, #eef4f1 45%, #e8f0ec 100%)" },
	card: {
		background: "#ffffff",
		borderRadius: 40,
		border: "1px solid rgba(15, 23, 20, 0.06)",
		shadow: "0 24px 80px rgba(15, 35, 28, 0.08), 0 2px 8px rgba(15, 35, 28, 0.04)"
	},
	text: {
		primary: "#0f1a16",
		secondary: "#5c6b64",
		muted: "#8a9690",
		accent: "#2d8a6a"
	},
	fonts: {
		display: "\"Space Grotesk\", ui-sans-serif, system-ui, sans-serif",
		body: "\"DM Sans\", ui-sans-serif, system-ui, sans-serif"
	},
	scale: {
		ringan: {
			bg: "#e8f5ef",
			text: "#1a7a55"
		},
		menengah: {
			bg: "#e8f2ef",
			text: "#2d8a6a"
		},
		besar: {
			bg: "#faf3e8",
			text: "#9a6b1a"
		},
		sangat_besar: {
			bg: "#fceceb",
			text: "#b83d32"
		}
	}
};
function getScaleColors(scale) {
	return shareCardTheme.scale[scale];
}
async function waitForImages(element) {
	const images = element.querySelectorAll("img");
	await Promise.all([...images].map((img) => new Promise((resolve) => {
		if (img.complete) {
			resolve();
			return;
		}
		img.addEventListener("load", () => resolve(), { once: true });
		img.addEventListener("error", () => resolve(), { once: true });
	})));
}
async function renderShareCardBlob(element) {
	if (typeof document !== "undefined" && document.fonts?.ready) await document.fonts.ready;
	await waitForImages(element);
	const blob = await toBlob(element, {
		width: SHARE_CARD_SIZE.width,
		height: SHARE_CARD_SIZE.height,
		pixelRatio: 1,
		cacheBust: true,
		skipAutoScale: true
	});
	if (!blob) throw new Error("Gagal merender kartu estimasi.");
	return blob;
}
async function downloadShareCardPng(element, filename) {
	const blob = await renderShareCardBlob(element);
	const url = URL.createObjectURL(blob);
	const anchor = document.createElement("a");
	anchor.href = url;
	anchor.download = filename;
	anchor.click();
	URL.revokeObjectURL(url);
}
/**
* Orkestrator Bagikan — arsitektur siap untuk teks, WhatsApp, dan salin.
* v1: hanya mengunduh PNG kartu estimasi.
*/
async function bagikanProyek(options) {
	switch (options.channel) {
		case "image":
			await downloadShareCardPng(options.cardElement, options.filename);
			return;
		case "text":
		case "whatsapp":
		case "copy": throw new Error(`Saluran bagikan "${options.channel}" belum tersedia.`);
		default: {
			const _exhaustive = options.channel;
			throw new Error(`Saluran bagikan tidak dikenal: ${_exhaustive}`);
		}
	}
}
var ShareCardTemplate = (0, import_react.forwardRef)(function ShareCardTemplate({ data }, ref) {
	const scaleColors = getScaleColors(data.scale);
	const { width, height } = SHARE_CARD_SIZE;
	const t = shareCardTheme;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		style: {
			width,
			height,
			boxSizing: "border-box",
			background: t.canvas.background,
			padding: 72,
			display: "flex",
			flexDirection: "column",
			fontFamily: t.fonts.body,
			color: t.text.primary
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				flex: 1,
				display: "flex",
				flexDirection: "column",
				background: t.card.background,
				borderRadius: t.card.borderRadius,
				border: t.card.border,
				boxShadow: t.card.shadow,
				padding: "64px 56px 56px"
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					style: {
						margin: 0,
						fontFamily: t.fonts.body,
						fontSize: 22,
						fontWeight: 500,
						letterSpacing: "0.08em",
						textTransform: "uppercase",
						color: t.text.muted
					},
					children: "Estimasi Proyek"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					style: {
						margin: "20px 0 0",
						fontFamily: t.fonts.display,
						fontSize: 56,
						fontWeight: 700,
						lineHeight: 1.15,
						letterSpacing: "-0.03em",
						color: t.text.primary,
						maxHeight: 196,
						overflow: "hidden"
					},
					children: data.projectName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: { marginTop: 32 },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						style: {
							display: "inline-block",
							padding: "10px 20px",
							borderRadius: 999,
							background: scaleColors.bg,
							color: scaleColors.text,
							fontFamily: t.fonts.body,
							fontSize: 22,
							fontWeight: 600
						},
						children: data.scaleLabel
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						marginTop: 48,
						display: "grid",
						gridTemplateColumns: "1fr 1fr",
						gap: 32
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricBlock, {
						label: "Estimasi Durasi",
						value: data.durationLabel
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricBlock, {
						label: "Estimasi Biaya",
						value: data.costLabel,
						accent: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						marginTop: 48,
						flex: 1,
						padding: "28px 32px",
						borderRadius: 24,
						background: "#f6f9f7",
						border: "1px solid rgba(15, 23, 20, 0.05)"
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						style: {
							margin: 0,
							fontSize: 18,
							fontWeight: 600,
							color: t.text.secondary,
							letterSpacing: "0.02em"
						},
						children: "Rekomendasi"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						style: {
							margin: "12px 0 0",
							fontSize: 26,
							fontWeight: 500,
							lineHeight: 1.45,
							color: t.text.primary,
							maxHeight: 152,
							overflow: "hidden"
						},
						children: data.recommendation
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						marginTop: 48,
						paddingTop: 32,
						borderTop: "1px solid rgba(15, 23, 20, 0.08)",
						display: "flex",
						alignItems: "center",
						justifyContent: "space-between",
						gap: 24
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: data.logoUrl,
						alt: "ESTIMO",
						width: 140,
						height: 39,
						style: {
							display: "block",
							objectFit: "contain",
							objectPosition: "left center"
						}
					}), data.appUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						style: {
							fontSize: 20,
							fontWeight: 500,
							color: t.text.muted,
							textAlign: "right",
							wordBreak: "break-all"
						},
						children: data.appUrl.replace(/^https?:\/\//, "")
					}) : null]
				})
			]
		})
	});
});
function MetricBlock({ label, value, accent }) {
	const t = shareCardTheme;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		style: {
			margin: 0,
			fontSize: 18,
			fontWeight: 500,
			color: t.text.muted
		},
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		style: {
			margin: "8px 0 0",
			fontFamily: t.fonts.display,
			fontSize: accent ? 40 : 36,
			fontWeight: 700,
			letterSpacing: "-0.02em",
			color: accent ? t.text.accent : t.text.primary,
			lineHeight: 1.1
		},
		children: value
	})] });
}
/**
* Renders the export template outside the page layout via portal.
* Visually hidden and clipped — does not participate in sticky/stacking context.
*/
function ShareCardExportRoot({ data, cardRef }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		id: "estimo-share-card-export",
		"aria-hidden": true,
		"data-share-card-export": "",
		className: "pointer-events-none",
		style: {
			position: "absolute",
			top: 0,
			left: 0,
			width: 1,
			height: 1,
			overflow: "hidden",
			clipPath: "inset(50%)"
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShareCardTemplate, {
			ref: cardRef,
			data
		})
	});
}
function ShareCardExportPortal({ data, cardRef }) {
	if (typeof document === "undefined") return null;
	return (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShareCardExportRoot, {
		data,
		cardRef
	}), document.body);
}
/**
* Smoothly counts up (or down) to `value` whenever it changes.
* Keeps the live summary feeling responsive without heavy animation libs.
*/
function useCountUp(value, durationMs = 450) {
	const [display, setDisplay] = (0, import_react.useState)(value);
	const fromRef = (0, import_react.useRef)(value);
	const rafRef = (0, import_react.useRef)(void 0);
	(0, import_react.useEffect)(() => {
		const from = fromRef.current;
		const to = value;
		if (from === to) return;
		const start = performance_default.now();
		const tick = (now) => {
			const t = Math.min(1, (now - start) / durationMs);
			const eased = 1 - Math.pow(1 - t, 3);
			const current = from + (to - from) * eased;
			setDisplay(current);
			if (t < 1) rafRef.current = requestAnimationFrame(tick);
			else {
				fromRef.current = to;
				setDisplay(to);
			}
		};
		rafRef.current = requestAnimationFrame(tick);
		return () => {
			if (rafRef.current) cancelAnimationFrame(rafRef.current);
			fromRef.current = value;
		};
	}, [value, durationMs]);
	return display;
}
function AnimatedNumber({ value, format, className }) {
	const display = useCountUp(value);
	const rounded = Math.round(display);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className,
		children: format ? format(rounded) : rounded.toLocaleString("id-ID")
	});
}
function ProjectSummaryCard({ summary, onCopySummary }) {
	const rows = [
		{
			label: "Skala Proyek",
			value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold ${summary.scaleChipClass}`,
				children: summary.scaleLabel
			})
		},
		{
			label: "Rekomendasi",
			value: summary.recommendation
		},
		{
			label: "Hal yang Perlu Diperhatikan",
			value: summary.watchOut
		},
		{
			label: "Langkah Selanjutnya",
			value: summary.nextStep
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 rounded-2xl border border-border bg-card p-5 shadow-card sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-8 w-8 place-items-center rounded-lg bg-primary text-primary-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "h-4 w-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold",
					children: "Ringkasan Proyek"
				})]
			}), onCopySummary && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onCopySummary,
				className: "inline-flex shrink-0 items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-3.5 w-3.5" }), "Salin"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: "mt-4 space-y-3",
			children: rows.map(({ label, value }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-1 sm:flex-row sm:items-start sm:justify-between sm:gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "shrink-0 text-xs font-medium text-muted-foreground",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "text-sm font-semibold leading-snug text-foreground sm:max-w-[65%] sm:text-right",
					children: value
				})]
			}, label))
		})]
	});
}
var nextId = 1;
var makeItem = () => ({
	id: `item-${nextId++}`,
	name: "",
	hours: 0,
	rate: 0
});
var PLACEHOLDER_EXAMPLES = [
	"Website Company Profile",
	"Landing Page",
	"Aplikasi POS",
	"Logo Brand"
];
function SimulatePage() {
	const [projectName, setProjectName] = (0, import_react.useState)("");
	const [items, setItems] = (0, import_react.useState)([makeItem()]);
	const [showResult, setShowResult] = (0, import_react.useState)(false);
	const [isSharingCard, setIsSharingCard] = (0, import_react.useState)(false);
	const [placeholderIdx, setPlaceholderIdx] = (0, import_react.useState)(0);
	const resultRef = (0, import_react.useRef)(null);
	const shareCardRef = (0, import_react.useRef)(null);
	const simulationCompletedRef = (0, import_react.useRef)(false);
	useSimulationAbandonTracking(simulationCompletedRef);
	const validItems = (0, import_react.useMemo)(() => items.filter((i) => i.hours > 0), [items]);
	const canSimulate = projectName.trim().length > 0 && validItems.length > 0;
	const result = (0, import_react.useMemo)(() => simulate(items), [items]);
	(0, import_react.useEffect)(() => {
		const id = setInterval(() => setPlaceholderIdx((i) => (i + 1) % PLACEHOLDER_EXAMPLES.length), 2600);
		return () => clearInterval(id);
	}, []);
	const updateItem = (id, patch) => {
		setItems((prev) => prev.map((i) => i.id === id ? {
			...i,
			...patch
		} : i));
		setShowResult(false);
	};
	const setName = (value) => {
		setProjectName(value);
		setShowResult(false);
	};
	const addItem = () => {
		setItems((prev) => [...prev, makeItem()]);
		setShowResult(false);
	};
	const removeItem = (id) => {
		setItems((prev) => prev.filter((i) => i.id !== id));
		setShowResult(false);
	};
	const simulationMeta = (0, import_react.useMemo)(() => ({
		scale: result.projectSummary.scale,
		totalHours: result.totalHours,
		totalCost: result.totalCost,
		taskCount: validItems.length
	}), [result, validItems.length]);
	const handleSimulate = () => {
		if (!canSimulate) return;
		trackSimulationStarted(simulationMeta);
		setShowResult(true);
		simulationCompletedRef.current = true;
		trackSimulationCompleted(simulationMeta);
		requestAnimationFrame(() => resultRef.current?.scrollIntoView({
			behavior: "smooth",
			block: "start"
		}));
	};
	const shareCardData = (0, import_react.useMemo)(() => buildShareCardData(projectName, result.projectSummary, result.durationLabel, result.totalCost), [projectName, result]);
	const shareInput = (0, import_react.useMemo)(() => ({
		projectName,
		durationLabel: result.durationLabel,
		totalCost: result.totalCost,
		scaleLabel: result.projectSummary.scaleLabel,
		recommendation: result.projectSummary.recommendation
	}), [projectName, result]);
	const handleCopySummary = async () => {
		if (await copyToClipboard(formatClientShareText(shareInput))) {
			trackSummaryCopied("copy");
			toast.success("Ringkasan berhasil disalin.");
			return;
		}
		trackShareActionFailed("copy_summary", "clipboard_unavailable");
		toast.error("Gagal menyalin ringkasan. Coba lagi.");
	};
	const handleShareResult = async () => {
		const cardElement = shareCardRef.current;
		if (!cardElement || isSharingCard) return;
		setIsSharingCard(true);
		const toastId = toast.loading("Menyiapkan kartu estimasi...");
		try {
			await bagikanProyek({
				channel: "image",
				cardElement,
				filename: shareCardFilename(projectName)
			});
			trackShareCardDownloaded("image");
			toast.success("Kartu estimasi berhasil diunduh.", { id: toastId });
		} catch {
			trackShareActionFailed("share_card", "render_or_download_failed");
			toast.error("Gagal mengunduh kartu estimasi. Coba lagi.", { id: toastId });
		} finally {
			setIsSharingCard(false);
		}
	};
	const recalculate = () => {
		setShowResult(false);
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	const reset = () => {
		nextId = 1;
		setProjectName("");
		setItems([makeItem()]);
		setShowResult(false);
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 border-b border-border bg-background/80 backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-2xl items-center justify-between px-5 py-3.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), "Kembali"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "inline-flex items-center py-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EstimoLogo, { height: 22 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: reset,
								className: "inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-3.5 w-3.5" }), "Reset"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeToggle, {})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-t border-border/60 bg-muted/30",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-2xl px-5 py-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryStat, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListChecks, { className: "h-3.5 w-3.5" }),
									label: "Pekerjaan",
									value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, { value: validItems.length })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryStat, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5" }),
									label: "Total jam",
									value: result.totalHours > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, { value: result.totalHours }) : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryStat, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarRange, { className: "h-3.5 w-3.5" }),
									label: "Durasi",
									value: result.durationLabel
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryStat, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "h-3.5 w-3.5" }),
									label: "Biaya",
									value: result.totalCost > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedNumber, {
										value: result.totalCost,
										format: formatMoney
									}) : "—",
									highlight: true
								})
							]
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-2xl px-5 pb-40 pt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-2xl border border-border bg-card p-5 shadow-card sm:p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-semibold uppercase tracking-wide text-muted-foreground",
								children: projectName.trim().length === 0 ? "✨ Proyek Baru" : "Nama proyek"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: projectName,
								onChange: (e) => setName(e.target.value),
								placeholder: PLACEHOLDER_EXAMPLES[placeholderIdx],
								className: "mt-1 w-full bg-transparent text-lg font-bold tracking-tight outline-none placeholder:font-semibold placeholder:text-muted-foreground/50 sm:text-xl"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: [
									validItems.length,
									" pekerjaan · ",
									result.totalHours,
									" jam"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-center justify-between px-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold",
								children: "Daftar Pekerjaan"
							}), items.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: [validItems.length, " dihitung"]
							})]
						}), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center rounded-2xl border border-dashed border-input bg-card px-6 py-12 text-center shadow-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-14 w-14 place-items-center rounded-2xl bg-muted text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "h-7 w-7" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-base font-semibold",
									children: "Belum ada pekerjaan."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 max-w-xs text-sm text-muted-foreground",
									children: "Tambahkan pekerjaan pertama untuk mulai menghitung estimasi proyek."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: addItem,
									className: "mt-5 inline-flex items-center gap-1.5 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-soft transition-transform hover:-translate-y-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), "Tambah Pekerjaan"]
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [items.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-border bg-card p-4 shadow-card sm:p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: item.name,
											onChange: (e) => updateItem(item.id, { name: e.target.value }),
											placeholder: `Pekerjaan ${idx + 1}`,
											className: "min-w-0 flex-1 bg-transparent text-base font-semibold outline-none placeholder:font-medium placeholder:text-muted-foreground/50"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => removeItem(item.id),
											"aria-label": "Hapus pekerjaan",
											className: "grid h-9 w-9 shrink-0 place-items-center rounded-lg text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 grid grid-cols-2 gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-medium text-muted-foreground",
												children: "Estimasi Jam"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "number",
												min: 0,
												inputMode: "numeric",
												value: item.hours || "",
												onChange: (e) => updateItem(item.id, { hours: Math.max(0, Number(e.target.value)) }),
												placeholder: "0",
												className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2.5 text-base outline-none transition-shadow placeholder:text-muted-foreground/50 focus:ring-2 focus:ring-ring"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-medium text-muted-foreground",
												children: "Tarif per Jam"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "number",
												min: 0,
												inputMode: "numeric",
												value: item.rate || "",
												onChange: (e) => updateItem(item.id, { rate: Math.max(0, Number(e.target.value)) }),
												placeholder: "Rp0",
												className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2.5 text-base outline-none transition-shadow placeholder:text-muted-foreground/50 focus:ring-2 focus:ring-ring"
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 flex items-center justify-between border-t border-border/60 pt-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-medium text-muted-foreground",
											children: "Estimasi biaya"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-display text-sm font-bold",
											children: itemCost(item) > 0 ? formatMoney(itemCost(item)) : "—"
										})]
									})
								]
							}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: addItem,
								className: "inline-flex w-full items-center justify-center gap-1.5 rounded-xl border border-dashed border-input px-3 py-3 text-sm font-medium text-muted-foreground transition-colors hover:border-primary hover:text-primary",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), "Tambah Pekerjaan"]
							})]
						})]
					}),
					showResult && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: resultRef,
						className: "mt-10 scroll-mt-40 animate-in fade-in slide-in-from-bottom-4 duration-500",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Results, {
							projectName,
							result,
							onCopySummary: handleCopySummary
						})
					})
				]
			}),
			showResult && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShareCardExportPortal, {
				cardRef: shareCardRef,
				data: shareCardData
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-0 z-50 border-t border-border bg-background/90 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-2xl px-5 py-3",
					children: showResult ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: recalculate,
								className: "inline-flex flex-col items-center justify-center gap-1 rounded-xl border border-input bg-background px-2 py-3 text-xs font-semibold text-foreground transition-colors hover:bg-accent sm:flex-row sm:gap-1.5 sm:px-3 sm:text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-4 w-4 shrink-0" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "leading-none sm:hidden",
										children: "Ulang"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden leading-none sm:inline",
										children: "Hitung Ulang"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: handleCopySummary,
								className: "inline-flex flex-col items-center justify-center gap-1 rounded-xl bg-primary px-2 py-3 text-xs font-semibold text-primary-foreground shadow-focus transition-transform hover:-translate-y-0.5 sm:flex-row sm:gap-1.5 sm:px-3 sm:text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4 shrink-0" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "leading-none sm:hidden",
										children: "Salin"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden leading-none sm:inline",
										children: "Salin Ringkasan"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: handleShareResult,
								disabled: isSharingCard,
								className: "inline-flex flex-col items-center justify-center gap-1 rounded-xl border border-input bg-background px-2 py-3 text-xs font-semibold text-foreground transition-colors hover:bg-accent disabled:cursor-not-allowed disabled:opacity-50 sm:flex-row sm:gap-1.5 sm:px-3 sm:text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "leading-none",
									children: "Bagikan"
								})]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: handleSimulate,
						disabled: !canSimulate,
						className: "inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-4 text-base font-semibold text-primary-foreground shadow-focus transition-transform hover:-translate-y-0.5 disabled:translate-y-0 disabled:cursor-not-allowed disabled:opacity-40 disabled:shadow-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4.5 w-4.5" }), "Simulasikan Estimasi"]
					}), !canSimulate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-center text-xs text-muted-foreground",
						children: "Isi nama proyek dan minimal satu pekerjaan dengan jam untuk menyimulasikan."
					})] })
				})
			})
		]
	});
}
function SummaryStat({ icon, label, value, highlight }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-xl border px-3 py-2 ${highlight ? "border-primary/30 bg-accent" : "border-border bg-card"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1 text-muted-foreground",
			children: [icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[0.7rem] font-medium",
				children: label
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-0.5 font-display text-lg font-bold tracking-tight",
			children: value
		})]
	});
}
function Results({ projectName, result, onCopySummary }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-wide text-muted-foreground",
				children: "Estimasi untuk"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "truncate text-xl font-bold",
				children: projectName
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4" }),
					label: "Total jam",
					value: `${result.totalHours.toLocaleString("id-ID")} Jam`,
					hint: `Disarankan +${result.bufferHours} jam buffer · ideal ${result.idealHours.toLocaleString("id-ID")} Jam`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarRange, { className: "h-4 w-4" }),
					label: "Estimasi durasi",
					value: result.durationLabel,
					hint: `${result.totalHours.toLocaleString("id-ID")} jam kerja`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "h-4 w-4" }),
					label: "Estimasi biaya",
					value: formatMoney(result.totalCost),
					hint: `Rata-rata ${formatMoney(result.averageRate)} per jam`,
					highlight: true
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectSummaryCard, {
			summary: result.projectSummary,
			onCopySummary
		})
	] });
}
function StatCard({ icon, label, value, hint, highlight }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-2xl border p-5 shadow-card ${highlight ? "border-primary/30 bg-accent" : "border-border bg-card"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1.5 text-muted-foreground",
				children: [icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium",
					children: label
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-display text-2xl font-bold tracking-tight",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: hint
			})
		]
	});
}
//#endregion
export { SimulatePage as component };
