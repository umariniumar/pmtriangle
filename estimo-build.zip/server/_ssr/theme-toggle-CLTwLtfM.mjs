import { n as __toESM } from "../_runtime.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as captureClientEvent } from "./client-DeQjJImR.mjs";
import { c as Moon, r as Sun } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/theme-toggle-CLTwLtfM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function getDurationBucket(totalHours) {
	if (totalHours <= 0) return "empty";
	if (totalHours <= 8) return "0-8h";
	if (totalHours <= 40) return "9-40h";
	if (totalHours <= 120) return "41-120h";
	return "120h+";
}
function getCostBucket(totalCost) {
	if (totalCost <= 0) return "empty";
	if (totalCost < 1e6) return "under_1m";
	if (totalCost < 5e6) return "1m_5m";
	if (totalCost < 2e7) return "5m_20m";
	return "20m_plus";
}
function getDeviceType() {
	if (typeof window === "undefined") return "desktop";
	const width = window.innerWidth;
	if (width < 768) return "mobile";
	if (width < 1024) return "tablet";
	return "desktop";
}
function getBrowserName() {
	if (typeof navigator === "undefined") return "unknown";
	const ua = navigator.userAgent;
	if (ua.includes("Edg/")) return "edge";
	if (ua.includes("Firefox/")) return "firefox";
	if (ua.includes("Chrome/")) return "chrome";
	if (ua.includes("Safari/") && !ua.includes("Chrome/")) return "safari";
	return "other";
}
function buildProjectMetadata(input) {
	return {
		project_scale: input.scale,
		duration_bucket: getDurationBucket(input.totalHours),
		cost_bucket: getCostBucket(input.totalCost),
		task_count: input.taskCount,
		device_type: getDeviceType(),
		browser: getBrowserName()
	};
}
function projectMeta(input) {
	return buildProjectMetadata(input);
}
function trackLandingView() {
	captureClientEvent("landing_view");
}
function trackCtaClicked(source) {
	captureClientEvent("cta_clicked", { source });
}
function trackSimulationStarted(input) {
	captureClientEvent("simulation_started", projectMeta(input));
}
function trackSimulationCompleted(input) {
	captureClientEvent("simulation_completed", projectMeta(input));
}
function trackSimulationAbandoned() {
	captureClientEvent("simulation_abandoned");
}
function trackSummaryCopied(channel = "copy") {
	captureClientEvent("summary_copied", { channel });
}
function trackShareCardDownloaded(channel = "image") {
	captureClientEvent("share_card_downloaded", { channel });
}
function trackShareActionFailed(action, reason) {
	captureClientEvent("share_action_failed", {
		action,
		reason: reason.slice(0, 120)
	});
}
var STORAGE_KEY = "estimo-theme";
var LEGACY_STORAGE_KEY = "pds-theme";
function getInitialTheme() {
	if (typeof window === "undefined") return "light";
	const stored = window.localStorage.getItem(STORAGE_KEY) ?? window.localStorage.getItem(LEGACY_STORAGE_KEY);
	if (stored === "light" || stored === "dark") return stored;
	return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}
function useTheme() {
	const [theme, setTheme] = (0, import_react.useState)("light");
	(0, import_react.useEffect)(() => {
		setTheme(getInitialTheme());
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.classList.toggle("dark", theme === "dark");
		window.localStorage.setItem(STORAGE_KEY, theme);
	}, [theme]);
	const toggle = () => setTheme((t) => t === "dark" ? "light" : "dark");
	return {
		theme,
		toggle
	};
}
function ThemeToggle() {
	const { theme, toggle } = useTheme();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		onClick: toggle,
		"aria-label": theme === "dark" ? "Beralih ke mode terang" : "Beralih ke mode gelap",
		className: "grid h-9 w-9 place-items-center rounded-full border border-border bg-card text-muted-foreground shadow-soft transition-colors hover:text-foreground",
		children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "h-4 w-4" })
	});
}
//#endregion
export { trackShareCardDownloaded as a, trackSimulationStarted as c, trackShareActionFailed as i, trackSummaryCopied as l, trackCtaClicked as n, trackSimulationAbandoned as o, trackLandingView as r, trackSimulationCompleted as s, ThemeToggle as t };
