import { r as __toESM } from "../_runtime.mjs";
import { n as require_react } from "./react+tanstack__react-query.mjs";
//#region node_modules/posthog-js/dist/module.js
var t = "undefined" != typeof window ? window : void 0, e = "undefined" != typeof globalThis ? globalThis : t;
"undefined" == typeof self && (e.self = e), "undefined" == typeof File && (e.File = function() {});
var i = null == e ? void 0 : e.navigator, r = null == e ? void 0 : e.document, s = null == e ? void 0 : e.location, n = null == e ? void 0 : e.fetch, o = null != e && e.XMLHttpRequest && "withCredentials" in new e.XMLHttpRequest() ? e.XMLHttpRequest : void 0, a = null == e ? void 0 : e.AbortController, l = null == e ? void 0 : e.CompressionStream, u = null == i ? void 0 : i.userAgent, h = null != t ? t : {}, d = "1.396.6", v = {
	DEBUG: !1,
	LIB_VERSION: d,
	LIB_NAME: "web",
	JS_SDK_VERSION: d
};
function c(t, e, i, r, s, n, o) {
	try {
		var a = t[n](o), l = a.value;
	} catch (t) {
		i(t);
		return;
	}
	a.done ? e(l) : Promise.resolve(l).then(r, s);
}
function p(t) {
	return function() {
		var e = this, i = arguments;
		return new Promise((function(r, s) {
			var n = t.apply(e, i);
			function o(t) {
				c(n, r, s, o, a, "next", t);
			}
			function a(t) {
				c(n, r, s, o, a, "throw", t);
			}
			o(void 0);
		}));
	};
}
function f() {
	return f = Object.assign ? Object.assign.bind() : function(t) {
		for (var e = 1; arguments.length > e; e++) {
			var i = arguments[e];
			for (var r in i) ({}).hasOwnProperty.call(i, r) && (t[r] = i[r]);
		}
		return t;
	}, f.apply(null, arguments);
}
function _(t, e) {
	if (null == t) return {};
	var i = {};
	for (var r in t) if ({}.hasOwnProperty.call(t, r)) {
		if (-1 !== e.indexOf(r)) continue;
		i[r] = t[r];
	}
	return i;
}
var g = (t) => {
	if ("string" != typeof t) return t;
	try {
		return JSON.parse(t);
	} catch (e) {
		return t;
	}
};
function m(t) {
	return "string" == typeof t || t;
}
function y(t) {
	return "string" == typeof t ? t : void 0;
}
var b, w = function(t) {
	return t.AnonymousId = "anonymous_id", t.DistinctId = "distinct_id", t.Props = "props", t.EnablePersonProcessing = "enable_person_processing", t.PersonMode = "person_mode", t.FeatureFlagDetails = "feature_flag_details", t.FeatureFlags = "feature_flags", t.FeatureFlagPayloads = "feature_flag_payloads", t.BootstrapFeatureFlagDetails = "bootstrap_feature_flag_details", t.BootstrapFeatureFlags = "bootstrap_feature_flags", t.BootstrapFeatureFlagPayloads = "bootstrap_feature_flag_payloads", t.OverrideFeatureFlags = "override_feature_flags", t.Queue = "queue", t.LogsQueue = "logs_queue", t.OptedOut = "opted_out", t.SessionId = "session_id", t.SessionStartTimestamp = "session_start_timestamp", t.SessionLastTimestamp = "session_timestamp", t.PersonProperties = "person_properties", t.GroupProperties = "group_properties", t.InstalledAppBuild = "installed_app_build", t.InstalledAppVersion = "installed_app_version", t.SessionReplay = "session_replay", t.SessionReplayEventTriggerActivatedSession = "session_replay_event_trigger_activated_session", t.SurveyLastSeenDate = "survey_last_seen_date", t.SurveysSeen = "surveys_seen", t.Surveys = "surveys", t.RemoteConfig = "remote_config", t.FlagsEndpointWasHit = "flags_endpoint_was_hit", t.DeviceId = "device_id", t;
}({}), E = function(t) {
	return t.GZipJS = "gzip-js", t.Base64 = "base64", t;
}({}), x = [
	"$snapshot",
	"$pageview",
	"$pageleave",
	"$set",
	"survey dismissed",
	"survey sent",
	"survey shown",
	"$identify",
	"$groupidentify",
	"$create_alias",
	"$$client_ingestion_warning",
	"$web_experiment_applied",
	"$feature_enrollment_update",
	"$feature_flag_called"
], S = ["token"], T = "NativeGzipValidationError", k = (t) => t.length >= 2 && 31 === t[0] && 139 === t[1], R = (t, e) => t === E.GZipJS || e === E.GZipJS || "gzip" === e, P = (t) => !(!t || "object" != typeof t) && "NotReadableError" === ("name" in t ? String(t.name) : ""), I = (t) => {
	var e = /* @__PURE__ */ new Error("Native gzip produced invalid output: " + t);
	throw e.name = T, e;
}, O = function() {
	var t = p((function* (t, e) {
		18 > t.size && I("too-short");
		var i = new Uint8Array(yield t.slice(0, 10).arrayBuffer());
		k(i) && 8 === i[2] || I("invalid-header");
		var r = new DataView(yield t.slice(t.size - 8).arrayBuffer());
		r.getUint32(0, !0) !== ((t) => {
			for (var e = (() => {
				if (b) return b;
				b = [];
				for (var t = 0; 256 > t; t++) {
					for (var e = t, i = 0; 8 > i; i++) e = 1 & e ? 3988292384 ^ e >>> 1 : e >>> 1;
					b[t] = e >>> 0;
				}
				return b;
			})(), i = 4294967295, r = 0; t.length > r; r++) i = e[255 & (i ^ t[r])] ^ i >>> 8;
			return (4294967295 ^ i) >>> 0;
		})(e) && I("invalid-crc");
		var s = e.length >>> 0;
		r.getUint32(4, !0) !== s && I("invalid-size");
	}));
	return function(e, i) {
		return t.apply(this, arguments);
	};
}();
function C() {
	return C = p((function* (t, e, i) {
		void 0 === e && (e = !0);
		try {
			var r = new TextEncoder().encode(t), s = new CompressionStream("gzip"), n = s.writable.getWriter(), o = n.write(r).then((() => n.close())).catch(function() {
				var t = p((function* (t) {
					try {
						yield n.abort(t);
					} catch (t) {}
					throw t;
				}));
				return function(e) {
					return t.apply(this, arguments);
				};
			}()), a = new Response(s.readable).blob(), [l] = yield Promise.all([a, o]);
			return yield O(l, r), l;
		} catch (t) {
			if (null != i && i.rethrow) throw t;
			return e && console.error("Failed to gzip compress data", t), null;
		}
	})), C.apply(this, arguments);
}
var A = [
	"amazonbot",
	"amazonproductbot",
	"app.hypefactors.com",
	"applebot",
	"archive.org_bot",
	"awariobot",
	"backlinksextendedbot",
	"baiduspider",
	"bingbot",
	"bingpreview",
	"chrome-lighthouse",
	"dataforseobot",
	"deepscan",
	"duckduckbot",
	"facebookexternal",
	"facebookcatalog",
	"http://yandex.com/bots",
	"hubspot",
	"ia_archiver",
	"leikibot",
	"linkedinbot",
	"meta-externalagent",
	"mj12bot",
	"msnbot",
	"nessus",
	"petalbot",
	"pinterest",
	"prerender",
	"rogerbot",
	"screaming frog",
	"sebot-wa",
	"sitebulb",
	"slackbot",
	"slurp",
	"trendictionbot",
	"turnitin",
	"twitterbot",
	"vercel-screenshot",
	"vercelbot",
	"yahoo! slurp",
	"yandexbot",
	"zoombot",
	"bot.htm",
	"bot.php",
	"(bot;",
	"bot/",
	"crawler",
	"ahrefsbot",
	"ahrefssiteaudit",
	"semrushbot",
	"siteauditbot",
	"splitsignalbot",
	"gptbot",
	"oai-searchbot",
	"chatgpt-user",
	"perplexitybot",
	"better uptime bot",
	"sentryuptimebot",
	"uptimerobot",
	"headlesschrome",
	"cypress",
	"google-hoteladsverifier",
	"adsbot-google",
	"apis-google",
	"duplexweb-google",
	"feedfetcher-google",
	"google favicon",
	"google web preview",
	"google-read-aloud",
	"googlebot",
	"googleother",
	"google-cloudvertexbot",
	"googleweblight",
	"mediapartners-google",
	"storebot-google",
	"google-inspectiontool",
	"bytespider"
], F = function(t, e) {
	if (void 0 === e && (e = []), !t) return !1;
	var i = t.toLowerCase();
	return A.concat(e).some(((t) => {
		var e = t.toLowerCase();
		return -1 !== i.indexOf(e);
	}));
};
function M(t, e) {
	return -1 !== t.indexOf(e);
}
var D = function(t) {
	return t.trim();
}, L = function(t) {
	return t.replace(/^\$/, "");
}, N = Object.prototype, U = N.hasOwnProperty, j = N.toString, B = Array.isArray || function(t) {
	return "[object Array]" === j.call(t);
}, z = (t) => "function" == typeof t, H = (t) => t === Object(t) && !B(t), q = (t) => {
	if (H(t)) {
		for (var e in t) if (U.call(t, e)) return !1;
		return !0;
	}
	return !1;
}, V = (t) => void 0 === t, G = (t) => "[object String]" == j.call(t), W = (t) => G(t) && 0 === t.trim().length, Y = (t) => null === t, K = (t) => V(t) || Y(t), J = (t) => "[object Number]" == j.call(t) && t == t, Q = (t) => J(t) && t > 0, X = (t) => "[object Boolean]" === j.call(t), Z = (t) => t instanceof FormData, tt = (t) => M(x, t), et = (t) => M(S, t);
function it(t) {
	return null === t || "object" != typeof t;
}
function rt(t, e) {
	return {}.toString.call(t) === "[object " + e + "]";
}
function st(t) {
	return "undefined" != typeof Event && function(t, e) {
		try {
			return t instanceof e;
		} catch (t) {
			return !1;
		}
	}(t, Event);
}
var nt = [
	!0,
	"true",
	1,
	"1",
	"yes"
], ot = (t) => M(nt, t), at = [
	!1,
	"false",
	0,
	"0",
	"no"
];
function lt(t, e, i, r, s) {
	return e > i && (r.warn("min cannot be greater than max."), e = i), J(t) ? t > i ? (r.warn(" cannot be  greater than max: " + i + ". Using max value instead."), i) : e > t ? (r.warn(" cannot be less than min: " + e + ". Using min value instead."), e) : t : (r.warn(" must be a number. using max or fallback. max: " + i + ", fallback: " + s), lt(s || i, e, i, r));
}
var ut = class {
	constructor(t) {
		this.Ee = {}, this.Pe = t.Pe, this.Fe = lt(t.bucketSize, 0, 100, t.Ae), this.$e = lt(t.refillRate, 0, this.Fe, t.Ae), this.De = lt(t.refillInterval, 0, 864e5, t.Ae);
	}
	Ne(t, e) {
		var i = Math.floor((e - t.lastAccess) / this.De);
		i > 0 && (t.tokens = Math.min(t.tokens + i * this.$e, this.Fe), t.lastAccess = t.lastAccess + i * this.De);
	}
	consumeRateLimit(t) {
		var e, i = Date.now(), r = String(t), s = this.Ee[r];
		return s ? this.Ne(s, i) : this.Ee[r] = s = {
			tokens: this.Fe,
			lastAccess: i
		}, 0 === s.tokens || (s.tokens--, 0 === s.tokens && (null == (e = this.Pe) || e.call(this, t)), 0 === s.tokens);
	}
	stop() {
		this.Ee = {};
	}
};
var ht = "Mobile", dt = "iOS", vt = "Android", ct = "Tablet", pt = vt + " " + ct, ft = "iPad", _t = "Apple", gt = _t + " Watch", mt = "Safari", yt = "BlackBerry", bt = "Samsung", wt = bt + "Browser", Et = bt + " Internet", xt = "Chrome", St = xt + " OS", Tt = xt + " " + dt, $t = "Internet Explorer", kt = $t + " " + ht, Rt = "Opera", Pt = Rt + " Mini", It = "Edge", Ot = "Microsoft " + It, Ct = "Firefox", At = Ct + " " + dt, Ft = "Nintendo", Mt = "PlayStation", Dt = "Xbox", Lt = vt + " " + ht, Nt = ht + " " + mt, Ut = "Windows", jt = Ut + " Phone", Bt = "Nokia", zt = "Ouya", Ht = "Generic", qt = Ht + " " + ht.toLowerCase(), Vt = Ht + " " + ct.toLowerCase(), Gt = "Konqueror", Wt = "Oculus Browser", Yt = "Vivaldi", Kt = "Yandex", Jt = "Whale", Qt = "DuckDuckGo", Xt = "Pale Moon", Zt = "Waterfox", te = "Brave", ee = "Google Search App", ie = "(\\d+(\\.\\d+)?)", re = new RegExp("Version/" + ie), se = new RegExp(Dt, "i"), ne = new RegExp(Mt + " \\w+", "i"), oe = new RegExp(Ft + " \\w+", "i"), ae = new RegExp(yt + "|PlayBook|BB10", "i"), le = {
	"NT3.51": "NT 3.11",
	"NT4.0": "NT 4.0",
	"5.0": "2000",
	5.1: "XP",
	5.2: "XP",
	"6.0": "Vista",
	6.1: "7",
	6.2: "8",
	6.3: "8.1",
	6.4: "10",
	"10.0": "10"
}, ue = function(t, e, i, r) {
	e = e || "";
	return function(t) {
		return null != t && t.brave ? te : null;
	}(i) || (null != r && r.detectGoogleSearchApp && M(t, "GSA/") ? ee : M(t, " OPR/") && M(t, "Mini") ? Pt : M(t, " OPR/") ? Rt : ae.test(t) ? yt : M(t, "IE" + ht) || M(t, "WPDesktop") ? kt : M(t, "OculusBrowser") ? Wt : M(t, wt) ? Et : M(t, It) || M(t, "Edg/") ? Ot : M(t, Yt + "/") ? Yt : M(t, "YaBrowser/") ? Kt : M(t, Jt + "/") ? Jt : M(t, Qt + "/") || M(t, "Ddg/") ? Qt : M(t, "FBIOS") ? "Facebook " + ht : M(t, "UCWEB") || M(t, "UCBrowser") ? "UC Browser" : M(t, "CriOS") ? Tt : M(t, "CrMo") || M(t, xt) ? xt : M(t, vt) && M(t, mt) ? Lt : M(t, "FxiOS") ? At : M(t.toLowerCase(), Gt.toLowerCase()) ? Gt : M(t, te + "/") ? te : ((t, e) => e && M(e, _t) || function(t) {
		return M(t, mt) && !M(t, xt) && !M(t, vt);
	}(t))(t, e) ? M(t, ht) ? Nt : mt : M(t, "PaleMoon/") ? Xt : M(t, Zt + "/") ? Zt : M(t, Ct) ? Ct : M(t, "MSIE") || M(t, "Trident/") ? $t : M(t, "Gecko") ? Ct : "");
}, he = {
	[kt]: [new RegExp("rv:" + ie)],
	[Ot]: [new RegExp(It + "?\\/" + ie)],
	[xt]: [new RegExp("(" + xt + "|CrMo)\\/" + ie)],
	[Tt]: [new RegExp("CriOS\\/" + ie)],
	"UC Browser": [new RegExp("(UCBrowser|UCWEB)\\/" + ie)],
	[mt]: [re],
	[Nt]: [re],
	[Rt]: [new RegExp("(Opera|OPR)\\/" + ie)],
	[Ct]: [new RegExp(Ct + "\\/" + ie)],
	[At]: [new RegExp("FxiOS\\/" + ie)],
	[Gt]: [new RegExp("Konqueror[:/]?" + ie, "i")],
	[yt]: [new RegExp(yt + " " + ie), re],
	[Lt]: [new RegExp("android\\s" + ie, "i")],
	[Et]: [new RegExp(wt + "\\/" + ie)],
	[Wt]: [new RegExp("OculusBrowser\\/" + ie)],
	[Yt]: [new RegExp(Yt + "\\/" + ie)],
	[Kt]: [new RegExp("YaBrowser\\/" + ie)],
	[Jt]: [new RegExp(Jt + "\\/" + ie)],
	[te]: [new RegExp(te + "\\/" + ie)],
	[Qt]: [new RegExp("(DuckDuckGo|Ddg)\\/" + ie)],
	[Xt]: [new RegExp("PaleMoon\\/" + ie)],
	[Zt]: [new RegExp(Zt + "\\/" + ie)],
	[ee]: [new RegExp("GSA\\/" + ie)],
	[$t]: [new RegExp("(rv:|MSIE )" + ie)],
	Mozilla: [new RegExp("rv:" + ie)]
}, de = function(t, e, i, r) {
	var n = he[ue(t, e, i, r)];
	if (V(n)) return null;
	for (var o = 0; n.length > o; o++) {
		var a = t.match(n[o]);
		if (a) return parseFloat(a[a.length - 2]);
	}
	return null;
}, ve = [
	[new RegExp(Dt + "; " + Dt + " (.*?)[);]", "i"), (t) => [Dt, t && t[1] || ""]],
	[new RegExp(Ft, "i"), [Ft, ""]],
	[new RegExp(Mt, "i"), [Mt, ""]],
	[ae, [yt, ""]],
	[new RegExp(Ut, "i"), (t, e) => {
		if (/Phone/.test(e) || /WPDesktop/.test(e)) return [jt, ""];
		if (new RegExp(ht).test(e) && !/IEMobile\b/.test(e)) return [Ut + " " + ht, ""];
		var i = /Windows NT ([0-9.]+)/i.exec(e);
		if (i && i[1]) {
			var r = le[i[1]] || "";
			return /arm/i.test(e) && (r = "RT"), [Ut, r];
		}
		return [Ut, ""];
	}],
	[/((iPhone|iPad|iPod).*?OS (\d+)_(\d+)_?(\d+)?|iPhone)/, (t) => t && t[3] ? [dt, [
		t[3],
		t[4],
		t[5] || "0"
	].join(".")] : [dt, ""]],
	[/(watch.*\/(\d+\.\d+\.\d+)|watch os,(\d+\.\d+),)/i, (t) => {
		var e = "";
		return t && t.length >= 3 && (e = V(t[2]) ? t[3] : t[2]), ["watchOS", e];
	}],
	[new RegExp("(" + vt + " (\\d+)\\.(\\d+)\\.?(\\d+)?|" + vt + ")", "i"), (t) => t && t[2] ? [vt, [
		t[2],
		t[3],
		t[4] || "0"
	].join(".")] : [vt, ""]],
	[/Mac OS X (\d+)[_.](\d+)[_.]?(\d+)?/i, (t) => {
		var e = ["Mac OS X", ""];
		return t && t[1] && (e[1] = [
			t[1],
			t[2],
			t[3] || "0"
		].join(".")), e;
	}],
	[/Mac/i, ["Mac OS X", ""]],
	[/CrOS/, [St, ""]],
	[/Linux|debian/i, ["Linux", ""]]
], ce = function(t) {
	return oe.test(t) ? Ft : ne.test(t) ? Mt : se.test(t) ? Dt : new RegExp(zt, "i").test(t) ? zt : new RegExp("(" + jt + "|WPDesktop)", "i").test(t) ? jt : /iPad/.test(t) ? ft : /iPod/.test(t) ? "iPod Touch" : /iPhone/.test(t) ? "iPhone" : /(watch)(?: ?os[,/]|\d,\d\/)[\d.]+/i.test(t) ? gt : ae.test(t) ? yt : /(kobo)\s(ereader|touch)/i.test(t) ? "Kobo" : new RegExp(Bt, "i").test(t) ? Bt : /(kf[a-z]{2}wi|aeo[c-r]{2})( bui|\))/i.test(t) || /(kf[a-z]+)( bui|\)).+silk\//i.test(t) ? "Kindle Fire" : /(Android|ZTE)/i.test(t) ? new RegExp(ht).test(t) && !/(9138B|TB782B|Nexus [97]|pixel c|HUAWEISHT|BTV|noble nook|smart ultra 6)/i.test(t) || /pixel[\daxl ]{1,6}/i.test(t) && !/pixel c/i.test(t) || /(huaweimed-al00|tah-|APA|SM-G92|i980|zte|U304AA)/i.test(t) || /lmy47v/i.test(t) && !/QTAQZ3/i.test(t) ? vt : pt : new RegExp("(pda|" + ht + ")", "i").test(t) ? qt : new RegExp(ct, "i").test(t) && !new RegExp(ct + " pc", "i").test(t) ? Vt : "";
}, pe = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function fe(t, e) {
	return "string" == typeof (i = t) && pe.test(i) ? t : e();
	var i;
}
function _e(t) {
	return t ? t.split("#")[0] : t;
}
function ge(t, e) {
	var i = setTimeout(t, e);
	return null != i && i.unref && i?.unref(), i;
}
var me = (t) => t instanceof Error, ye = {
	trace: {
		text: "TRACE",
		number: 1
	},
	debug: {
		text: "DEBUG",
		number: 5
	},
	info: {
		text: "INFO",
		number: 9
	},
	warn: {
		text: "WARN",
		number: 13
	},
	error: {
		text: "ERROR",
		number: 17
	},
	fatal: {
		text: "FATAL",
		number: 21
	}
}, be = ye.info;
function we(t) {
	if (X(t)) return { boolValue: t };
	if ("number" == typeof t) return Number.isFinite(t) ? Number.isInteger(t) ? { intValue: t } : { doubleValue: t } : { stringValue: String(t) };
	if ("string" == typeof t) return { stringValue: t };
	if (B(t)) return { arrayValue: { values: t.map(((t) => we(t))) } };
	try {
		return { stringValue: JSON.stringify(t) };
	} catch (e) {
		return { stringValue: String(t) };
	}
}
function Ee(t) {
	var e = [];
	for (var i in t) {
		var r = t[i];
		Y(r) || V(r) || e.push({
			key: i,
			value: we(r)
		});
	}
	return e;
}
function xe(t, e) {
	var { text: r, number: s } = ye[t.level || "info"] || be, n = String(Date.now()) + "000000", o = {};
	e.distinctId && (o.posthogDistinctId = e.distinctId), e.sessionId && (o.sessionId = e.sessionId), e.windowId && (o["window.id"] = e.windowId), K(e.sessionStartTimestamp) || (o.sessionStartTimestamp = String(e.sessionStartTimestamp)), K(e.lastActivityTimestamp) || (o.lastActivityTimestamp = String(e.lastActivityTimestamp)), e.currentUrl && (o["url.full"] = e.currentUrl), e.screenName && (o["screen.name"] = e.screenName), e.appState && (o["app.state"] = e.appState), e.activeFeatureFlags && e.activeFeatureFlags.length > 0 && (o.feature_flags = e.activeFeatureFlags);
	var a = f({}, o, t.attributes || {}), l = {
		timeUnixNano: n,
		observedTimeUnixNano: n,
		severityNumber: s,
		severityText: r,
		body: { stringValue: t.body },
		attributes: Ee(a)
	};
	return t.trace_id && (l.traceId = t.trace_id), t.span_id && (l.spanId = t.span_id), V(t.trace_flags) || (l.flags = t.trace_flags), l;
}
function Se(t, e, i) {
	return f({}, t.resourceAttributes, { "service.name": t.serviceName || "unknown_service" }, t.environment && { "deployment.environment": t.environment }, t.serviceVersion && { "service.version": t.serviceVersion }, {
		"telemetry.sdk.name": e,
		"telemetry.sdk.version": i
	});
}
function Te(t, e, i, r) {
	return { resourceLogs: [{
		resource: { attributes: Ee(e) },
		scopeLogs: [{
			scope: {
				name: i,
				version: r
			},
			logRecords: t
		}]
	}] };
}
var $e = class {
	constructor(t, e, i, r, s, n, o) {
		var a;
		void 0 === n && (n = () => Promise.resolve()), this._instance = t, this.Se = e, this.Ae = i, this.qe = r, this.Be = s, this.je = n, this.He = o, this.Ue = null, this.ze = 0, this.Ve = 0, this.We = 0, this.Ge = 0, this.Ze = !1, this.Qe = e.maxBufferSize, this.Je = Math.max(null !== (a = e.maxQueueSize) && void 0 !== a ? a : e.maxBufferSize, e.maxBufferSize), this.Ye = e.flushIntervalMs, this.Ke = e.maxBatchRecordsPerPost, this.Xe = e.rateCapWindowMs, this.et = e.maxLogsPerInterval;
	}
	reset() {
		this.tt(), this.Ue = null, this.We = 0, this.Ge = 0, this.Ze = !1, this.ze = 0, this.Ve = 0, this.Ke = this.Se.maxBatchRecordsPerPost;
	}
	onReconnect() {
		this.Ve = 0, this.rt();
	}
	captureLog(t) {
		if (!this._instance.isDisabled && !this._instance.optedOut && null != t && t.body) {
			var e = this.it(t);
			if (null !== e) if (e.body) {
				if (this.nt()) {
					var i = { record: xe(e, this.qe()) };
					this.Be((() => this.st(i)));
				}
			} else this.Ae.info("Log was rejected in beforeSend function");
		}
	}
	it(t) {
		var e = this.Se.beforeSend;
		if (!e) return t;
		var i = B(e) ? e : [e], r = t;
		for (var s of i) try {
			var n = s(r);
			if (!n) return this.Ae.info("Log was rejected in beforeSend function"), null;
			r = n;
		} catch (t) {
			return this.Ae.error("Error in beforeSend function for log:", t), null;
		}
		return r;
	}
	nt() {
		if (void 0 === this.et) return !0;
		var t = Date.now(), e = t - this.We;
		return this.Xe > e && e >= 0 || (this.We = t, this.Ge = 0, this.Ze = !1), this.et > this.Ge ? (this.Ge++, !0) : (this.Ze || (this.Ae.warn("captureLog dropping logs: exceeded " + this.et + " logs per " + this.Xe + "ms"), this.Ze = !0), !1);
	}
	flush() {
		var t = this;
		return p((function* () {
			if (!t._instance.isDisabled) return t.Ue || (t.Ue = t.ot().finally((() => {
				t.Ue = null;
			}))), t.Ue;
		}))();
	}
	ot() {
		var t = this;
		return p((function* () {
			var e;
			t.tt();
			var i = null !== (e = t._instance.getPersistedProperty(w.LogsQueue)) && void 0 !== e ? e : [];
			if (0 !== i.length) for (var r = i.length, s = 0; i.length > 0 && r > s;) {
				var n, o;
				t.ze = 0;
				var a = Math.min(i.length, t.Ke), l = i.slice(0, a), u = Te(l.map(((t) => t.record)), t.ut(), null !== (n = t.He) && void 0 !== n ? n : t._instance.getLibraryId(), t._instance.getLibraryVersion()), h = yield t._instance.ht(u);
				if ("too-large" === h.kind && l.length > 1) t.Ke = Math.max(1, Math.floor(l.length / 2)), t.Ae.warn("Received 413 when sending logs batch of size " + l.length + ", reducing batch size to " + t.Ke);
				else {
					if ("retry-later" === h.kind) throw h.error;
					if ("too-large" === h.kind ? t.Ae.warn("Dropping a single log record after 413 with batch size 1 — the record is larger than the server cap and cannot be split further.") : "ok" === h.kind && t.Se.maxBatchRecordsPerPost > t.Ke && (t.Ke = Math.min(t.Se.maxBatchRecordsPerPost, t.Ke + 1)), yield t.dt(l.length), i = null !== (o = t._instance.getPersistedProperty(w.LogsQueue)) && void 0 !== o ? o : [], s += l.length, "fatal" === h.kind) throw h.error;
				}
			}
		}))();
	}
	dt(t) {
		var e = this;
		return p((function* () {
			var i, r = Math.max(0, t - e.ze), s = null !== (i = e._instance.getPersistedProperty(w.LogsQueue)) && void 0 !== i ? i : [];
			e._instance.setPersistedProperty(w.LogsQueue, s.slice(r)), yield e.je();
		}))();
	}
	ut() {
		return Se(this.Se, this._instance.getLibraryId(), this._instance.getLibraryVersion());
	}
	st(t) {
		var e;
		if (!this._instance.optedOut) {
			var i = null !== (e = this._instance.getPersistedProperty(w.LogsQueue)) && void 0 !== e ? e : [];
			this.Je > i.length || (i.shift(), this.ze++, this.Ae.info("Logs queue is full, dropping oldest record.")), i.push(t), this._instance.setPersistedProperty(w.LogsQueue, i), this.Qe > i.length ? this.ct() : this.rt();
		}
	}
	ct(t) {
		void 0 === t && (t = this.Ye), this.vt || (this.vt = ge((() => {
			this.vt = void 0, this.rt();
		}), t));
	}
	ft() {
		var t = Math.min(Math.max(0, this.Ve - 1), 6);
		return this.Ye * Math.pow(2, t);
	}
	yt() {
		var t = this._instance.getPersistedProperty(w.LogsQueue);
		return !!t && t.length > 0;
	}
	shutdown(t) {
		var e = this;
		return p((function* () {
			e.tt();
			var i = e.flush().catch((() => {}));
			void 0 !== t ? yield Promise.race([i, new Promise(((e) => ge(e, t)))]) : yield i;
		}))();
	}
	flushWithTimeout(t) {
		var e = this;
		return p((function* () {
			var i = !1, r = e.flush(), s = new Promise(((e) => ge((() => {
				i = !0, e();
			}), t)));
			try {
				yield Promise.race([r, s]);
			} finally {
				i && r.catch((() => {}));
			}
		}))();
	}
	rt() {
		this.flush().then((() => {
			this.Ve = 0;
		}), ((t) => {
			this.Ve++, this.Ae.error("PostHog logs flush failed:", t);
		})).finally((() => {
			!this._instance.isDisabled && this.yt() && this.ct(this.ft());
		}));
	}
	tt() {
		this.vt && (clearTimeout(this.vt), this.vt = void 0);
	}
};
var ke, Re, Pe;
function Ie(t) {
	var e = globalThis._posthogChunkIds;
	if (e) {
		var i = Object.keys(e);
		return Pe && i.length === Re || (Re = i.length, Pe = i.reduce(((i, r) => {
			ke || (ke = {});
			var s = ke[r];
			if (s) i[s[0]] = s[1];
			else for (var n = t(r), o = n.length - 1; o >= 0; o--) {
				var a = n[o], l = null == a ? void 0 : a.filename, u = e[r];
				if (l && u) {
					i[l] = u, ke[r] = [l, u];
					break;
				}
			}
			return i;
		}), {})), Pe;
	}
}
var Oe = class {
	constructor(t, e, i) {
		void 0 === i && (i = []), this.coercers = t, this.stackParser = e, this.modifiers = i;
	}
	buildFromUnknown(t, e) {
		void 0 === e && (e = {});
		var i = e && e.mechanism || {
			handled: !0,
			type: "generic"
		}, r = this.buildCoercingContext(i, e, 0).apply(t), s = this.buildParsingContext(e), n = this.parseStacktrace(r, s);
		return {
			$exception_list: this.convertToExceptionList(n, i),
			$exception_level: "error"
		};
	}
	modifyFrames(t) {
		var e = this;
		return p((function* () {
			for (var i of t) i.stacktrace && i.stacktrace.frames && B(i.stacktrace.frames) && (i.stacktrace.frames = yield e.applyModifiers(i.stacktrace.frames));
			return t;
		}))();
	}
	coerceFallback(t) {
		var e;
		return {
			type: "Error",
			value: "Unknown error",
			stack: null == (e = t.syntheticException) ? void 0 : e.stack,
			synthetic: !0
		};
	}
	parseStacktrace(t, e) {
		var i, r;
		return null != t.cause && (i = this.parseStacktrace(t.cause, e)), "" != t.stack && null != t.stack && (r = this.applyChunkIds(this.stackParser(t.stack, t.synthetic ? e.skipFirstLines : 0), e.chunkIdMap)), f({}, t, {
			cause: i,
			stack: r
		});
	}
	applyChunkIds(t, e) {
		return t.map(((t) => (t.filename && e && (t.chunk_id = e[t.filename]), t)));
	}
	applyCoercers(t, e) {
		for (var i of this.coercers) if (i.match(t)) return i.coerce(t, e);
		return this.coerceFallback(e);
	}
	applyModifiers(t) {
		var e = this;
		return p((function* () {
			var i = t;
			for (var r of e.modifiers) i = yield r(i);
			return i;
		}))();
	}
	convertToExceptionList(t, e) {
		var i, r, s, n = {
			type: t.type,
			value: t.value,
			mechanism: {
				type: null !== (i = e.type) && void 0 !== i ? i : "generic",
				handled: null === (r = e.handled) || void 0 === r || r,
				synthetic: null !== (s = t.synthetic) && void 0 !== s && s
			}
		};
		t.stack && (n.stacktrace = {
			type: "raw",
			frames: t.stack
		});
		var o = [n];
		return null != t.cause && o.push(...this.convertToExceptionList(t.cause, f({}, e, { handled: !0 }))), o;
	}
	buildParsingContext(t) {
		var e;
		return {
			chunkIdMap: Ie(this.stackParser),
			skipFirstLines: null !== (e = t.skipFirstLines) && void 0 !== e ? e : 1
		};
	}
	buildCoercingContext(t, e, i) {
		void 0 === i && (i = 0);
		var r = (i, r) => {
			if (4 >= r) {
				var s = this.buildCoercingContext(t, e, r);
				return this.applyCoercers(i, s);
			}
		};
		return f({}, e, {
			syntheticException: 0 == i ? e.syntheticException : void 0,
			mechanism: t,
			apply: (t) => r(t, i),
			next: (t) => r(t, i + 1)
		});
	}
};
var Ce = "?";
function Ae(t, e, i, r, s) {
	var n = {
		platform: t,
		filename: e,
		function: "<anonymous>" === i ? Ce : i,
		in_app: !0
	};
	return V(r) || (n.lineno = r), V(s) || (n.colno = s), n;
}
var Fe = (t, e) => {
	var i = -1 !== t.indexOf("safari-extension"), r = -1 !== t.indexOf("safari-web-extension");
	return i || r ? [-1 !== t.indexOf("@") ? t.split("@")[0] : Ce, i ? "safari-extension:" + e : "safari-web-extension:" + e] : [t, e];
}, Me = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i, De = /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i, Le = /\((\S*)(?::(\d+))(?::(\d+))\)/, Ne = (t, e) => {
	var i = Me.exec(t);
	if (i) {
		var [, r, s, n] = i;
		return Ae(e, r, Ce, +s, +n);
	}
	var o = De.exec(t);
	if (o) {
		if (o[2] && 0 === o[2].indexOf("eval")) {
			var a = Le.exec(o[2]);
			a && (o[2] = a[1], o[3] = a[2], o[4] = a[3]);
		}
		var [l, u] = Fe(o[1] || Ce, o[2]);
		return Ae(e, u, l, o[3] ? +o[3] : void 0, o[4] ? +o[4] : void 0);
	}
}, Ue = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i, je = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i, Be = (t, e) => {
	var i = Ue.exec(t);
	if (i) {
		if (i[3] && i[3].indexOf(" > eval") > -1) {
			var r = je.exec(i[3]);
			r && (i[1] = i[1] || "eval", i[3] = r[1], i[4] = r[2], i[5] = "");
		}
		var s = i[3], n = i[1] || Ce;
		return [n, s] = Fe(n, s), Ae(e, s, n, i[4] ? +i[4] : void 0, i[5] ? +i[5] : void 0);
	}
}, ze = /\(error: (.*)\)/;
var He = class {
	match(t) {
		return this.isDOMException(t) || this.isDOMError(t);
	}
	coerce(t, e) {
		var i = G(t.stack);
		return {
			type: this.getType(t),
			value: this.getValue(t),
			stack: i ? t.stack : void 0,
			cause: t.cause ? e.next(t.cause) : void 0,
			synthetic: !1
		};
	}
	getType(t) {
		return this.isDOMError(t) ? "DOMError" : "DOMException";
	}
	getValue(t) {
		var e = t.name || (this.isDOMError(t) ? "DOMError" : "DOMException");
		return t.message ? e + ": " + t.message : e;
	}
	isDOMException(t) {
		return rt(t, "DOMException");
	}
	isDOMError(t) {
		return rt(t, "DOMError");
	}
};
var qe = class {
	match(t) {
		return ((t) => t instanceof Error)(t);
	}
	coerce(t, e) {
		return {
			type: this.getType(t),
			value: this.getMessage(t, e),
			stack: this.getStack(t),
			cause: t.cause ? e.next(t.cause) : void 0,
			synthetic: !1
		};
	}
	getType(t) {
		return t.name || t.constructor.name;
	}
	getMessage(t, e) {
		var i = t.message;
		return String(i.error && "string" == typeof i.error.message ? i.error.message : i);
	}
	getStack(t) {
		return t.stacktrace || t.stack || void 0;
	}
};
var Ve = class {
	constructor() {}
	match(t) {
		return rt(t, "ErrorEvent") && null != t.error;
	}
	coerce(t, e) {
		var i;
		return e.apply(t.error) || {
			type: "ErrorEvent",
			value: t.message,
			stack: null == (i = e.syntheticException) ? void 0 : i.stack,
			synthetic: !0
		};
	}
};
var Ge = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?(.*)$/i;
var We = class {
	match(t) {
		return "string" == typeof t;
	}
	coerce(t, e) {
		var i, [r, s] = this.getInfos(t);
		return {
			type: null != r ? r : "Error",
			value: null != s ? s : t,
			stack: null == (i = e.syntheticException) ? void 0 : i.stack,
			synthetic: !0
		};
	}
	getInfos(t) {
		var e = "Error", i = t, r = t.match(Ge);
		return r && (e = r[1], i = r[2]), [e, i];
	}
};
var Ye = [
	"fatal",
	"error",
	"warning",
	"log",
	"info",
	"debug"
];
function Ke(t, e) {
	void 0 === e && (e = 40);
	var i = Object.keys(t);
	if (i.sort(), !i.length) return "[object has no keys]";
	for (var r = i.length; r > 0; r--) {
		var s = i.slice(0, r).join(", ");
		if (e >= s.length) return r === i.length ? s : s.length > e ? s.slice(0, e) + "..." : s;
	}
	return "";
}
var Je = class {
	match(t) {
		return "object" == typeof t && null !== t;
	}
	coerce(t, e) {
		var i, r = this.getErrorPropertyFromObject(t);
		return r ? e.apply(r) : {
			type: this.getType(t),
			value: this.getValue(t),
			stack: null == (i = e.syntheticException) ? void 0 : i.stack,
			level: this.isSeverityLevel(t.level) ? t.level : "error",
			synthetic: !0
		};
	}
	getType(t) {
		return st(t) ? t.constructor.name : "Error";
	}
	getValue(t) {
		if ("name" in t && "string" == typeof t.name) {
			var e = "'" + t.name + "' captured as exception";
			return "message" in t && "string" == typeof t.message && (e += " with message: '" + t.message + "'"), e;
		}
		if ("message" in t && "string" == typeof t.message) return t.message;
		var i = this.getObjectClassName(t);
		return (i && "Object" !== i ? "'" + i + "'" : "Object") + " captured as exception with keys: " + Ke(t);
	}
	isSeverityLevel(t) {
		return G(t) && !W(t) && Ye.indexOf(t) >= 0;
	}
	getErrorPropertyFromObject(t) {
		for (var e in t) if ({}.hasOwnProperty.call(t, e)) {
			var i = t[e];
			if (me(i)) return i;
		}
	}
	getObjectClassName(t) {
		try {
			var e = Object.getPrototypeOf(t);
			return e ? e.constructor.name : void 0;
		} catch (t) {
			return;
		}
	}
};
var Qe = class {
	match(t) {
		return st(t);
	}
	coerce(t, e) {
		var i, r = t.constructor.name;
		return {
			type: r,
			value: r + " captured as exception with keys: " + Ke(t),
			stack: null == (i = e.syntheticException) ? void 0 : i.stack,
			synthetic: !0
		};
	}
};
var Xe = class {
	match(t) {
		return it(t);
	}
	coerce(t, e) {
		var i;
		return {
			type: "Error",
			value: "Primitive value captured as exception: " + String(t),
			stack: null == (i = e.syntheticException) ? void 0 : i.stack,
			synthetic: !0
		};
	}
};
var Ze = class {
	match(t) {
		return rt(t, "PromiseRejectionEvent") || this.isCustomEventWrappingRejection(t);
	}
	isCustomEventWrappingRejection(t) {
		if (!st(t)) return !1;
		try {
			var e = t.detail;
			return null != e && "object" == typeof e && "reason" in e;
		} catch (t) {
			return !1;
		}
	}
	coerce(t, e) {
		var i, r = this.getUnhandledRejectionReason(t);
		return it(r) ? {
			type: "UnhandledRejection",
			value: "Non-Error promise rejection captured with value: " + String(r),
			stack: null == (i = e.syntheticException) ? void 0 : i.stack,
			synthetic: !0
		} : e.apply(r);
	}
	getUnhandledRejectionReason(t) {
		try {
			if ("reason" in t) return t.reason;
			if ("detail" in t && null != t.detail && "object" == typeof t.detail && "reason" in t.detail) return t.detail.reason;
		} catch (t) {}
		return t;
	}
};
var ti = "$message", ei = "$timestamp", ii = /* @__PURE__ */ new Set([ti, ei]), ri = {
	enabled: !0,
	max_bytes: 32768
};
function si(t) {
	var e;
	return t ? {
		enabled: null !== (e = t.enabled) && void 0 !== e ? e : ri.enabled,
		max_bytes: oi(t.max_bytes, ri.max_bytes)
	} : f({}, ri);
}
var ni = class {
	constructor(t) {
		this.bt = [], this._t = 0, this.Se = si(t);
	}
	setConfig(t) {
		this.Se = si(t), this.wt();
	}
	add(t) {
		var e = function(t) {
			var e, i, r;
			try {
				r = [], e = null !== (i = JSON.stringify(t, (function(t, e) {
					if ("bigint" == typeof e) return e.toString();
					if ("function" != typeof e && "symbol" != typeof e) {
						if (e instanceof Error) return {
							name: e.name,
							message: e.message,
							stack: e.stack
						};
						if (e && "object" == typeof e) {
							for (; r.length > 0 && r[r.length - 1] !== this;) r.pop();
							if (r.includes(e)) return "[Circular]";
							r.push(e);
						}
						return e;
					}
				}))) && void 0 !== i ? i : "null";
			} catch (t) {
				return;
			}
			try {
				var s = JSON.parse(e);
				if (!H(s)) return;
				var n = s, o = n[ti], a = n[ei];
				if (!G(o) || 0 === o.trim().length) return;
				if (!G(a) && !J(a)) return;
				return {
					step: n,
					json: e
				};
			} catch (t) {
				return;
			}
		}(t);
		if (e) {
			var i = function(t) {
				if ("undefined" != typeof TextEncoder) return new TextEncoder().encode(t).length;
				for (var e = encodeURIComponent(t), i = 0, r = 0; e.length > r; r++) "%" === e[r] ? (i += 1, r += 2) : i += 1;
				return i;
			}(e.json);
			i > this.Se.max_bytes || (this.bt.push({
				step: e.step,
				bytes: i
			}), this._t += i, this.wt());
		}
	}
	getAttachable() {
		return this.bt.map(((t) => t.step));
	}
	clear() {
		this.bt = [], this._t = 0;
	}
	size() {
		return this.bt.length;
	}
	wt() {
		for (; this._t > this.Se.max_bytes && this.bt.length > 0;) {
			var t = this.bt.shift();
			t && (this._t -= t.bytes);
		}
	}
};
function oi(t, e) {
	if (!J(t) || t === Infinity || t === -Infinity) return e;
	var i = Math.floor(t);
	return 0 > i ? e : i;
}
var ai = function(e, i) {
	var { debugEnabled: r } = void 0 === i ? {} : i, s = {
		k(i) {
			if (t && (v.DEBUG || h.POSTHOG_DEBUG || r) && !V(t.console) && t.console) {
				for (var s = ("__rrweb_original__" in t.console[i]) ? t.console[i].__rrweb_original__ : t.console[i], n = arguments.length, o = new Array(n > 1 ? n - 1 : 0), a = 1; n > a; a++) o[a - 1] = arguments[a];
				s(e, ...o);
			}
		},
		debug() {
			for (var t = arguments.length, e = new Array(t), i = 0; t > i; i++) e[i] = arguments[i];
			s.k("debug", ...e);
		},
		info() {
			for (var t = arguments.length, e = new Array(t), i = 0; t > i; i++) e[i] = arguments[i];
			s.k("log", ...e);
		},
		warn() {
			for (var t = arguments.length, e = new Array(t), i = 0; t > i; i++) e[i] = arguments[i];
			s.k("warn", ...e);
		},
		error() {
			for (var t = arguments.length, e = new Array(t), i = 0; t > i; i++) e[i] = arguments[i];
			s.k("error", ...e);
		},
		critical() {
			for (var t = arguments.length, i = new Array(t), r = 0; t > r; r++) i[r] = arguments[r];
			console.error(e, ...i);
		},
		uninitializedWarning(t) {
			s.error("You must initialize PostHog before calling " + t);
		},
		createLogger: (t, i) => ai(e + " " + t, i)
	};
	return s;
}, li = ai("[PostHog.js]"), ui = li.createLogger, hi = ui("[ExternalScriptsLoader]"), di = (t, e, i) => {
	if (t.config.disable_external_dependency_loading) return hi.warn(e + " was requested but loading of external scripts is disabled."), i("Loading of external scripts is disabled");
	var s = null == r ? void 0 : r.querySelectorAll("script");
	if (s) {
		for (var n, o = function() {
			if (s[a].src === e) {
				var t = s[a];
				return t.__posthog_loading_callback_fired ? { v: i() } : (t.addEventListener("load", ((e) => {
					t.__posthog_loading_callback_fired = !0, i(void 0, e);
				})), t.onerror = (t) => i(t), { v: void 0 });
			}
		}, a = 0; s.length > a; a++) if (n = o()) return n.v;
	}
	var l = () => {
		if (!r) return i("document not found");
		var s = r.createElement("script");
		if (s.type = "text/javascript", s.crossOrigin = "anonymous", s.src = e, s.onload = (t) => {
			s.__posthog_loading_callback_fired = !0, i(void 0, t);
		}, s.onerror = (t) => i(t), t.config.prepare_external_dependency_script && (s = t.config.prepare_external_dependency_script(s)), !s) return i("prepare_external_dependency_script returned null");
		if ("head" === t.config.external_scripts_inject_target) r.head.appendChild(s);
		else {
			var n, o = r.querySelectorAll("body > script");
			o.length > 0 ? null == (n = o[0].parentNode) || n.insertBefore(s, o[0]) : r.body.appendChild(s);
		}
	};
	null != r && r.body ? l() : r?.addEventListener("DOMContentLoaded", l);
};
h.__PosthogExtensions__ = h.__PosthogExtensions__ || {}, h.__PosthogExtensions__.loadExternalDependency = (t, e, i) => {
	if ("remote-config" !== e) {
		var r;
		if (t.config.strict_script_versioning) r = t.requestRouter.endpointFor("assets", "/static/" + t.version + "/" + e + ".js");
		else {
			var s = "/static/" + e + ".js?v=" + t.version;
			if ("toolbar" === e) {
				var n = 3e5;
				s = s + "&t=" + Math.floor(Date.now() / n) * n;
			}
			r = t.requestRouter.endpointFor("assets", s);
		}
		di(t, r, i);
	} else di(t, t.requestRouter.endpointFor("assets", "/array/" + t.config.token + "/config.js"), i);
}, h.__PosthogExtensions__.loadSiteApp = (t, e, i) => {
	di(t, t.requestRouter.endpointFor("api", e), i);
};
var vi = "$people_distinct_id", ci = "$device_id", pi = "$device_model", fi = "__alias", _i = "__timers", gi = "$autocapture_disabled_server_side", mi = "$heatmaps_enabled_server_side", yi = "$exception_capture_enabled_server_side", bi = "$error_tracking_suppression_rules", wi = "$error_tracking_capture_extension_exceptions", Ei = "$web_vitals_enabled_server_side", xi = "$dead_clicks_enabled_server_side", Si = "$product_tours_enabled_server_side", Ti = "$web_vitals_allowed_metrics", $i = "$session_recording_remote_config", ki = "$replay_sample_rate", Ri = "$replay_override_sampling", Pi = "$replay_override_linked_flag", Ii = "$replay_override_url_trigger", Oi = "$replay_override_event_trigger", Ci = "$sesid", Ai = "$session_is_sampled", Fi = "$enabled_feature_flags", Mi = "$active_feature_flags", Di = "$early_access_features", Li = "$feature_flag_details", Ni = "$feature_flag_payloads", Ui = "$feature_flag_request_id", ji = "$override_feature_flags", Bi = "$override_feature_flag_payloads", zi = "$stored_person_properties", Hi = "$stored_group_properties", qi = "$surveys", Vi = "$surveys_loaded_at", Gi = "$surveys_activated", Wi = "ph_product_tours", Yi = "$flag_call_reported", Ki = "$flag_call_reported_session_id", Ji = "$feature_flag_errors", Qi = "$feature_flag_evaluated_at", Xi = "$user_state", Zi = "$client_session_props", tr = "$capture_rate_limit", er = "$initial_campaign_params", ir = "$initial_referrer_info", rr = "$initial_person_info", sr = "$epp", nr = "__POSTHOG_TOOLBAR__", or = "$posthog_cookieless", ar = "$sdk_debug_extensions_init_method", lr = "$sdk_debug_extensions_init_time_ms", ur = "$sdk_debug_recording_script_not_loaded", hr = "PostHog loadExternalDependency extension not found.", dr = "on_reject", vr = "always", cr = "anonymous", pr = "identified", fr = "identified_only", _r = "visibilitychange", gr = "beforeunload", mr = "$pageview", yr = "$pageleave", br = "$identify", wr = "$groupidentify";
function Er(t, e) {
	B(t) && t.forEach(e);
}
function xr(t, e) {
	if (!K(t)) if (B(t)) t.forEach(e);
	else if (Z(t)) t.forEach(((t, i) => e(t, i)));
	else for (var i in t) U.call(t, i) && e(t[i], i);
}
var Sr = function(t) {
	for (var e = arguments.length, i = new Array(e > 1 ? e - 1 : 0), r = 1; e > r; r++) i[r - 1] = arguments[r];
	for (var s of i) for (var n in s) void 0 !== s[n] && (t[n] = s[n]);
	return t;
};
function Tr(t) {
	for (var e = Object.keys(t), i = e.length, r = new Array(i); i--;) r[i] = [e[i], t[e[i]]];
	return r;
}
var $r = function(t) {
	try {
		return t();
	} catch (t) {
		return;
	}
}, kr = function(t) {
	return function() {
		try {
			for (var e = arguments.length, i = new Array(e), r = 0; e > r; r++) i[r] = arguments[r];
			return t.apply(this, i);
		} catch (t) {
			li.critical("Implementation error. Please turn on debug mode and open a ticket on https://app.posthog.com/home#panel=support%3Asupport%3A."), li.critical(t);
		}
	};
}, Rr = function(t) {
	var e = {};
	return xr(t, (function(t, i) {
		(G(t) && t.length > 0 || J(t)) && (e[i] = t);
	})), e;
};
var Pr = [
	"herokuapp.com",
	"vercel.app",
	"netlify.app"
];
function Ir(t) {
	var e = null == t ? void 0 : t.hostname;
	if (!G(e)) return !1;
	var i = e.split(".").slice(-2).join(".");
	for (var r of Pr) if (i === r) return !1;
	return !0;
}
function Or(t, e, i, r) {
	var { capture: s = !1, passive: n = !0 } = null != r ? r : {};
	t?.addEventListener(e, i, {
		capture: s,
		passive: n
	});
}
function Cr(t) {
	return "ph_toolbar_internal" === t.name;
}
Math.trunc || (Math.trunc = function(t) {
	return 0 > t ? Math.ceil(t) : Math.floor(t);
}), Number.isInteger || (Number.isInteger = function(t) {
	return J(t) && isFinite(t) && Math.floor(t) === t;
});
var Ar = class Ar {
	constructor(t) {
		if (this.bytes = t, 16 !== t.length) throw new TypeError("not 128-bit length");
	}
	static fromFieldsV7(t, e, i, r) {
		if (!Number.isInteger(t) || !Number.isInteger(e) || !Number.isInteger(i) || !Number.isInteger(r) || 0 > t || 0 > e || 0 > i || 0 > r || t > 0xffffffffffff || e > 4095 || i > 1073741823 || r > 4294967295) throw new RangeError("invalid field value");
		var s = /* @__PURE__ */ new Uint8Array(16);
		return s[0] = t / Math.pow(2, 40), s[1] = t / Math.pow(2, 32), s[2] = t / Math.pow(2, 24), s[3] = t / Math.pow(2, 16), s[4] = t / Math.pow(2, 8), s[5] = t, s[6] = 112 | e >>> 8, s[7] = e, s[8] = 128 | i >>> 24, s[9] = i >>> 16, s[10] = i >>> 8, s[11] = i, s[12] = r >>> 24, s[13] = r >>> 16, s[14] = r >>> 8, s[15] = r, new Ar(s);
	}
	toString() {
		for (var t = "", e = 0; this.bytes.length > e; e++) t = t + (this.bytes[e] >>> 4).toString(16) + (15 & this.bytes[e]).toString(16), 3 !== e && 5 !== e && 7 !== e && 9 !== e || (t += "-");
		if (36 !== t.length) throw new Error("Invalid UUIDv7 was generated");
		return t;
	}
	clone() {
		return new Ar(this.bytes.slice(0));
	}
	equals(t) {
		return 0 === this.compareTo(t);
	}
	compareTo(t) {
		for (var e = 0; 16 > e; e++) {
			var i = this.bytes[e] - t.bytes[e];
			if (0 !== i) return Math.sign(i);
		}
		return 0;
	}
};
var Fr = class {
	constructor() {
		this.S = 0, this.C = 0, this.I = new Lr();
	}
	generate() {
		var t = this.generateOrAbort();
		if (V(t)) {
			this.S = 0;
			var e = this.generateOrAbort();
			if (V(e)) throw new Error("Could not generate UUID after timestamp reset");
			return e;
		}
		return t;
	}
	generateOrAbort() {
		var t = Date.now();
		if (t > this.S) this.S = t, this.M();
		else {
			if (this.S >= t + 1e4) return;
			this.C++, this.C > 4398046511103 && (this.S++, this.M());
		}
		return Ar.fromFieldsV7(this.S, Math.trunc(this.C / Math.pow(2, 30)), this.C & Math.pow(2, 30) - 1, this.I.nextUint32());
	}
	M() {
		this.C = 1024 * this.I.nextUint32() + (1023 & this.I.nextUint32());
	}
};
var Mr, Dr = (t) => {
	if ("undefined" != typeof UUIDV7_DENY_WEAK_RNG && UUIDV7_DENY_WEAK_RNG) throw new Error("no cryptographically strong RNG available");
	for (var e = 0; t.length > e; e++) t[e] = 65536 * Math.trunc(65536 * Math.random()) + Math.trunc(65536 * Math.random());
	return t;
};
t && !V(t.crypto) && crypto.getRandomValues && (Dr = (t) => crypto.getRandomValues(t));
var Lr = class {
	constructor() {
		this.R = /* @__PURE__ */ new Uint32Array(8), this.O = Infinity;
	}
	nextUint32() {
		return this.R.length > this.O || (Dr(this.R), this.O = 0), this.R[this.O++];
	}
};
var Nr = () => Ur().toString(), Ur = () => (Mr || (Mr = new Fr())).generate(), jr = "", Br = /[a-z0-9][a-z0-9-]+\.[a-z]{2,}$/i;
var zr = {
	N: () => !!r,
	D(t) {
		li.error("cookieStore error: " + t);
	},
	A(t) {
		if (r) {
			try {
				for (var e = t + "=", i = r.cookie.split(";").filter(((t) => t.length)), s = 0; i.length > s; s++) {
					for (var n = i[s]; " " == n.charAt(0);) n = n.substring(1, n.length);
					if (0 === n.indexOf(e)) return decodeURIComponent(n.substring(e.length, n.length));
				}
			} catch (t) {}
			return null;
		}
	},
	F(t) {
		var e;
		try {
			e = JSON.parse(zr.A(t)) || {};
		} catch (t) {}
		return e;
	},
	q(t, e, i, s, n) {
		if (!r) return !1;
		try {
			var o = "", a = "", l = function(t, e) {
				if (e) {
					var i = function(t, e) {
						if (void 0 === e && (e = r), jr) return jr;
						if (!e) return "";
						if (["localhost", "127.0.0.1"].includes(t)) return "";
						for (var i = t.split("."), s = Math.min(i.length, 8), n = "dmn_chk_" + Nr(); !jr && s--;) {
							var o = i.slice(s).join("."), a = n + "=1;domain=." + o + ";path=/";
							e.cookie = a + ";max-age=3", e.cookie.includes(n) && (e.cookie = a + ";max-age=0", jr = o);
						}
						return jr;
					}(t);
					if (!i) {
						var s = ((t) => {
							var e = t.match(Br);
							return e ? e[0] : "";
						})(t);
						s !== i && li.info("Warning: cookie subdomain discovery mismatch", s, i), i = s;
					}
					return i ? "; domain=." + i : "";
				}
				return "";
			}(r.location.hostname, s);
			if (i) {
				var u = /* @__PURE__ */ new Date();
				u.setTime(u.getTime() + 864e5 * i), o = "; expires=" + u.toUTCString();
			}
			n && (a = "; secure");
			var h = t + "=" + encodeURIComponent(JSON.stringify(e)) + o + "; SameSite=Lax; path=/" + l + a;
			return h.length > 3686.4 && li.warn("cookieStore warning: large cookie, len=" + h.length), r.cookie = h, !0;
		} catch (t) {
			return !1;
		}
	},
	P(t, e) {
		if (null != r && r.cookie) try {
			zr.q(t, "", -1, e);
		} catch (t) {
			return;
		}
	}
}, Hr = null, qr = {
	N() {
		if (!Y(Hr)) return Hr;
		var e = !0;
		if (V(t)) e = !1;
		else try {
			var i = "__mplssupport__";
			qr.q(i, "xyz"), "\"xyz\"" !== qr.A(i) && (e = !1), qr.P(i);
		} catch (t) {
			e = !1;
		}
		return e || li.error("localStorage unsupported; falling back to cookie store"), Hr = e, e;
	},
	D(t) {
		li.error("localStorage error: " + t);
	},
	A(e) {
		try {
			return null == t ? void 0 : t.localStorage.getItem(e);
		} catch (t) {
			qr.D(t);
		}
		return null;
	},
	F(t) {
		try {
			return JSON.parse(qr.A(t)) || {};
		} catch (t) {}
		return null;
	},
	q(e, i) {
		try {
			return t?.localStorage.setItem(e, JSON.stringify(i)), !0;
		} catch (t) {
			qr.D(t);
		}
		return !1;
	},
	P(e) {
		try {
			t?.localStorage.removeItem(e);
		} catch (t) {
			qr.D(t);
		}
	}
}, Vr = [
	ci,
	"distinct_id",
	Ci,
	Ai,
	sr,
	rr,
	Xi
], Gr = {}, Wr = {
	N: () => !0,
	D(t) {
		li.error("memoryStorage error: " + t);
	},
	A: (t) => Gr[t] || null,
	F: (t) => Gr[t] || null,
	q: (t, e) => (Gr[t] = e, !0),
	P(t) {
		delete Gr[t];
	}
}, Yr = null, Kr = {
	N() {
		if (!Y(Yr)) return Yr;
		if (Yr = !0, V(t)) Yr = !1;
		else try {
			var e = "__support__";
			Kr.q(e, "xyz"), "\"xyz\"" !== Kr.A(e) && (Yr = !1), Kr.P(e);
		} catch (t) {
			Yr = !1;
		}
		return Yr;
	},
	D(t) {
		li.error("sessionStorage error: ", t);
	},
	A(e) {
		try {
			return null == t ? void 0 : t.sessionStorage.getItem(e);
		} catch (t) {
			Kr.D(t);
		}
		return null;
	},
	F(t) {
		try {
			return JSON.parse(Kr.A(t)) || null;
		} catch (t) {}
		return null;
	},
	q(e, i) {
		try {
			return t?.sessionStorage.setItem(e, JSON.stringify(i)), !0;
		} catch (t) {
			Kr.D(t);
		}
		return !1;
	},
	P(e) {
		try {
			t?.sessionStorage.removeItem(e);
		} catch (t) {
			Kr.D(t);
		}
	}
};
var Jr = class {
	constructor(t) {
		this._instance = t;
	}
	get Se() {
		return this._instance.config;
	}
	get consent() {
		return this.kt() ? 0 : this.St;
	}
	isOptedOut() {
		return this.Se.cookieless_mode === vr || this.isRejected() || -1 === this.consent && this.Se.cookieless_mode === dr;
	}
	isOptedIn() {
		return !this.isOptedOut();
	}
	isExplicitlyOptedOut() {
		return 0 === this.consent;
	}
	isRejected() {
		return 0 === this.consent || -1 === this.consent && this.Se.opt_out_capturing_by_default;
	}
	optInOut(t) {
		this.Ct.q(this.It, t ? 1 : 0, this.Se.cookie_expiration, this.Se.cross_subdomain_cookie, this.Se.secure_cookie);
	}
	reset() {
		this.Ct.P(this.It, this.Se.cross_subdomain_cookie);
	}
	get It() {
		var { token: t, opt_out_capturing_cookie_prefix: e, consent_persistence_name: i } = this._instance.config;
		return i || (e ? e + t : "__ph_opt_in_out_" + t);
	}
	get St() {
		var t = this.Ct.A(this.It);
		return ot(t) ? 1 : M(at, t) ? 0 : -1;
	}
	get Ct() {
		var t = this.Se.opt_out_capturing_persistence_type, e = "localStorage" === t ? qr : zr;
		if (!this.Tt || this.Tt !== e) {
			this.Tt = e;
			var i = "localStorage" === t ? zr : qr;
			i.A(this.It) && (this.Tt.A(this.It) || this.optInOut(ot(i.A(this.It))), i.P(this.It, this.Se.cross_subdomain_cookie));
		}
		return this.Tt;
	}
	kt() {
		return !!this.Se.respect_dnt && [
			null == i ? void 0 : i.doNotTrack,
			null == i ? void 0 : i.msDoNotTrack,
			h.doNotTrack
		].some(((t) => ot(t)));
	}
};
function Qr(t, e) {
	var i, r = null == t || null == (i = t.config) ? void 0 : i.get_current_url;
	if (!z(r)) return e;
	try {
		var s = r(e);
		return G(s) && s ? s : e;
	} catch (t) {
		return li.error("Error in get_current_url, falling back to window.location.href", t), e;
	}
}
var Xr = 1, Zr = 3, ts = 11;
function es(t) {
	return t instanceof Element && (t.id === nr || !(null == t.closest || !t.closest(".toolbar-global-fade-container")));
}
function is(t) {
	return !!t && t.nodeType === Xr;
}
function rs(t, e) {
	return !!t && !!t.tagName && t.tagName.toLowerCase() === e.toLowerCase();
}
function ss(t) {
	return !!t && t.nodeType === Zr;
}
function ns(t) {
	return !!t && t.nodeType === ts && is(t.host);
}
function os(t) {
	return t ? D(t).split(/\s+/) : [];
}
function as(e, i) {
	var r = function(e) {
		var i, r = null == t || null == (i = t.location) ? void 0 : i.href;
		return V(r) ? void 0 : Qr(e, r);
	}(i);
	return !!(r && e && e.some(((t) => r.match(t))));
}
function ls(t) {
	var e = "";
	switch (typeof t.className) {
		case "string":
			e = t.className;
			break;
		case "object":
			e = (t.className && "baseVal" in t.className ? t.className.baseVal : null) || t.getAttribute("class") || "";
			break;
		default: e = "";
	}
	return os(e);
}
function us(t) {
	return K(t) ? null : D(t).split(/(\s+)/).filter(((t) => Cs(t))).join("").replace(/[\r\n]/g, " ").replace(/[ ]+/g, " ").substring(0, 255);
}
function hs(t) {
	var e = "";
	return Ss(t) && !Ts(t) && t.childNodes && t.childNodes.length && xr(t.childNodes, (function(t) {
		var i;
		ss(t) && t.textContent && (e += null !== (i = us(t.textContent)) && void 0 !== i ? i : "");
	})), D(e);
}
function ds(t) {
	return V(t.target) ? t.srcElement || null : null != (e = t.target) && e.shadowRoot ? t.composedPath()[0] || null : t.target || null;
	var e;
}
var vs = [
	"a",
	"button",
	"form",
	"input",
	"select",
	"textarea",
	"label"
];
function cs(t, e) {
	if (V(e)) return !0;
	var i, r = function(t) {
		if (e.some(((e) => function(t, e) {
			var i = t.matches || t.matchesSelector || t.msMatchesSelector || t.mozMatchesSelector || t.webkitMatchesSelector || t.oMatchesSelector;
			try {
				return !!i && i.call(t, e);
			} catch (t) {
				return !1;
			}
		}(t, e)))) return { v: !0 };
	};
	for (var s of t) if (i = r(s)) return i.v;
	return !1;
}
function ps(t) {
	var e = t.parentNode;
	return !(!e || !is(e)) && e;
}
var fs = [".ph-no-autocapture", "[data-ph-no-autocapture]"], _s = [
	"next",
	"previous",
	"prev",
	">",
	"<"
], gs = [
	..._s,
	"+",
	"-",
	"−",
	"–"
], ms = (t, e) => /[a-z0-9]/i.test(e) ? t.includes(e) : t === e, ys = [".ph-no-rageclick", ".ph-no-capture"], bs = [
	"",
	"text",
	"search",
	"email",
	"password",
	"url",
	"tel",
	"number"
];
function ws(e, i) {
	if (!t || Es(e)) return !1;
	var r, s, n, o, a;
	if (X(i) ? (r = !!i && ys, s = void 0, n = !1) : (r = null !== (o = null == i ? void 0 : i.css_selector_ignorelist) && void 0 !== o ? o : ys, s = null == i ? void 0 : i.content_ignorelist, n = null !== (a = null == i ? void 0 : i.ignore_text_selection) && void 0 !== a && a), !1 === r) return !1;
	if (n && function(t) {
		return !(!t || !is(t)) && (!!rs(t, "textarea") || (rs(t, "input") ? M(bs, (t.getAttribute("type") || "").toLowerCase()) : function(t) {
			if (t.isContentEditable) return !0;
			var e = null == t.getAttribute ? void 0 : t.getAttribute("contenteditable");
			return "true" === e || "" === e;
		}(t)));
	}(e)) return !1;
	var { targetElementList: l } = xs(e, !1);
	return !function(t, e) {
		if (!1 === t || V(t)) return !1;
		var i;
		if (!0 === t) i = _s;
		else {
			if (!B(t)) return !1;
			if (t.length > 10) return li.error("[PostHog] content_ignorelist array cannot exceed 10 items. Use css_selector_ignorelist for more complex matching."), !1;
			i = t.map(((t) => t.toLowerCase()));
		}
		return e.some(((t) => {
			var { safeText: e, ariaLabel: r } = t;
			return i.some(((t) => ms(e, t) || ms(r, t)));
		}));
	}(s, l.map(((t) => {
		var e;
		return {
			safeText: hs(t).toLowerCase(),
			ariaLabel: (null == (e = t.getAttribute("aria-label")) ? void 0 : e.toLowerCase().trim()) || ""
		};
	}))) && !cs(l, r);
}
var Es = (t) => !t || rs(t, "html") || !is(t), xs = (e, i) => {
	if (!t || Es(e)) return {
		parentIsUsefulElement: !1,
		targetElementList: []
	};
	for (var r = !1, s = [e], n = e; n.parentNode && !rs(n, "body");) if (ns(n.parentNode)) s.push(n.parentNode.host), n = n.parentNode.host;
	else {
		var o = ps(n);
		if (!o) break;
		if (i || vs.indexOf(o.tagName.toLowerCase()) > -1) r = !0;
		else try {
			var a = t.getComputedStyle(o);
			a && "pointer" === a.getPropertyValue("cursor") && (r = !0);
		} catch (t) {}
		s.push(o), n = o;
	}
	return {
		parentIsUsefulElement: r,
		targetElementList: s
	};
};
function Ss(t) {
	for (var e = t; e.parentNode && !rs(e, "body"); e = e.parentNode) {
		var i = ls(e);
		if (M(i, "ph-sensitive") || M(i, "ph-no-capture")) return !1;
	}
	if (M(ls(t), "ph-include")) return !0;
	var r = t.type || "";
	if (G(r)) switch (r.toLowerCase()) {
		case "hidden":
		case "password": return !1;
	}
	var s = t.name || t.id || "";
	return !G(s) || !/^cc|cardnum|ccnum|creditcard|csc|cvc|cvv|exp|pass|pwd|routing|seccode|securitycode|securitynum|socialsec|socsec|ssn/i.test(s.replace(/[^a-zA-Z0-9]/g, ""));
}
function Ts(t) {
	return !!(rs(t, "input") && ![
		"button",
		"checkbox",
		"submit",
		"reset"
	].includes(t.type) || rs(t, "select") || rs(t, "textarea") || "true" === t.getAttribute("contenteditable"));
}
var $s = "(4[0-9]{12}(?:[0-9]{3})?)|(5[1-5][0-9]{14})|(6(?:011|5[0-9]{2})[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|((?:2131|1800|35[0-9]{3})[0-9]{11})", ks = new RegExp("^(?:" + $s + ")$"), Rs = new RegExp($s), Ps = "\\d{3}-?\\d{2}-?\\d{4}", Is = new RegExp("^(" + Ps + ")$"), Os = new RegExp("(" + Ps + ")");
function Cs(t, e) {
	if (void 0 === e && (e = !0), K(t)) return !1;
	if (G(t)) {
		if (t = D(t), (e ? ks : Rs).test((t || "").replace(/[- ]/g, ""))) return !1;
		if ((e ? Is : Os).test(t)) return !1;
	}
	return !0;
}
function As(t) {
	var e = hs(t);
	return Cs(e = (e + " " + Fs(t)).trim()) ? e : "";
}
function Fs(t) {
	var e = "";
	return t && t.childNodes && t.childNodes.length && xr(t.childNodes, (function(t) {
		var i;
		if (t && "span" === (null == (i = t.tagName) ? void 0 : i.toLowerCase())) try {
			var r = hs(t);
			e = (e + " " + r).trim(), t.childNodes && t.childNodes.length && (e = (e + " " + Fs(t)).trim());
		} catch (t) {
			li.error("[AutoCapture]", t);
		}
	})), e;
}
function Ms(t) {
	return t.replace(/"|\\"/g, "\\\"");
}
function Ds(t) {
	var e = t.attr__class;
	return e ? B(e) ? e : os(e) : void 0;
}
var Ls = ui("[Dead Clicks]"), Ns = () => !0, Us = (t) => {
	var e, i = !(null == (e = t.instance.persistence) || !e.get_property(xi)), r = t.instance.config.capture_dead_clicks;
	return X(r) ? r : !!H(r) || i;
};
var js = class {
	get lazyLoadedDeadClicksAutocapture() {
		return this.Et;
	}
	constructor(t, e, i) {
		this.instance = t, this.isEnabled = e, this.onCapture = i, this.startIfEnabledOrStop();
	}
	onRemoteConfig(t) {
		"captureDeadClicks" in t && (this.instance.persistence && this.instance.persistence.register({ [xi]: t.captureDeadClicks }), this.startIfEnabledOrStop());
	}
	startIfEnabledOrStop() {
		this.isEnabled(this) ? this.Mt((() => {
			this.Pt();
		})) : this.stop();
	}
	Mt(t) {
		var e, i;
		null != (e = h.__PosthogExtensions__) && e.initDeadClicksAutocapture ? t() : null == (i = h.__PosthogExtensions__) || null == i.loadExternalDependency || i.loadExternalDependency(this.instance, "dead-clicks-autocapture", ((e) => {
			e ? Ls.error("failed to load script", e) : t();
		}));
	}
	Pt() {
		var t;
		if (r) {
			if (!this.Et && null != (t = h.__PosthogExtensions__) && t.initDeadClicksAutocapture) {
				var e = H(this.instance.config.capture_dead_clicks) ? this.instance.config.capture_dead_clicks : {};
				e.__onCapture = this.onCapture, this.Et = h.__PosthogExtensions__.initDeadClicksAutocapture(this.instance, e), this.Et.start(r), Ls.info("starting...");
			}
		} else Ls.error("`document` not found. Cannot start.");
	}
	stop() {
		this.Et && (this.Et.stop(), this.Et = void 0, Ls.info("stopping..."));
	}
};
var Bs = ui("[SegmentIntegration]");
var zs = "posthog-js";
function Hs(t, e) {
	var { organization: i, projectId: r, prefix: s, severityAllowList: n = ["error"], sendExceptionsToPostHog: o = !0 } = void 0 === e ? {} : e;
	return (e) => {
		var a, l, u, h, d;
		if ("*" !== n && !n.includes(e.level) || !t.__loaded) return e;
		e.tags || (e.tags = {});
		var v = t.requestRouter.endpointFor("ui", "/project/" + t.config.token + "/person/" + t.get_distinct_id());
		e.tags["PostHog Person URL"] = v, t.sessionRecordingStarted() && (e.tags["PostHog Recording URL"] = t.get_session_replay_url({ withTimestamp: !0 }));
		var c, p = (null == (a = e.exception) ? void 0 : a.values) || [], _ = p.map(((t) => f({}, t, { stacktrace: t.stacktrace ? f({}, t.stacktrace, {
			type: "raw",
			frames: (t.stacktrace.frames || []).map(((t) => f({}, t, { platform: "web:javascript" })))
		}) : void 0 }))), g = {
			$exception_message: (null == (l = p[0]) ? void 0 : l.value) || e.message,
			$exception_type: null == (u = p[0]) ? void 0 : u.type,
			$exception_level: e.level,
			$exception_list: _,
			$sentry_event_id: e.event_id,
			$sentry_exception: e.exception,
			$sentry_exception_message: (null == (h = p[0]) ? void 0 : h.value) || e.message,
			$sentry_exception_type: null == (d = p[0]) ? void 0 : d.type,
			$sentry_tags: e.tags
		};
		return i && r && (g.$sentry_url = (s || "https://sentry.io/organizations/") + i + "/issues/?project=" + r + "&query=" + e.event_id), o && (null == (c = t.exceptions) || c.sendExceptionEvent(g)), e;
	};
}
var qs = class {
	constructor(t, e, i, r, s, n) {
		this.name = zs, this.setupOnce = function(o) {
			o(Hs(t, {
				organization: e,
				projectId: i,
				prefix: r,
				severityAllowList: s,
				sendExceptionsToPostHog: null == n || n
			}));
		};
	}
};
var Vs = class {
	constructor(t) {
		this.Rt = (t, e, i) => {
			i && (i.noSessionId || i.activityTimeout || i.sessionPastMaximumLength || i.crossTabAdoption) && (li.info("[PageViewManager] Session rotated, clearing pageview state", {
				sessionId: t,
				changeReason: i
			}), this.Ot = void 0, this._instance.scrollManager.resetContext());
		}, this._instance = t, this.Lt();
	}
	Lt() {
		var t;
		this.Ft = null == (t = this._instance.sessionManager) ? void 0 : t.onSessionId(this.Rt);
	}
	destroy() {
		var t;
		null == (t = this.Ft) || t.call(this), this.Ft = void 0;
	}
	doPageView(e, i) {
		var r, s = this.At(e, i);
		return this.Ot = {
			pathname: null !== (r = null == t ? void 0 : t.location.pathname) && void 0 !== r ? r : "",
			pageViewId: i,
			timestamp: e
		}, this._instance.scrollManager.resetContext(), s;
	}
	doPageLeave(t) {
		var e;
		return this.At(t, null == (e = this.Ot) ? void 0 : e.pageViewId);
	}
	doEvent() {
		var t;
		return { $pageview_id: null == (t = this.Ot) ? void 0 : t.pageViewId };
	}
	At(t, e) {
		var i = this.Ot;
		if (!i) return { $pageview_id: e };
		var r = {
			$pageview_id: e,
			$prev_pageview_id: i.pageViewId
		}, s = this._instance.scrollManager.getContext();
		if (s && !this._instance.config.disable_scroll_properties) {
			var { maxScrollHeight: n, lastScrollY: o, maxScrollY: a, maxContentHeight: l, lastContentY: u, maxContentY: h } = s;
			if (!(V(n) || V(o) || V(a) || V(l) || V(u) || V(h))) {
				n = Math.ceil(n), o = Math.ceil(o), a = Math.ceil(a), l = Math.ceil(l), u = Math.ceil(u), h = Math.ceil(h);
				var d = n > 1 ? lt(o / n, 0, 1, li) : 1, v = n > 1 ? lt(a / n, 0, 1, li) : 1, c = l > 1 ? lt(u / l, 0, 1, li) : 1, p = l > 1 ? lt(h / l, 0, 1, li) : 1;
				r = Sr(r, {
					$prev_pageview_last_scroll: o,
					$prev_pageview_last_scroll_percentage: d,
					$prev_pageview_max_scroll: a,
					$prev_pageview_max_scroll_percentage: v,
					$prev_pageview_last_content: u,
					$prev_pageview_last_content_percentage: c,
					$prev_pageview_max_content: h,
					$prev_pageview_max_content_percentage: p
				});
			}
		}
		return i.pathname && (r.$prev_pageview_pathname = i.pathname), i.timestamp && (r.$prev_pageview_duration = (t.getTime() - i.timestamp.getTime()) / 1e3), r;
	}
};
var Gs = ["flags", "surveys"], Ws = {
	[vi]: { exposure: "hidden" },
	[fi]: { exposure: "hidden" },
	__cmpns: { exposure: "hidden" },
	[_i]: { exposure: "hidden" },
	[gi]: { exposure: "event" },
	[mi]: { exposure: "hidden" },
	[yi]: { exposure: "event" },
	[bi]: { exposure: "hidden" },
	[wi]: { exposure: "event" },
	[Ei]: { exposure: "event" },
	[xi]: { exposure: "event" },
	[Si]: { exposure: "hidden" },
	[Ti]: { exposure: "event" },
	[$i]: { exposure: "hidden" },
	$session_recording_enabled_server_side: { exposure: "hidden" },
	[Ci]: { exposure: "hidden" },
	[Ai]: { exposure: "event" },
	[ki]: {
		exposure: "event",
		shouldSkipFromEventProperties: (t) => Y(t)
	},
	$session_past_minimum_duration: { exposure: "event" },
	$session_recording_url_trigger_activated_session: { exposure: "event" },
	$session_recording_event_trigger_activated_session: { exposure: "event" },
	$debug_first_full_snapshot_timestamp: { exposure: "event" },
	$sess_rec_flush_size: { exposure: "hidden" },
	[Fi]: {
		exposure: "derived",
		storageGroup: "flags",
		shouldSkipFromEventProperties: (t, e) => e(),
		transformToEventProperties(t) {
			if (!H(t)) return {};
			for (var e = {}, i = Object.keys(t), r = 0; i.length > r; r++) e["$feature/" + i[r]] = t[i[r]];
			return e;
		}
	},
	[Mi]: {
		exposure: "event",
		storageGroup: "flags"
	},
	[Di]: { exposure: "hidden" },
	[Li]: {
		exposure: "hidden",
		storageGroup: "flags"
	},
	[Ni]: {
		exposure: "event",
		storageGroup: "flags"
	},
	[Ui]: {
		exposure: "event",
		storageGroup: "flags",
		volatile: !0
	},
	[ji]: { exposure: "event" },
	[Bi]: { exposure: "hidden" },
	[zi]: { exposure: "hidden" },
	[Hi]: { exposure: "hidden" },
	[qi]: {
		exposure: "hidden",
		storageGroup: "surveys"
	},
	[Vi]: {
		exposure: "hidden",
		storageGroup: "surveys",
		volatile: !0
	},
	[Gi]: { exposure: "event" },
	[Wi]: { exposure: "hidden" },
	$product_tours_activated: { exposure: "hidden" },
	$conversations_widget_session_id: { exposure: "event" },
	$conversations_ticket_id: { exposure: "event" },
	$conversations_widget_state: { exposure: "event" },
	$conversations_user_traits: { exposure: "event" },
	[Yi]: { exposure: "hidden" },
	[Ki]: { exposure: "hidden" },
	[Ji]: { exposure: "hidden" },
	[Qi]: {
		exposure: "hidden",
		storageGroup: "flags",
		volatile: !0
	},
	[Xi]: { exposure: "hidden" },
	[Zi]: { exposure: "hidden" },
	[tr]: { exposure: "hidden" },
	[er]: { exposure: "hidden" },
	[ir]: { exposure: "hidden" },
	[rr]: { exposure: "hidden" },
	[sr]: { exposure: "hidden" },
	[Ri]: { exposure: "event" },
	[Pi]: { exposure: "event" },
	[Ii]: { exposure: "event" },
	[Oi]: { exposure: "event" },
	[ar]: { exposure: "event" },
	[lr]: { exposure: "event" },
	[ur]: { exposure: "event" },
	$sdk_debug_replay_event_trigger_status: { exposure: "event" },
	$sdk_debug_replay_linked_flag_trigger_status: { exposure: "event" },
	$sdk_debug_replay_matched_recording_trigger_groups: { exposure: "event" },
	$sdk_debug_replay_remote_trigger_matching_config: { exposure: "event" },
	$sdk_debug_replay_trigger_groups_count: { exposure: "event" },
	$sdk_debug_replay_url_trigger_status: { exposure: "event" },
	$session_recording_start_reason: { exposure: "event" }
}, Ys = [
	["$posthog_sr_group_event_trigger_", { exposure: "hidden" }],
	["$posthog_sr_group_url_trigger_", { exposure: "hidden" }],
	["$posthog_sr_group_sampling_", { exposure: "hidden" }]
], Ks = (t) => {
	var e = Ws[t];
	if (e) return e;
	for (var [i, r] of Ys) if (0 === t.indexOf(i)) return r;
}, Js = (t) => {
	var e = null == r ? void 0 : r.createElement("a");
	return V(e) ? null : (e.href = t, e);
}, Qs = function(t, e) {
	for (var i, r = ((t.split("#")[0] || "").split(/\?(.*)/)[1] || "").replace(/^\?+/g, "").split("&"), s = 0; r.length > s; s++) {
		var n = r[s].split("=");
		if (n[0] === e) {
			i = n;
			break;
		}
	}
	if (!B(i) || 2 > i.length) return "";
	var o = i[1];
	try {
		o = decodeURIComponent(o);
	} catch (t) {
		li.error("Skipping decoding for malformed query param: " + o);
	}
	return o.replace(/\+/g, " ");
}, Xs = function(t, e, i) {
	if (!t || !e || !e.length) return t;
	for (var r = t.split("#"), s = r[1], n = (r[0] || "").split("?"), o = n[1], a = n[0], l = (o || "").split("&"), u = [], h = 0; l.length > h; h++) {
		var d = l[h].split("=");
		B(d) && (e.includes(d[0]) ? u.push(d[0] + "=" + i) : u.push(l[h]));
	}
	var v = a;
	return null != o && (v += "?" + u.join("&")), null != s && (v += "#" + s), v;
}, Zs = function(t, e) {
	var i = t.match(new RegExp(e + "=([^&]*)"));
	return i ? i[1] : null;
}, tn = "https?://(.*)", en = [
	"gclid",
	"gclsrc",
	"dclid",
	"gbraid",
	"wbraid",
	"fbclid",
	"msclkid",
	"twclid",
	"li_fat_id",
	"igshid",
	"ttclid",
	"rdt_cid",
	"epik",
	"qclid",
	"sccid",
	"irclid",
	"_kx"
], rn = [
	"utm_source",
	"utm_medium",
	"utm_campaign",
	"utm_content",
	"utm_term",
	"gad_source",
	"mc_cid",
	...en
], sn = "<masked>", nn = ["li_fat_id"];
function on(t, e, i) {
	if (!r) return {};
	var s, n = e ? [...en, ...i || []] : [], o = an(Xs(r.URL, n, sn), t);
	return Sr((s = {}, xr(nn, (function(t) {
		var e = zr.A(t);
		s[t] = e || null;
	})), s), o);
}
function an(t, e) {
	var i = rn.concat(e || []), r = {};
	return xr(i, (function(e) {
		r[e] = Qs(t, e) || null;
	})), r;
}
function ln(t) {
	var e = function(t) {
		return t ? 0 === t.search(tn + "google.([^/?]*)") ? "google" : 0 === t.search(tn + "bing.com") ? "bing" : 0 === t.search(tn + "yahoo.com") ? "yahoo" : 0 === t.search(tn + "duckduckgo.com") ? "duckduckgo" : null : null;
	}(t), i = "yahoo" != e ? "q" : "p", s = {};
	if (!Y(e)) {
		s.$search_engine = e;
		var n = r ? Qs(r.referrer, i) : "";
		n.length && (s.ph_keyword = n);
	}
	return s;
}
function un() {
	return navigator.language || navigator.userLanguage;
}
var hn = "$direct";
function dn() {
	return (null == r ? void 0 : r.referrer) || hn;
}
function vn(t, e, i) {
	void 0 === i && (i = !1);
	var r = t ? [...en, ...e || []] : [], n = i ? _e(null == s ? void 0 : s.href) : null == s ? void 0 : s.href, o = null == n ? void 0 : n.substring(0, 1e3);
	return {
		r: dn().substring(0, 1e3),
		u: o ? Xs(o, r, sn) : void 0
	};
}
function cn(t, e) {
	var i;
	void 0 === e && (e = !1);
	var { r, u: s } = t, n = e ? _e(s) : s, o = {
		$referrer: r,
		$referring_domain: null == r ? void 0 : r == hn ? hn : null == (i = Js(r)) ? void 0 : i.host
	};
	if (n) {
		o.$current_url = n;
		var a = Js(n);
		o.$host = null == a ? void 0 : a.host, o.$pathname = null == a ? void 0 : a.pathname;
		Sr(o, an(n));
	}
	if (r) Sr(o, ln(r));
	return o;
}
function pn() {
	try {
		return Intl.DateTimeFormat().resolvedOptions().timeZone;
	} catch (t) {
		return;
	}
}
function fn() {
	try {
		return (/* @__PURE__ */ new Date()).getTimezoneOffset();
	} catch (t) {
		return;
	}
}
var _n = {
	flags: Qi,
	surveys: Vi
}, gn = [
	"cookie",
	"localstorage",
	"localstorage+cookie",
	"sessionstorage",
	"memory"
], mn = "main";
var yn = class {
	constructor(e, i, r) {
		if (void 0 === r && (r = !0), this.$t = {}, this.Dt = !1, this.Nt = !1, this.Se = e, this.qt = r, this.props = {}, this.Bt = !1, this.jt = ((t) => {
			var e = "";
			return t.token && (e = t.token.replace(/\+/g, "PL").replace(/\//g, "SL").replace(/=/g, "EQ")), t.persistence_name ? "ph_" + t.persistence_name : "ph_" + e + "_posthog";
		})(e), this.Ct = this.Ht(e), this.Nt = this.Ut(e), this.load(), e.debug && li.info("Persistence loaded", e.persistence, f({}, this.props)), this.update_config(e, e, i), this.save(), t) {
			var s = () => this.flush();
			Or(t, "beforeunload", s, { capture: !1 }), Or(t, "pagehide", s, { capture: !1 });
		}
	}
	zt() {
		var t, e = null == (t = this.Se) ? void 0 : t.persistence_save_debounce_ms;
		return J(e) && e > 0 ? e : 0;
	}
	isDisabled() {
		return !!this.Vt;
	}
	Ht(e) {
		-1 === gn.indexOf(e.persistence.toLowerCase()) && (li.critical("Unknown persistence type " + e.persistence + "; falling back to localStorage+cookie"), e.persistence = "localStorage+cookie");
		var i, r = function(e, i) {
			void 0 === e && (e = []), void 0 === i && (i = !1);
			var r = [...Vr, ...e];
			return f({}, qr, {
				F(t) {
					try {
						var e = {};
						try {
							e = zr.F(t) || {};
						} catch (t) {}
						var r, s = JSON.parse(qr.A(t) || "{}");
						if (i) {
							var n = {};
							for (var o in e) {
								var a = e[o];
								Y(a) || "" === a || (n[o] = a);
							}
							r = Sr(s, n);
						} else r = Sr(e, s);
						return qr.q(t, r), r;
					} catch (t) {}
					return null;
				},
				q(t, e, i, s, n, o) {
					var a = qr.q(t, e, void 0, void 0, o);
					try {
						var l = {};
						r.forEach(((t) => {
							e[t] && (l[t] = e[t]);
						})), Object.keys(l).length && zr.q(t, l, i, s, n, o);
					} catch (t) {
						qr.D(t);
					}
					return a;
				},
				P(e, i) {
					try {
						t?.localStorage.removeItem(e), zr.P(e, i);
					} catch (t) {
						qr.D(t);
					}
				}
			});
		}(e.cookie_persisted_properties || [], e.__preview_cookie_wins_on_conflict || !1), s = !1, n = e.persistence.toLowerCase();
		return "localstorage" === n && qr.N() ? (i = qr, s = !0) : "localstorage+cookie" === n && r.N() ? (i = r, s = !0) : "sessionstorage" === n && Kr.N() ? i = Kr : "memory" === n ? i = Wr : "cookie" === n ? i = zr : r.N() ? (i = r, s = !0) : i = zr, this.Dt = s, i;
	}
	Wt(t) {
		return this.jt + "__" + t;
	}
	Ut(t) {
		return this.Dt && !!t.split_storage;
	}
	Gt(t) {
		var e = null != t ? t : this.Se.feature_flag_cache_ttl_ms;
		if (!e || 0 >= e) return !1;
		var i = this.props[Qi];
		return !i || "number" != typeof i || Date.now() - i > e;
	}
	properties() {
		var t = {};
		return xr(this.props, ((e, i) => {
			var r = Ks(i);
			if ("derived" === (null == r ? void 0 : r.exposure)) {
				if (null != r.shouldSkipFromEventProperties && r.shouldSkipFromEventProperties(e, i === Fi ? () => this.Gt() : () => !1)) return;
				r.transformToEventProperties && Sr(t, r.transformToEventProperties(e));
			} else if (!r || "event" === r.exposure) {
				if (null != r && null != r.shouldSkipFromEventProperties && r.shouldSkipFromEventProperties(e, (() => !1))) return;
				t[i] = e;
			}
		})), t;
	}
	load() {
		if (!this.Vt) {
			var t = this.Ct.F(this.jt);
			t && (this.props = Sr({}, t)), this.Nt && this.Zt();
		}
	}
	Zt() {
		for (var t of Gs) {
			var e = qr.F(this.Wt(t));
			if (e && !q(e)) {
				var i = this.Qt(t);
				i.persisted = !0, this.Jt(t) || (i.fingerprint = this.Yt(e, t)), this.Kt(t, e) || Sr(this.props, e);
			}
		}
	}
	Jt(t) {
		return Object.keys(this.props).some(((e) => {
			var i;
			return (null == (i = Ks(e)) ? void 0 : i.storageGroup) === t;
		}));
	}
	Kt(t, e) {
		var i = _n[t];
		if (!i) return !1;
		var r = e[i], s = this.props[i];
		return J(r) && J(s) && s > r;
	}
	refreshKey(t) {
		var e;
		if (!this.Vt) {
			var i = this.Nt ? null == (e = Ks(t)) ? void 0 : e.storageGroup : void 0, r = i ? qr.F(this.Wt(i)) : this.Ct.F(this.jt);
			if (r && t in r) this.Xt(t, r[t]);
			else {
				if (i) {
					var s = this.Ct.F(this.jt);
					if (s && t in s) return void this.Xt(t, s[t]);
				}
				this.er(t);
			}
		}
	}
	save() {
		if (!this.Vt) {
			var t = this.zt();
			t > 0 ? V(this.tr) && (this.tr = setTimeout((() => {
				this.tr = void 0, this.rr();
			}), t)) : this.rr();
		}
	}
	flush() {
		V(this.tr) || (clearTimeout(this.tr), this.tr = void 0, this.rr());
	}
	rr() {
		this.Vt || (this.Nt ? this.ir() : this.nr(this.Ct, this.jt, this.props, mn));
	}
	ir() {
		var { main: t, groups: e } = this.sr();
		for (var i of (this.nr(this.Ct, this.jt, t, mn), Gs)) {
			var r, s = e[i];
			(!q(s) || null != (r = this.$t[i]) && r.persisted) && this.nr(qr, this.Wt(i), s, i);
		}
	}
	sr() {
		var t = {}, e = {};
		for (var i of Gs) e[i] = {};
		return xr(this.props, ((i, r) => {
			var s, n = null == (s = Ks(r)) ? void 0 : s.storageGroup;
			n ? e[n][r] = i : t[r] = i;
		})), {
			main: t,
			groups: e
		};
	}
	Yt(t, e) {
		if (e === mn) return JSON.stringify(t) + "|" + this.ar + "|" + this.lr + "|" + this.ur;
		var i = {};
		return xr(t, ((t, e) => {
			var r;
			i[e] = null != (r = Ks(e)) && r.volatile ? "__volatile__" : t;
		})), JSON.stringify(i);
	}
	nr(t, e, i, r) {
		var s = this.Qt(r);
		if (r === mn || s.dirty || V(s.fingerprint)) {
			var n;
			try {
				if ((n = this.Yt(i, r)) === s.fingerprint) return void (s.dirty = !1);
			} catch (t) {
				n = void 0;
			}
			t.q(e, i, this.ar, this.lr, this.ur, this.Se.debug) ? (s.dirty = !1, r !== mn && (s.persisted = !0), V(n) || (s.fingerprint = n)) : this.Se.debug && li.warn("failed to persist storage entry \"" + e + "\"; will retry on next save");
		}
	}
	remove(t) {
		var { keepGroupEntries: e = !1 } = void 0 === t ? {} : t;
		if (V(this.tr) || (clearTimeout(this.tr), this.tr = void 0), this.Ct.P(this.jt, !1), this.Ct.P(this.jt, !0), !e && this.qt) for (var i of Gs) qr.P(this.Wt(i));
		e ? delete this.$t[mn] : this.$t = {};
	}
	clear() {
		this.remove(), this.props = {};
	}
	register_once(t, e, i) {
		if (H(t)) {
			V(e) && (e = "None"), this.ar = V(i) ? this.hr : i;
			var r = !1;
			if (xr(t, ((t, i) => {
				this.props.hasOwnProperty(i) && this.props[i] !== e || (this.Xt(i, t), r = !0);
			})), r) return this.save(), !0;
		}
		return !1;
	}
	register(t, e) {
		if (H(t)) {
			this.ar = V(e) ? this.hr : e;
			var i = !1;
			if (xr(t, ((e, r) => {
				t.hasOwnProperty(r) && this.props[r] !== e && (this.Xt(r, e), i = !0);
			})), i) return this.save(), !0;
		}
		return !1;
	}
	unregister(t) {
		t in this.props && (this.er(t), this.save());
	}
	update_campaign_params() {
		if (!this.Bt) {
			var t = on(this.Se.custom_campaign_params, this.Se.mask_personal_data_properties, this.Se.custom_personal_data_properties);
			q(Rr(t)) || this.register(t), this.Bt = !0;
		}
	}
	update_search_keyword() {
		var t;
		this.register((t = null == r ? void 0 : r.referrer) ? ln(t) : {});
	}
	update_referrer_info() {
		var t;
		this.register_once({
			$referrer: dn(),
			$referring_domain: null != r && r.referrer && (null == (t = Js(r.referrer)) ? void 0 : t.host) || hn
		}, void 0);
	}
	set_initial_person_info() {
		this.props[er] || this.props[ir] || this.register_once({ [rr]: vn(this.Se.mask_personal_data_properties, this.Se.custom_personal_data_properties, this.Se.disable_capture_url_hashes) }, void 0);
	}
	get_initial_props() {
		var t = {};
		xr([ir, er], ((e) => {
			var i = this.props[e];
			i && xr(i, (function(e, i) {
				t["$initial_" + L(i)] = e;
			}));
		}));
		var e = this.props[rr];
		if (e) Sr(t, function(t, e) {
			void 0 === e && (e = !1);
			var i = cn(t, e), r = {};
			return xr(i, (function(t, e) {
				r["$initial_" + L(e)] = t;
			})), r;
		}(e, this.Se.disable_capture_url_hashes));
		return t;
	}
	safe_merge(t) {
		return xr(this.props, (function(e, i) {
			i in t || (t[i] = e);
		})), t;
	}
	update_config(t, e, i) {
		this.hr = this.ar = t.cookie_expiration, this.set_disabled(t.disable_persistence || !!i), this.set_cross_subdomain(t.cross_subdomain_cookie), this.set_secure(t.secure_cookie);
		var r = t.persistence !== e.persistence || !((t, e) => {
			if (t.length !== e.length) return !1;
			var i = [...t].sort(), r = [...e].sort();
			return i.every(((t, e) => t === r[e]));
		})(t.cookie_persisted_properties || [], e.cookie_persisted_properties || []), s = r ? this.Ht(t) : this.Ct, n = this.Ut(t);
		if (r || n !== this.Nt) {
			var o = this.props;
			this.clear(), this.Ct = s, this.Nt = n, this.props = o, this.save();
		}
	}
	set_disabled(t) {
		this.Vt = t, this.Vt ? this.remove() : this.save();
	}
	set_cross_subdomain(t) {
		t !== this.lr && (this.lr = t, this.remove({ keepGroupEntries: !0 }), this.save());
	}
	set_secure(t) {
		t !== this.ur && (this.ur = t, this.remove({ keepGroupEntries: !0 }), this.save());
	}
	set_event_timer(t, e) {
		var i = this.props[_i] || {};
		i[t] = e, this.Xt(_i, i), this.save();
	}
	remove_event_timer(t) {
		var e = this.props[_i] || {}, i = e[t];
		return V(i) || (delete e[t], this.Xt(_i, e), this.save()), i;
	}
	get_property(t) {
		return this.props[t];
	}
	set_property(t, e) {
		this.Xt(t, e), this.save();
	}
	Xt(t, e) {
		var i;
		this.props[t] = e, null != (i = Ks(t)) && i.volatile || this.dr(t);
	}
	er(t) {
		delete this.props[t], this.dr(t);
	}
	dr(t) {
		var e, i = null == (e = Ks(t)) ? void 0 : e.storageGroup;
		i && (this.Qt(i).dirty = !0);
	}
	Qt(t) {
		return this.$t[t] || (this.$t[t] = {});
	}
}, bn = {
	Activation: "events",
	Cancellation: "cancelEvents"
}, Sn = {
	Popover: "popover",
	API: "api",
	Widget: "widget",
	ExternalSurvey: "external_survey"
}, kn = {
	Once: "once",
	Recurring: "recurring",
	Always: "always"
}, Rn = {
	SHOWN: "survey shown",
	DISMISSED: "survey dismissed",
	SENT: "survey sent",
	ABANDONED: "survey abandoned"
}, Pn = {
	SURVEY_ID: "$survey_id",
	SURVEY_NAME: "$survey_name",
	SURVEY_RESPONSE: "$survey_response",
	SURVEY_ITERATION: "$survey_iteration",
	SURVEY_ITERATION_START_DATE: "$survey_iteration_start_date",
	SURVEY_PARTIALLY_COMPLETED: "$survey_partially_completed",
	SURVEY_SUBMISSION_ID: "$survey_submission_id",
	SURVEY_QUESTIONS: "$survey_questions",
	SURVEY_COMPLETED: "$survey_completed",
	PRODUCT_TOUR_ID: "$product_tour_id",
	SURVEY_LAST_SEEN_DATE: "$survey_last_seen_date",
	SURVEY_LANGUAGE: "$survey_language"
}, In = {
	Popover: "popover",
	Inline: "inline"
}, Cn = {
	SHOWN: "product tour shown",
	DISMISSED: "product tour dismissed",
	COMPLETED: "product tour completed",
	STEP_SHOWN: "product tour step shown",
	STEP_COMPLETED: "product tour step completed",
	BUTTON_CLICKED: "product tour button clicked",
	STEP_SELECTOR_FAILED: "product tour step selector failed",
	BANNER_CONTAINER_SELECTOR_FAILED: "product tour banner container selector failed",
	BANNER_ACTION_CLICKED: "product tour banner action clicked"
}, An = {
	TOUR_ID: "$product_tour_id",
	TOUR_NAME: "$product_tour_name",
	TOUR_ITERATION: "$product_tour_iteration",
	TOUR_RENDER_REASON: "$product_tour_render_reason",
	TOUR_STEP_ID: "$product_tour_step_id",
	TOUR_STEP_ORDER: "$product_tour_step_order",
	TOUR_STEP_TYPE: "$product_tour_step_type",
	TOUR_DISMISS_REASON: "$product_tour_dismiss_reason",
	TOUR_BUTTON_TEXT: "$product_tour_button_text",
	TOUR_BUTTON_ACTION: "$product_tour_button_action",
	TOUR_BUTTON_LINK: "$product_tour_button_link",
	TOUR_BUTTON_TOUR_ID: "$product_tour_button_tour_id",
	TOUR_STEPS_COUNT: "$product_tour_steps_count",
	TOUR_STEP_SELECTOR: "$product_tour_step_selector",
	TOUR_STEP_SELECTOR_FOUND: "$product_tour_step_selector_found",
	TOUR_STEP_ELEMENT_TAG: "$product_tour_step_element_tag",
	TOUR_STEP_ELEMENT_ID: "$product_tour_step_element_id",
	TOUR_STEP_ELEMENT_CLASSES: "$product_tour_step_element_classes",
	TOUR_STEP_ELEMENT_TEXT: "$product_tour_step_element_text",
	TOUR_ERROR: "$product_tour_error",
	TOUR_MATCHES_COUNT: "$product_tour_matches_count",
	TOUR_FAILURE_PHASE: "$product_tour_failure_phase",
	TOUR_WAITED_FOR_ELEMENT: "$product_tour_waited_for_element",
	TOUR_WAIT_DURATION_MS: "$product_tour_wait_duration_ms",
	TOUR_BANNER_SELECTOR: "$product_tour_banner_selector",
	TOUR_LINKED_SURVEY_ID: "$product_tour_linked_survey_id",
	USE_MANUAL_SELECTOR: "$use_manual_selector",
	INFERENCE_DATA_PRESENT: "$inference_data_present",
	TOUR_LAST_SEEN_DATE: "$product_tour_last_seen_date",
	TOUR_TYPE: "$product_tour_type"
}, Fn = ui("[RateLimiter]");
var Mn = class {
	constructor(t) {
		this.serverLimits = {}, this.lastEventRateLimited = !1, this.checkForLimiting = (t) => {
			var e = t.text;
			if (e && e.length) try {
				(JSON.parse(e).quota_limited || []).forEach(((t) => {
					Fn.info((t || "events") + " is quota limited."), this.serverLimits[t] = (/* @__PURE__ */ new Date()).getTime() + 6e4;
				}));
			} catch (t) {
				Fn.warn("could not rate limit - continuing. Error: \"" + (null == t ? void 0 : t.message) + "\"", { text: e });
				return;
			}
		}, this.instance = t, this.lastEventRateLimited = this.clientRateLimitContext(!0).isRateLimited;
	}
	get captureEventsPerSecond() {
		var t;
		return (null == (t = this.instance.config.rate_limiting) ? void 0 : t.events_per_second) || 10;
	}
	get captureEventsBurstLimit() {
		var t;
		return Math.max((null == (t = this.instance.config.rate_limiting) ? void 0 : t.events_burst_limit) || 10 * this.captureEventsPerSecond, this.captureEventsPerSecond);
	}
	clientRateLimitContext(t) {
		var e, i, r;
		void 0 === t && (t = !1);
		var { captureEventsBurstLimit: s, captureEventsPerSecond: n } = this, o = (/* @__PURE__ */ new Date()).getTime(), a = null !== (e = null == (i = this.instance.persistence) ? void 0 : i.get_property(tr)) && void 0 !== e ? e : {
			tokens: s,
			last: o
		};
		a.tokens += (o - a.last) / 1e3 * n, a.last = o, a.tokens > s && (a.tokens = s);
		var l = 1 > a.tokens;
		return l || t || (a.tokens = Math.max(0, a.tokens - 1)), !l || this.lastEventRateLimited || t || this.instance.capture("$$client_ingestion_warning", { $$client_ingestion_warning_message: "posthog-js client rate limited. Config is set to " + n + " events per second and " + s + " events burst limit." }, { skip_client_rate_limiting: !0 }), this.lastEventRateLimited = l, null == (r = this.instance.persistence) || r.set_property(tr, a), {
			isRateLimited: l,
			remainingTokens: a.tokens
		};
	}
	isServerRateLimited(t) {
		var e = this.serverLimits[t || "events"] || !1;
		return !1 !== e && (/* @__PURE__ */ new Date()).getTime() < e;
	}
};
var Dn = ui("[RemoteConfig]");
var Ln = class {
	constructor(t) {
		this._instance = t;
	}
	get remoteConfig() {
		var t;
		return null == (t = h._POSTHOG_REMOTE_CONFIG) || null == (t = t[this._instance.config.token]) ? void 0 : t.config;
	}
	cr(t) {
		var e, i;
		null != (e = h.__PosthogExtensions__) && e.loadExternalDependency ? null == (i = h.__PosthogExtensions__) || null == i.loadExternalDependency || i.loadExternalDependency(this._instance, "remote-config", (() => t(this.remoteConfig))) : t();
	}
	vr(t) {
		this._instance._send_request({
			method: "GET",
			url: this._instance.requestRouter.endpointFor("assets", "/array/" + this._instance.config.token + "/config"),
			callback(e) {
				t(e.json);
			}
		});
	}
	load() {
		try {
			if (this.remoteConfig) return Dn.info("Using preloaded remote config", this.remoteConfig), this.pr(this.remoteConfig), void this.gr();
			if (this._instance.mr()) return void Dn.warn("Remote config is disabled. Falling back to local config.");
			this.cr(((t) => {
				if (!t) return Dn.info("No config found after loading remote JS config. Falling back to JSON."), void this.vr(((t) => {
					this.pr(t), this.gr();
				}));
				this.pr(t), this.gr();
			}));
		} catch (t) {
			Dn.error("Error loading remote config", t);
		}
	}
	stop() {
		this.yr && (clearInterval(this.yr), this.yr = void 0);
	}
	refresh() {
		!this._instance.mr() && r && "hidden" !== r.visibilityState && this._instance.reloadFeatureFlags();
	}
	gr() {
		var t;
		if (!this.yr) {
			var e = null !== (t = this._instance.config.remote_config_refresh_interval_ms) && void 0 !== t ? t : 3e5;
			0 !== e && (this.yr = setInterval((() => {
				this.refresh();
			}), e));
		}
	}
	pr(t) {
		var e;
		t || Dn.error("Failed to fetch remote config from PostHog."), this._instance.pr(null != t ? t : {}), !1 !== (null == t ? void 0 : t.hasFeatureFlags) && (this._instance.config.advanced_disable_feature_flags_on_first_load || null == (e = this._instance.featureFlags) || e.ensureFlagsLoaded());
	}
}, Un = {
	GZipJS: "gzip-js",
	Base64: "base64"
}, jn = Uint8Array, Bn = Uint16Array, zn = Uint32Array, Hn = new jn([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]), qn = new jn([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]), Vn = new jn([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]), Gn = function(t, e) {
	for (var i = new Bn(31), r = 0; 31 > r; ++r) i[r] = e += 1 << t[r - 1];
	var s = new zn(i[30]);
	for (r = 1; 30 > r; ++r) for (var n = i[r]; i[r + 1] > n; ++n) s[n] = n - i[r] << 5 | r;
	return [i, s];
}, Wn = Gn(Hn, 2), Yn = Wn[1];
Wn[0][28] = 258, Yn[258] = 28;
for (var Kn = Gn(qn, 0)[1], Jn = new Bn(32768), Qn = 0; 32768 > Qn; ++Qn) {
	var Xn = (43690 & Qn) >>> 1 | (21845 & Qn) << 1;
	Jn[Qn] = ((65280 & (Xn = (61680 & (Xn = (52428 & Xn) >>> 2 | (13107 & Xn) << 2)) >>> 4 | (3855 & Xn) << 4)) >>> 8 | (255 & Xn) << 8) >>> 1;
}
var Zn = function(t, e, i) {
	for (var r = t.length, s = 0, n = new Bn(e); r > s; ++s) ++n[t[s] - 1];
	var o, a = new Bn(e);
	for (s = 0; e > s; ++s) a[s] = a[s - 1] + n[s - 1] << 1;
	if (i) {
		o = new Bn(1 << e);
		var l = 15 - e;
		for (s = 0; r > s; ++s) if (t[s]) for (var u = s << 4 | t[s], h = e - t[s], d = a[t[s] - 1]++ << h, v = d | (1 << h) - 1; v >= d; ++d) o[Jn[d] >>> l] = u;
	} else for (o = new Bn(r), s = 0; r > s; ++s) o[s] = Jn[a[t[s] - 1]++] >>> 15 - t[s];
	return o;
}, to = new jn(288);
for (Qn = 0; 144 > Qn; ++Qn) to[Qn] = 8;
for (Qn = 144; 256 > Qn; ++Qn) to[Qn] = 9;
for (Qn = 256; 280 > Qn; ++Qn) to[Qn] = 7;
for (Qn = 280; 288 > Qn; ++Qn) to[Qn] = 8;
var eo = new jn(32);
for (Qn = 0; 32 > Qn; ++Qn) eo[Qn] = 5;
var io = Zn(to, 9, 0), ro = Zn(eo, 5, 0), so = function(t) {
	return (t / 8 >> 0) + (7 & t && 1);
}, no = function(t, e, i) {
	(null == i || i > t.length) && (i = t.length);
	var r = new (t instanceof Bn ? Bn : t instanceof zn ? zn : jn)(i - e);
	return r.set(t.subarray(e, i)), r;
}, oo = function(t, e, i) {
	var r = e / 8 >> 0;
	t[r] |= i <<= 7 & e, t[r + 1] |= i >>> 8;
}, ao = function(t, e, i) {
	var r = e / 8 >> 0;
	t[r] |= i <<= 7 & e, t[r + 1] |= i >>> 8, t[r + 2] |= i >>> 16;
}, lo = function(t, e) {
	for (var i = [], r = 0; t.length > r; ++r) t[r] && i.push({
		s: r,
		f: t[r]
	});
	var s = i.length, n = i.slice();
	if (!s) return [new jn(0), 0];
	if (1 == s) {
		var o = new jn(i[0].s + 1);
		return o[i[0].s] = 1, [o, 1];
	}
	i.sort((function(t, e) {
		return t.f - e.f;
	})), i.push({
		s: -1,
		f: 25001
	});
	var a = i[0], l = i[1], u = 0, h = 1, d = 2;
	for (i[0] = {
		s: -1,
		f: a.f + l.f,
		l: a,
		r: l
	}; h != s - 1;) a = i[i[d].f > i[u].f ? u++ : d++], l = i[u != h && i[d].f > i[u].f ? u++ : d++], i[h++] = {
		s: -1,
		f: a.f + l.f,
		l: a,
		r: l
	};
	var v = n[0].s;
	for (r = 1; s > r; ++r) n[r].s > v && (v = n[r].s);
	var c = new Bn(v + 1), p = uo(i[h - 1], c, 0);
	if (p > e) {
		r = 0;
		var f = 0, _ = p - e, g = 1 << _;
		for (n.sort((function(t, e) {
			return c[e.s] - c[t.s] || t.f - e.f;
		})); s > r; ++r) {
			var m = n[r].s;
			if (e >= c[m]) break;
			f += g - (1 << p - c[m]), c[m] = e;
		}
		for (f >>>= _; f > 0;) {
			var y = n[r].s;
			e > c[y] ? f -= 1 << e - c[y]++ - 1 : ++r;
		}
		for (; r >= 0 && f; --r) {
			var b = n[r].s;
			c[b] == e && (--c[b], ++f);
		}
		p = e;
	}
	return [new jn(c), p];
}, uo = function(t, e, i) {
	return -1 == t.s ? Math.max(uo(t.l, e, i + 1), uo(t.r, e, i + 1)) : e[t.s] = i;
}, ho = function(t) {
	for (var e = t.length; e && !t[--e];);
	for (var i = new Bn(++e), r = 0, s = t[0], n = 1, o = function(t) {
		i[r++] = t;
	}, a = 1; e >= a; ++a) if (t[a] == s && a != e) ++n;
	else {
		if (!s && n > 2) {
			for (; n > 138; n -= 138) o(32754);
			n > 2 && (o(n > 10 ? n - 11 << 5 | 28690 : n - 3 << 5 | 12305), n = 0);
		} else if (n > 3) {
			for (o(s), --n; n > 6; n -= 6) o(8304);
			n > 2 && (o(n - 3 << 5 | 8208), n = 0);
		}
		for (; n--;) o(s);
		n = 1, s = t[a];
	}
	return [i.subarray(0, r), e];
}, vo = function(t, e) {
	for (var i = 0, r = 0; e.length > r; ++r) i += t[r] * e[r];
	return i;
}, co = function(t, e, i) {
	var r = i.length, s = so(e + 2);
	t[s] = 255 & r, t[s + 1] = r >>> 8, t[s + 2] = 255 ^ t[s], t[s + 3] = 255 ^ t[s + 1];
	for (var n = 0; r > n; ++n) t[s + n + 4] = i[n];
	return 8 * (s + 4 + r);
}, po = function(t, e, i, r, s, n, o, a, l, u, h) {
	oo(e, h++, i), ++s[256];
	for (var d = lo(s, 15), v = d[0], c = d[1], p = lo(n, 15), f = p[0], _ = p[1], g = ho(v), m = g[0], y = g[1], b = ho(f), w = b[0], E = b[1], x = new Bn(19), S = 0; m.length > S; ++S) x[31 & m[S]]++;
	for (S = 0; w.length > S; ++S) x[31 & w[S]]++;
	for (var T = lo(x, 7), k = T[0], R = T[1], P = 19; P > 4 && !k[Vn[P - 1]]; --P);
	var I, O, C, A, F = u + 5 << 3, M = vo(s, to) + vo(n, eo) + o, D = vo(s, v) + vo(n, f) + o + 14 + 3 * P + vo(x, k) + (2 * x[16] + 3 * x[17] + 7 * x[18]);
	if (M >= F && D >= F) return co(e, h, t.subarray(l, l + u));
	if (oo(e, h, 1 + (M > D)), h += 2, M > D) {
		I = Zn(v, c, 0), O = v, C = Zn(f, _, 0), A = f;
		var L = Zn(k, R, 0);
		for (oo(e, h, y - 257), oo(e, h + 5, E - 1), oo(e, h + 10, P - 4), h += 14, S = 0; P > S; ++S) oo(e, h + 3 * S, k[Vn[S]]);
		h += 3 * P;
		for (var N = [m, w], U = 0; 2 > U; ++U) {
			var j = N[U];
			for (S = 0; j.length > S; ++S) oo(e, h, L[B = 31 & j[S]]), h += k[B], B > 15 && (oo(e, h, j[S] >>> 5 & 127), h += j[S] >>> 12);
		}
	} else I = io, O = to, C = ro, A = eo;
	for (S = 0; a > S; ++S) if (r[S] > 255) {
		var B;
		ao(e, h, I[257 + (B = r[S] >>> 18 & 31)]), h += O[B + 257], B > 7 && (oo(e, h, r[S] >>> 23 & 31), h += Hn[B]);
		var z = 31 & r[S];
		ao(e, h, C[z]), h += A[z], z > 3 && (ao(e, h, r[S] >>> 5 & 8191), h += qn[z]);
	} else ao(e, h, I[r[S]]), h += O[r[S]];
	return ao(e, h, I[256]), h + O[256];
}, fo = new zn([
	65540,
	131080,
	131088,
	131104,
	262176,
	1048704,
	1048832,
	2114560,
	2117632
]), _o = function() {
	for (var t = new zn(256), e = 0; 256 > e; ++e) {
		for (var i = e, r = 9; --r;) i = (1 & i && 3988292384) ^ i >>> 1;
		t[e] = i;
	}
	return t;
}(), go = function(t, e, i) {
	for (; i; ++e) t[e] = i, i >>>= 8;
};
function mo(t, e) {
	void 0 === e && (e = {});
	var i = function() {
		var t = 4294967295;
		return {
			p(e) {
				for (var i = t, r = 0; e.length > r; ++r) i = _o[255 & i ^ e[r]] ^ i >>> 8;
				t = i;
			},
			d() {
				return 4294967295 ^ t;
			}
		};
	}(), r = t.length;
	i.p(t);
	var s, n, o, a, l, u = (a = 10 + ((s = e).filename && s.filename.length + 1 || 0), l = 8, function(t, e, i, r, s, n) {
		var o = t.length, a = new jn(r + o + 5 * (1 + Math.floor(o / 7e3)) + s), l = a.subarray(r, a.length - s), u = 0;
		if (!e || 8 > o) for (var h = 0; o >= h; h += 65535) {
			var d = h + 65535;
			o > d ? u = co(l, u, t.subarray(h, d)) : (l[h] = !0, u = co(l, u, t.subarray(h, o)));
		}
		else {
			for (var v = fo[e - 1], c = v >>> 13, p = 8191 & v, f = (1 << i) - 1, _ = new Bn(32768), g = new Bn(f + 1), m = Math.ceil(i / 3), y = 2 * m, b = function(e) {
				return (t[e] ^ t[e + 1] << m ^ t[e + 2] << y) & f;
			}, w = new zn(25e3), E = new Bn(288), x = new Bn(32), S = 0, T = 0, k = (h = 0, 0), R = 0, P = 0; o > h; ++h) {
				var I = b(h), O = 32767 & h, C = g[I];
				if (_[O] = C, g[I] = O, h >= R) {
					var A = o - h;
					if ((S > 7e3 || k > 24576) && A > 423) {
						u = po(t, l, 0, w, E, x, T, k, P, h - P, u), k = S = T = 0, P = h;
						for (var F = 0; 286 > F; ++F) E[F] = 0;
						for (F = 0; 30 > F; ++F) x[F] = 0;
					}
					var M = 2, D = 0, L = p, N = O - C & 32767;
					if (A > 2 && I == b(h - N)) for (var U = Math.min(c, A) - 1, j = Math.min(32767, h), B = Math.min(258, A); j >= N && --L && O != C;) {
						if (t[h + M] == t[h + M - N]) {
							for (var z = 0; B > z && t[h + z] == t[h + z - N]; ++z);
							if (z > M) {
								if (M = z, D = N, z > U) break;
								var H = Math.min(N, z - 2), q = 0;
								for (F = 0; H > F; ++F) {
									var V = h - N + F + 32768 & 32767, G = V - _[V] + 32768 & 32767;
									G > q && (q = G, C = V);
								}
							}
						}
						N += (O = C) - (C = _[O]) + 32768 & 32767;
					}
					if (D) {
						w[k++] = 268435456 | Yn[M] << 18 | Kn[D];
						var W = 31 & Yn[M], Y = 31 & Kn[D];
						T += Hn[W] + qn[Y], ++E[257 + W], ++x[Y], R = h + M, ++S;
					} else w[k++] = t[h], ++E[t[h]];
				}
			}
			u = po(t, l, !0, w, E, x, T, k, P, h - P, u);
		}
		return no(a, 0, r + so(u) + s);
	}(n = t, null == (o = e).level ? 6 : o.level, null == o.mem ? Math.ceil(1.5 * Math.max(8, Math.min(13, Math.log(n.length)))) : 12 + o.mem, a, l)), h = u.length;
	return function(t, e) {
		var i = e.filename;
		if (t[0] = 31, t[1] = 139, t[2] = 8, t[8] = 2 > e.level ? 4 : 9 == e.level ? 2 : 0, t[9] = 3, 0 != e.mtime && go(t, 4, Math.floor(new Date(e.mtime || Date.now()) / 1e3)), i) {
			t[3] = 8;
			for (var r = 0; i.length >= r; ++r) t[r + 10] = i.charCodeAt(r);
		}
	}(u, e), go(u, h - 8, i.d()), go(u, h - 4, r), u;
}
var yo = !!o || !!n, bo = "text/plain", wo = !1, Eo = (t, e) => {
	var [i, r] = t.split("#"), [s, n] = i.split("?");
	if (!n) return t;
	var o = n.split("&").filter(((t) => t.split("=")[0] !== e)).join("&");
	return s + (o ? "?" + o : "") + (r ? "#" + r : "");
}, xo = function(t, e, i) {
	var r;
	void 0 === i && (i = !0);
	var [s, n] = t.split("?"), o = f({}, e), a = null !== (r = null == n ? void 0 : n.split("&").map(((t) => {
		var e, [r, s] = t.split("="), n = i && null !== (e = o[r]) && void 0 !== e ? e : s;
		return delete o[r], r + "=" + n;
	}))) && void 0 !== r ? r : [], l = function(t, e) {
		var i, r;
		void 0 === e && (e = "&");
		var s = [];
		return xr(t, (function(t, e) {
			V(t) || V(e) || "undefined" === e || (i = encodeURIComponent(((t) => t instanceof File)(t) ? t.name : t.toString()), r = encodeURIComponent(e), s[s.length] = r + "=" + i);
		})), s.join(e);
	}(o);
	return l && a.push(l), s + "?" + a.join("&");
}, So = (t, e) => JSON.stringify(t, ((t, e) => "bigint" == typeof e ? e.toString() : e), e), To = (t) => {
	if (t.xt) return t.xt;
	var { data: e, compression: i } = t;
	if (e) {
		if (i === Un.GZipJS) {
			var r = mo(function(t, e) {
				var i = t.length;
				if ("undefined" != typeof TextEncoder) return new TextEncoder().encode(t);
				for (var r = new jn(t.length + (t.length >>> 1)), s = 0, n = function(t) {
					r[s++] = t;
				}, o = 0; i > o; ++o) {
					if (s + 5 > r.length) {
						var a = new jn(s + 8 + (i - o << 1));
						a.set(r), r = a;
					}
					var l = t.charCodeAt(o);
					128 > l ? n(l) : 2048 > l ? (n(192 | l >>> 6), n(128 | 63 & l)) : l > 55295 && 57344 > l ? (n(240 | (l = 65536 + (1047552 & l) | 1023 & t.charCodeAt(++o)) >>> 18), n(128 | l >>> 12 & 63), n(128 | l >>> 6 & 63), n(128 | 63 & l)) : (n(224 | l >>> 12), n(128 | l >>> 6 & 63), n(128 | 63 & l));
				}
				return no(r, 0, s);
			}(So(e)), { mtime: 0 });
			return {
				contentType: bo,
				body: r.buffer.slice(r.byteOffset, r.byteOffset + r.byteLength),
				estimatedSize: r.byteLength
			};
		}
		if (i === Un.Base64) {
			var n = ((t) => "data=" + encodeURIComponent("string" == typeof t ? t : So(t)))(function(t) {
				return t ? btoa(encodeURIComponent(t).replace(/%([0-9A-F]{2})/g, ((t, e) => String.fromCharCode(parseInt(e, 16))))) : t;
			}(So(e)));
			return {
				contentType: "application/x-www-form-urlencoded",
				body: n,
				estimatedSize: new Blob([n]).size
			};
		}
		var o = So(e);
		return {
			contentType: "application/json",
			body: o,
			estimatedSize: new Blob([o]).size
		};
	}
}, $o = (t) => {
	var e, i, r = () => ({
		url: Eo(t.url, "compression"),
		encodedBody: To(f({}, t, {
			compression: void 0,
			xt: void 0
		}))
	});
	try {
		e = To(t);
	} catch (e) {
		if (R(t.compression, Qs(t.url, "compression"))) return li.error("Failed to gzip request body, sending uncompressed payload", e), r();
		throw e;
	}
	return e && R(t.compression, Qs(t.url, "compression")) && !((i = e.body) instanceof ArrayBuffer ? k(new Uint8Array(i)) : ArrayBuffer.isView(i) && k(new Uint8Array(i.buffer, i.byteOffset, i.byteLength))) ? (wo = !0, r()) : {
		url: t.url,
		encodedBody: e
	};
}, ko = (t) => {
	try {
		return $o(t);
	} catch (e) {
		li.error(e), null == t.callback || t.callback({
			statusCode: 0,
			error: e
		});
		return;
	}
}, Ro = function() {
	var t = p((function* (t) {
		var i = yield function(t, e, i) {
			return C.apply(this, arguments);
		}(So(t.data), v.DEBUG, { rethrow: !0 });
		if (!i) return t;
		var r = yield i.arrayBuffer();
		return f({}, t, { xt: {
			contentType: bo,
			body: r,
			estimatedSize: r.byteLength
		} });
	}));
	return function(e) {
		return t.apply(this, arguments);
	};
}(), Po = (t, e) => xo(t, {
	_: (/* @__PURE__ */ new Date()).getTime().toString(),
	ver: v.JS_SDK_VERSION,
	compression: e
}), Io = [];
n && Io.push({
	transport: "fetch",
	method(t) {
		var e, i = ko(t);
		if (i) {
			var { url: r, encodedBody: s } = i, { contentType: o, body: l, estimatedSize: u } = null != s ? s : {}, h = new Headers();
			xr(t.headers, (function(t, e) {
				h.append(e, t);
			})), o && h.append("Content-Type", o);
			var d = null, v = !1;
			if (a) {
				var c = new a();
				d = {
					signal: c.signal,
					timeout: setTimeout((() => {
						var e, i;
						v = !0, c.abort((e = t.timeout, (i = /* @__PURE__ */ new Error("PostHog request timed out" + (e ? " after " + e + "ms" : ""))).name = "AbortError", i));
					}), t.timeout)
				};
			}
			n(r, f({
				method: (null == t ? void 0 : t.method) || "GET",
				headers: h,
				keepalive: "POST" === t.method && 52428.8 > (u || 0),
				body: l,
				signal: null == (e = d) ? void 0 : e.signal
			}, t.fetchOptions)).then(((e) => e.text().then(((i) => {
				var r = {
					statusCode: e.status,
					text: i
				};
				if (200 === e.status) try {
					r.json = JSON.parse(i);
				} catch (t) {
					li.error(t);
				}
				null == t.callback || t.callback(r);
			})))).catch(((e) => {
				v && "AbortError" === (null == e ? void 0 : e.name) ? li.warn(e) : li.error(e), null == t.callback || t.callback({
					statusCode: 0,
					error: e
				});
			})).finally((() => d ? clearTimeout(d.timeout) : null));
		}
	}
}), o && Io.push({
	transport: "XHR",
	method(t) {
		var e = ko(t);
		if (e) {
			var i = new o(), { url: r, encodedBody: s } = e;
			i.open(t.method || "GET", r, !0);
			var { contentType: n, body: a } = null != s ? s : {};
			xr(t.headers, (function(t, e) {
				i.setRequestHeader(e, t);
			})), n && i.setRequestHeader("Content-Type", n), t.timeout && (i.timeout = t.timeout), i.onreadystatechange = () => {
				if (4 === i.readyState) {
					var e = {
						statusCode: i.status,
						text: i.responseText
					};
					if (200 === i.status) try {
						e.json = JSON.parse(i.responseText);
					} catch (t) {}
					null == t.callback || t.callback(e);
				}
			}, i.send(a);
		}
	}
}), null != i && i.sendBeacon && Io.push({
	transport: "sendBeacon",
	method(t) {
		try {
			var { url: e, encodedBody: r } = $o(t), { contentType: s, body: n } = null != r ? r : {};
			if (!n) return;
			var o = n instanceof Blob ? n : new Blob([n], { type: s });
			i.sendBeacon(e, o);
		} catch (t) {}
	}
});
var Oo = 3e3;
var Co = class {
	constructor(t, e) {
		this.br = !0, this._r = [], this.wr = lt((null == e ? void 0 : e.flush_interval_ms) || Oo, 250, 5e3, li.createLogger("flush interval"), Oo), this.kr = t;
	}
	enqueue(t) {
		this._r.push(t), this.Sr || this.Cr();
	}
	unload() {
		this.Ir();
		var t = this._r.length > 0 ? this.Tr() : {}, e = Object.values(t);
		[...e.filter(((t) => 0 === t.url.indexOf("/e"))), ...e.filter(((t) => 0 !== t.url.indexOf("/e")))].map(((t) => {
			this.Er(f({}, t, { transport: "sendBeacon" }));
		}));
	}
	enable() {
		this.br = !1, this.Cr();
	}
	Cr() {
		var t = this;
		this.br || (this.Sr = setTimeout((() => {
			if (this.Ir(), this._r.length > 0) {
				var e = this.Tr(), i = function() {
					var i = e[r], s = (/* @__PURE__ */ new Date()).getTime();
					i.data && B(i.data) && xr(i.data, ((t) => {
						t.offset = Math.abs(t.timestamp - s), delete t.timestamp;
					})), t.Er(i);
				};
				for (var r in e) i();
			}
		}), this.wr));
	}
	Er(t) {
		try {
			this.kr(t);
		} catch (t) {
			li.error(t);
		}
	}
	Ir() {
		clearTimeout(this.Sr), this.Sr = void 0;
	}
	Tr() {
		var t = {};
		return xr(this._r, ((e) => {
			var i, r = e, s = (r ? r.batchKey : null) || r.url;
			V(t[s]) && (t[s] = f({}, r, { data: [] })), null == (i = t[s].data) || i.push(r.data);
		})), this._r = [], t;
	}
};
var Ao = ["retriesPerformedSoFar"];
var Fo = class {
	constructor(e) {
		this.Mr = !1, this.Pr = 3e3, this._r = [], this._instance = e, this._r = [], this.Rr = !0, !V(t) && "onLine" in t.navigator && (this.Rr = t.navigator.onLine, this.Or = () => {
			this.Rr = !0, this.Lr();
		}, this.Fr = () => {
			this.Rr = !1;
		}, Or(t, "online", this.Or), Or(t, "offline", this.Fr));
	}
	get length() {
		return this._r.length;
	}
	retriableRequest(t) {
		var { retriesPerformedSoFar: e } = t, i = _(t, Ao);
		Q(e) && (i.url = xo(i.url, { retry_count: e })), this._instance._send_request(f({}, i, { callback: (t) => {
			if (200 !== t.statusCode && (400 > t.statusCode || t.statusCode >= 500)) {
				if ((0 === t.statusCode ? 3 : 10) > (null != e ? e : 0)) return void this.st(f({ retriesPerformedSoFar: e }, i));
				0 === t.statusCode && li.warn("Request failed before receiving an HTTP response; this can happen due to network issues, CORS, browser blocking, or ad blockers. Stopped retrying after " + (null != e ? e : 0) + " retries.");
			}
			null == i.callback || i.callback(t);
		} }));
	}
	st(t) {
		var e = t.retriesPerformedSoFar || 0;
		t.retriesPerformedSoFar = e + 1;
		var i = function(t) {
			var e = 3e3 * Math.pow(2, t), i = e / 2, r = Math.min(18e5, e), s = Math.random() - .5;
			return Math.ceil(r + s * (r - i));
		}(e), r = Date.now() + i;
		this._r.push({
			retryAt: r,
			requestOptions: t
		});
		var s = "Enqueued failed request for retry in " + i;
		navigator.onLine || (s += " (Browser is offline)"), li.warn(s), this.Mr || (this.Mr = !0, this.Ar());
	}
	Ar() {
		if (this.$r && clearTimeout(this.$r), 0 === this._r.length) return this.Mr = !1, void (this.$r = void 0);
		this.$r = setTimeout((() => {
			this.Rr && this._r.length > 0 && this.Lr(), this.Ar();
		}), this.Pr);
	}
	Lr() {
		var t = Date.now(), e = [], i = this._r.filter(((i) => t > i.retryAt || (e.push(i), !1)));
		if (this._r = e, i.length > 0) for (var { requestOptions: r } of i) this.retriableRequest(r);
	}
	unload() {
		for (var { requestOptions: e } of (this.$r && (clearTimeout(this.$r), this.$r = void 0), this.Mr = !1, V(t) || (this.Or && (t.removeEventListener("online", this.Or), this.Or = void 0), this.Fr && (t.removeEventListener("offline", this.Fr), this.Fr = void 0)), this._r)) try {
			this._instance._send_request(f({}, e, { transport: "sendBeacon" }));
		} catch (t) {
			li.error(t);
		}
		this._r = [];
	}
};
var Mo = class {
	constructor(t) {
		this.Dr = () => {
			var t, e, i, r;
			this.Nr || (this.Nr = {});
			var s = this.scrollElement(), n = this.scrollY(), o = s ? Math.max(0, s.scrollHeight - s.clientHeight) : 0, a = n + ((null == s ? void 0 : s.clientHeight) || 0), l = (null == s ? void 0 : s.scrollHeight) || 0;
			this.Nr.lastScrollY = Math.ceil(n), this.Nr.maxScrollY = Math.max(n, null !== (t = this.Nr.maxScrollY) && void 0 !== t ? t : 0), this.Nr.maxScrollHeight = Math.max(o, null !== (e = this.Nr.maxScrollHeight) && void 0 !== e ? e : 0), this.Nr.lastContentY = a, this.Nr.maxContentY = Math.max(a, null !== (i = this.Nr.maxContentY) && void 0 !== i ? i : 0), this.Nr.maxContentHeight = Math.max(l, null !== (r = this.Nr.maxContentHeight) && void 0 !== r ? r : 0);
		}, this._instance = t;
	}
	get qr() {
		return this._instance.config.scroll_root_selector;
	}
	getContext() {
		return this.Nr;
	}
	resetContext() {
		var t = this.Nr;
		return setTimeout(this.Dr, 0), t;
	}
	startMeasuringScrollPosition() {
		Or(t, "scroll", this.Dr, { capture: !0 }), Or(t, "scrollend", this.Dr, { capture: !0 }), Or(t, "resize", this.Dr);
	}
	scrollElement() {
		if (!this.qr) return null == t ? void 0 : t.document.documentElement;
		for (var i of B(this.qr) ? this.qr : [this.qr]) {
			var r = null == t ? void 0 : t.document.querySelector(i);
			if (r) return r;
		}
	}
	Br(e) {
		var i = "y" === e ? "scrollTop" : "scrollLeft";
		if (this.qr) {
			var r = this.scrollElement();
			return r && r[i] || 0;
		}
		return t ? "y" === e ? t.scrollY || t.pageYOffset || t.document.documentElement.scrollTop || 0 : t.scrollX || t.pageXOffset || t.document.documentElement.scrollLeft || 0 : 0;
	}
	scrollY() {
		return this.Br("y");
	}
	scrollX() {
		return this.Br("x");
	}
};
var Do = (t) => vn(null == t ? void 0 : t.config.mask_personal_data_properties, null == t ? void 0 : t.config.custom_personal_data_properties, null == t ? void 0 : t.config.disable_capture_url_hashes);
var Lo = class {
	constructor(t, e, i, r) {
		this.jr = (t) => {
			var e = this.Hr();
			if (!e || e.sessionId !== t) {
				var i = {
					sessionId: t,
					props: this.Ur(this._instance)
				};
				this.zr.register({ [Zi]: i });
			}
		}, this._instance = t, this.Vr = e, this.zr = i, this.Ur = r || Do, this.Vr.onSessionId(this.jr);
	}
	Hr() {
		return this.zr.props[Zi];
	}
	getSetOnceProps() {
		var t, e = null == (t = this.Hr()) ? void 0 : t.props;
		return e ? "r" in e ? cn(e, this._instance.config.disable_capture_url_hashes) : {
			$referring_domain: e.referringDomain,
			$pathname: e.initialPathName,
			utm_source: e.utm_source,
			utm_campaign: e.utm_campaign,
			utm_medium: e.utm_medium,
			utm_content: e.utm_content,
			utm_term: e.utm_term
		} : {};
	}
	getSessionProps() {
		var t = {};
		return xr(Rr(this.getSetOnceProps()), ((e, i) => {
			"$current_url" === i && (i = "url"), t["$session_entry_" + L(i)] = e;
		})), t;
	}
};
var No = class {
	constructor() {
		this.Wr = {};
	}
	on(t, e) {
		return this.Wr[t] || (this.Wr[t] = []), this.Wr[t].push(e), () => {
			this.Wr[t] = this.Wr[t].filter(((t) => t !== e));
		};
	}
	emit(t, e) {
		for (var i of this.Wr[t] || []) i(e);
		for (var r of this.Wr["*"] || []) r(t, e);
	}
};
var Uo = ui("[SessionId]");
var jo = class {
	on(t, e) {
		return this.Gr.on(t, e);
	}
	constructor(t, e, i) {
		var r;
		if (this.Zr = null, this.Qr = [], this.Jr = void 0, this.Yr = !1, this.Gr = new No(), this.Kr = (t, e) => !(!Q(t) || !Q(e)) && Math.abs(t - e) > this.sessionTimeoutMs, !t.persistence) throw new Error("SessionIdManager requires a PostHogPersistence instance");
		if (t.config.cookieless_mode === vr) throw new Error("SessionIdManager cannot be used with cookieless_mode=\"always\"");
		this.Se = t.config, this.zr = t.persistence, this.Xr = void 0, this.ei = void 0, this._sessionStartTimestamp = null, this._sessionActivityTimestamp = null, this.ti = e || Nr, this.ri = i || Nr;
		var s = this.Se.persistence_name || this.Se.token;
		if (this._sessionTimeoutMs = 1e3 * lt(this.Se.session_idle_timeout_seconds || 1800, 60, 36e3, Uo.createLogger("session_idle_timeout_seconds"), 1800), t.register({ $configured_session_timeout_ms: this._sessionTimeoutMs }), this.ii(), this.ni = "ph_" + s + "_window_id", this.si = "ph_" + s + "_primary_window_exists", this.oi()) {
			var n = Kr.F(this.ni), o = Kr.F(this.si);
			n && !o ? this.Xr = n : Kr.P(this.ni), Kr.q(this.si, !0);
		}
		if (null != (r = this.Se.bootstrap) && r.sessionID) try {
			var a = ((t) => {
				var e = this.Se.bootstrap.sessionID.replace(/-/g, "");
				if (32 !== e.length) throw new Error("Not a valid UUID");
				if ("7" !== e[12]) throw new Error("Not a UUIDv7");
				return parseInt(e.substring(0, 12), 16);
			})();
			this.ai(this.Se.bootstrap.sessionID, (/* @__PURE__ */ new Date()).getTime(), a);
		} catch (t) {
			Uo.error("Invalid sessionID in bootstrap", t);
		}
		this.li();
	}
	get sessionTimeoutMs() {
		return this._sessionTimeoutMs;
	}
	onSessionId(t) {
		return V(this.Qr) && (this.Qr = []), this.Qr.push(t), this.ei && t(this.ei, this.Xr), () => {
			this.Qr = this.Qr.filter(((e) => e !== t));
		};
	}
	oi() {
		return "memory" !== this.Se.persistence && !this.zr.Vt && Kr.N();
	}
	ui(t) {
		t !== this.Xr && (this.Xr = t, this.oi() && Kr.q(this.ni, t));
	}
	hi() {
		return this.Xr ? this.Xr : this.oi() ? Kr.F(this.ni) : null;
	}
	di(t) {
		var e = this.Zr;
		return !Y(e) && !Y(t) && 5e3 > Math.abs(t - e);
	}
	ai(t, e, i) {
		var r = e !== this._sessionActivityTimestamp, s = !(t !== this.ei || i !== this._sessionStartTimestamp);
		this._sessionStartTimestamp = i, this._sessionActivityTimestamp = e, this.ei = t, s && !r || s && this.di(e) || (this.Zr = e, this.zr.register({ [Ci]: [
			e,
			t,
			i
		] }));
	}
	ci() {
		var t, e = null == (t = this.Se) ? void 0 : t.persistence_save_debounce_ms;
		return Q(e) && e > 0;
	}
	vi() {
		this.ci() ? this.zr.refreshKey(Ci) : (this.zr.flush(), this.zr.load());
	}
	fi() {
		var t;
		if (!Y(this._sessionActivityTimestamp) && this._sessionActivityTimestamp !== this.Zr) {
			this.vi();
			var [, e, i] = this.pi();
			e === this.ei && i === this._sessionStartTimestamp && (this.Zr = this._sessionActivityTimestamp, this.zr.register({ [Ci]: [
				this._sessionActivityTimestamp,
				null !== (t = this.ei) && void 0 !== t ? t : null,
				this._sessionStartTimestamp
			] }), this.zr.flush());
		}
	}
	gi() {
		var [t] = this.pi(), e = Q(t) ? t : 0, i = Q(this._sessionActivityTimestamp) ? this._sessionActivityTimestamp : 0;
		return Math.max(e, i);
	}
	mi(t) {
		return this.vi(), this.Kr(t, this.gi());
	}
	pi() {
		var t = this.zr.props[Ci];
		return B(t) && 2 === t.length && t.push(t[0]), t || [
			0,
			null,
			0
		];
	}
	resetSessionId() {
		this.Zr = null, clearTimeout(this.yi), this.yi = void 0, this.ai(null, null, null);
	}
	destroy() {
		this.Yr = !0, this.fi(), clearTimeout(this.yi), this.yi = void 0, this.Jr && t && (t.removeEventListener(gr, this.Jr, { capture: !1 }), this.Jr = void 0), this.Qr = [];
	}
	li() {
		this.Jr = () => {
			this.fi(), this.oi() && Kr.P(this.si);
		}, Or(t, gr, this.Jr, { capture: !1 });
	}
	checkAndGetSessionAndWindowId(t, e) {
		if (void 0 === t && (t = !1), void 0 === e && (e = null), this.Se.cookieless_mode === vr) throw new Error("checkAndGetSessionAndWindowId should not be called with cookieless_mode=\"always\"");
		var i = e || (/* @__PURE__ */ new Date()).getTime(), [, r, s] = this.pi(), n = this.gi(), o = this.hi(), a = Q(s) && Math.abs(i - s) > 864e5, l = !1, u = !1, h = !r, d = r, v = !h && !t && this.Kr(i, n);
		v && ((v = this.mi(i)) || Uo.info("cross-tab refresh kept the session alive", { sessionId: r }), [, r, s] = this.pi()), h || v || a ? (r = this.ti(), o = this.ri(), Uo.info("new session ID generated", {
			sessionId: r,
			windowId: o,
			changeReason: {
				noSessionId: h,
				activityTimeout: v,
				sessionPastMaximumLength: a
			}
		}), s = i, l = !0) : (o || (o = this.ri(), l = !0), (u = r !== d) && (Uo.info("adopted cross-tab session id", {
			sessionId: r,
			windowId: o
		}), l = !0));
		var c = Q(n) && t && !a ? n : i, p = Q(s) ? s : (/* @__PURE__ */ new Date()).getTime();
		this.ui(o), this.ai(r, c, p), t || this.ii();
		var f = {
			noSessionId: h,
			activityTimeout: v,
			sessionPastMaximumLength: a,
			crossTabAdoption: u
		};
		return l && this.Qr.forEach(((t) => t(r, o, f))), {
			sessionId: r,
			windowId: o,
			sessionStartTimestamp: p,
			changeReason: l ? f : void 0,
			lastActivityTimestamp: n
		};
	}
	ii() {
		this.Yr || (clearTimeout(this.yi), this.yi = setTimeout((() => {
			if (!this.Yr) if (this.mi((/* @__PURE__ */ new Date()).getTime())) {
				var t = this.ei;
				this.resetSessionId(), this.Gr.emit("forcedIdleReset", { idleSessionId: t });
			} else this.ii();
		}), 1.1 * this.sessionTimeoutMs));
	}
};
var Bo = function(t, e) {
	if (!t) return !1;
	var i = t.userAgent;
	if (i && F(i, e)) return !0;
	try {
		var r = null == t ? void 0 : t.userAgentData;
		if (null != r && r.brands && r.brands.some(((t) => F(null == t ? void 0 : t.brand, e)))) return !0;
	} catch (t) {}
	return !!t.webdriver;
};
function zo() {
	return (zo = p((function* () {
		var t = null == i ? void 0 : i.userAgentData;
		if (null != t && t.getHighEntropyValues) try {
			var e = yield t.getHighEntropyValues(["model"]), r = null == e ? void 0 : e.model;
			return G(r) && r.length > 0 ? r : void 0;
		} catch (t) {
			li.info("Unable to resolve $device_model from userAgentData.getHighEntropyValues", t);
			return;
		}
	}))).apply(this, arguments);
}
var Ho = function(t, e) {
	if (!function(t) {
		try {
			new RegExp(t);
		} catch (t) {
			return !1;
		}
		return !0;
	}(e)) return !1;
	try {
		return new RegExp(e).test(t);
	} catch (t) {
		return !1;
	}
};
function qo(t, e, i) {
	return So({
		distinct_id: t,
		userPropertiesToSet: e,
		userPropertiesToSetOnce: i
	});
}
var Vo = {
	exact: (t, e) => e.some(((e) => t.some(((t) => e === t)))),
	is_not: (t, e) => e.every(((e) => t.every(((t) => e !== t)))),
	regex: (t, e) => e.some(((e) => t.some(((t) => Ho(e, t))))),
	not_regex: (t, e) => e.every(((e) => t.every(((t) => !Ho(e, t))))),
	icontains: (t, e) => e.map(Go).some(((e) => t.map(Go).some(((t) => e.includes(t))))),
	not_icontains: (t, e) => e.map(Go).every(((e) => t.map(Go).every(((t) => !e.includes(t))))),
	gt: (t, e) => e.some(((e) => {
		var i = parseFloat(e);
		return !isNaN(i) && t.some(((t) => i > parseFloat(t)));
	})),
	lt: (t, e) => e.some(((e) => {
		var i = parseFloat(e);
		return !isNaN(i) && t.some(((t) => i < parseFloat(t)));
	}))
}, Go = (t) => t.toLowerCase();
function Wo(t, e) {
	return !t || Object.entries(t).every(((t) => {
		var [i, r] = t, s = null == e ? void 0 : e[i];
		if (V(s) || Y(s)) return !1;
		var n = [String(s)], o = Vo[r.operator];
		return !!o && o(r.values, n);
	}));
}
var Yo = "custom", Ko = "i.posthog.com", Jo = /^\/static\//;
var Qo = class {
	constructor(t) {
		this.bi = {}, this.instance = t;
	}
	get apiHost() {
		var t = this.instance.config.api_host.trim().replace(/\/$/, "");
		return "https://app.posthog.com" === t ? "https://us.i.posthog.com" : t;
	}
	get flagsApiHost() {
		var t = this.instance.config.flags_api_host;
		return t ? t.trim().replace(/\/$/, "") : this.apiHost;
	}
	get uiHost() {
		var t, e = null == (t = this.instance.config.ui_host) ? void 0 : t.replace(/\/$/, "");
		return e || (e = this.apiHost.replace("." + Ko, ".posthog.com")), "https://app.posthog.com" === e ? "https://us.posthog.com" : e;
	}
	get region() {
		return this.bi[this.apiHost] || (this.bi[this.apiHost] = /https:\/\/(app|us|us-assets)(\.i)?\.posthog\.com/i.test(this.apiHost) ? "us" : /https:\/\/(eu|eu-assets)(\.i)?\.posthog\.com/i.test(this.apiHost) ? "eu" : Yo), this.bi[this.apiHost];
	}
	wi(t) {
		if (Jo.test(t)) {
			var e = this.instance.config.asset_host;
			if ("string" == typeof e) return e.trim().replace(/\/$/, "") || void 0;
		}
	}
	endpointFor(t, e) {
		if (void 0 === e && (e = ""), e && (e = "/" === e[0] ? e : "/" + e), "ui" === t) return this.uiHost + e;
		if ("flags" === t) return this.flagsApiHost + e;
		if ("assets" === t) {
			var i = this.wi(e);
			if (i) return "" + i + e;
		}
		if (this.region === Yo) return this.apiHost + e;
		var r = Ko + e;
		switch (t) {
			case "assets": return "https://" + this.region + "-assets." + r;
			case "api": return "https://" + this.region + "." + r;
		}
	}
};
var Xo = ui("[Surveys]"), Zo = "seenSurvey_", ta = (t) => {
	try {
		var e = ((t) => ((t, e) => {
			var i = "" + Zo + e.id;
			return e.current_iteration && e.current_iteration > 0 && (i = "" + Zo + e.id + "_" + e.current_iteration), i;
		})(0, t))(t);
		if (localStorage.getItem(e)) return;
		localStorage.setItem(e, "true");
	} catch (t) {
		Xo.error("Failed to persist survey seen state", t);
	}
}, ea = [
	Sn.Popover,
	Sn.Widget,
	Sn.API
], ia = {
	ignoreConditions: !1,
	ignoreDelay: !1,
	displayType: In.Popover
}, ra = ui("[PostHog ExternalIntegrations]"), sa = {
	intercom: "intercom-integration",
	crispChat: "crisp-chat-integration"
};
var na = class {
	constructor(t) {
		this._instance = t;
	}
	Mt(t, e) {
		var i;
		null == (i = h.__PosthogExtensions__) || null == i.loadExternalDependency || i.loadExternalDependency(this._instance, t, ((t) => {
			if (t) return ra.error("failed to load script", t);
			e();
		}));
	}
	startIfEnabledOrStop() {
		var t = this, e = function(e) {
			var i, s, n;
			!r || null != (i = h.__PosthogExtensions__) && null != (i = i.integrations) && i[e] || t.Mt(sa[e], (() => {
				var i;
				null == (i = h.__PosthogExtensions__) || null == (i = i.integrations) || null == (i = i[e]) || i.start(t._instance);
			})), !r && null != (s = h.__PosthogExtensions__) && null != (s = s.integrations) && s[e] && (null == (n = h.__PosthogExtensions__) || null == (n = n.integrations) || null == (n = n[e]) || n.stop());
		};
		for (var [i, r] of Object.entries(null !== (s = this._instance.config.integrations) && void 0 !== s ? s : {})) {
			var s;
			e(i);
		}
	}
};
var oa, aa = {}, la = 0, ua = () => {}, ha = "Consent opt in/out is not valid with cookieless_mode=\"always\" and will be ignored", da = "Surveys module not available", va = "sanitize_properties is deprecated. Use before_send instead", ca = "Invalid value for property_denylist config: ", pa = "posthog", fa = !yo && -1 === (null == u ? void 0 : u.indexOf("MSIE")) && -1 === (null == u ? void 0 : u.indexOf("Mozilla")), _a = (e) => {
	var i;
	return f({
		api_host: "https://us.i.posthog.com",
		flags_api_host: null,
		ui_host: null,
		asset_host: null,
		token: "",
		autocapture: !0,
		cross_subdomain_cookie: Ir(null == r ? void 0 : r.location),
		persistence: "localStorage+cookie",
		persistence_name: "",
		cookie_persisted_properties: [],
		loaded: ua,
		save_campaign_params: !0,
		custom_campaign_params: [],
		custom_blocked_useragents: [],
		save_referrer: !0,
		capture_pageleave: "if_capture_pageview",
		defaults: null != e ? e : "unset",
		__preview_deferred_init_extensions: !1,
		__preview_external_dependency_versioned_paths: !1,
		__preview_cookie_wins_on_conflict: !1,
		debug: s && G(null == s ? void 0 : s.search) && -1 !== s.search.indexOf("__posthog_debug=true") || !1,
		cookie_expiration: 365,
		upgrade: !1,
		disable_session_recording: !1,
		disable_persistence: !1,
		disable_web_experiments: !0,
		disable_surveys: !1,
		disable_surveys_automatic_display: !1,
		disable_conversations: !1,
		disable_product_tours: !1,
		disableDeviceModel: !1,
		disable_external_dependency_loading: !1,
		strict_script_versioning: !1,
		enable_recording_console_log: void 0,
		secure_cookie: "https:" === (null == t || null == (i = t.location) ? void 0 : i.protocol),
		ip: !1,
		opt_out_capturing_by_default: !1,
		opt_out_persistence_by_default: !1,
		opt_out_useragent_filter: !1,
		opt_out_capturing_persistence_type: "localStorage",
		consent_persistence_name: null,
		opt_out_capturing_cookie_prefix: null,
		opt_in_site_apps: !1,
		property_denylist: [],
		respect_dnt: !1,
		sanitize_properties: null,
		request_headers: {},
		request_batching: !0,
		properties_string_max_length: 65535,
		mask_all_element_attributes: !1,
		mask_all_text: !1,
		mask_personal_data_properties: !1,
		custom_personal_data_properties: [],
		advanced_disable_flags: !1,
		advanced_disable_decide: !1,
		advanced_disable_feature_flags: !1,
		advanced_disable_feature_flags_on_first_load: !1,
		advanced_only_evaluate_survey_feature_flags: !1,
		advanced_feature_flags_dedup_per_session: !1,
		advanced_enable_surveys: !1,
		advanced_disable_toolbar_metrics: !1,
		feature_flag_request_timeout_ms: 3e3,
		surveys_request_timeout_ms: 1e4,
		on_request_error(t) {
			li.error("Bad HTTP status: " + t.statusCode + " " + t.text);
		},
		get_device_id: (t) => t,
		capture_performance: void 0,
		name: "posthog",
		bootstrap: {},
		disable_compression: !1,
		session_idle_timeout_seconds: 1800,
		person_profiles: fr,
		before_send: void 0,
		get_current_url: void 0,
		request_queue_config: { flush_interval_ms: Oo },
		error_tracking: {},
		_onCapture: ua
	}, ((t) => ({
		rageclick: t && t >= "2026-05-30" ? {
			content_ignorelist: gs,
			ignore_text_selection: !0
		} : !t || "2025-11-30" > t || { content_ignorelist: !0 },
		capture_pageview: !t || "2025-05-24" > t || "history_change",
		session_recording: t && t >= "2026-06-25" ? {
			strictMinimumDuration: !0,
			canvasCapture: { resolutionScale: .6 },
			streamNetworkBody: !0
		} : t && t >= "2026-05-30" ? {
			strictMinimumDuration: !0,
			canvasCapture: { resolutionScale: .6 }
		} : t && t >= "2025-11-30" ? { strictMinimumDuration: !0 } : {},
		external_scripts_inject_target: t && t >= "2026-01-30" ? "head" : "body",
		internal_or_test_user_hostname: t && t >= "2026-01-30" ? /^(localhost|127\.0\.0\.1)$/ : void 0,
		persistence_save_debounce_ms: t && t >= "2026-05-30" ? 250 : 0,
		split_storage: !(!t || "2026-05-30" > t),
		detect_google_search_app: !(!t || "2026-05-30" > t),
		disable_capture_url_hashes: !(!t || "2026-06-25" > t)
	}))(e));
}, ga = [
	["process_person", "person_profiles"],
	["xhr_headers", "request_headers"],
	["cookie_name", "persistence_name"],
	["disable_cookie", "disable_persistence"],
	["__preview_disable_beacon", "disable_beacon"],
	["store_google", "save_campaign_params"],
	["verbose", "debug"]
], ma = (t) => {
	var e = {};
	for (var [i, r] of ga) V(t[i]) || (e[r] = t[i]);
	var s = Sr({}, e, t), n = t.__preview_external_dependency_versioned_paths;
	return V(n) || (V(t.strict_script_versioning) && (s.strict_script_versioning = !!n), G(n) && V(t.asset_host) && (s.asset_host = n)), B(t.property_blacklist) && (V(t.property_denylist) ? s.property_denylist = t.property_blacklist : B(t.property_denylist) ? s.property_denylist = [...t.property_blacklist, ...t.property_denylist] : li.error(ca + t.property_denylist)), s;
};
var ya = class {
	constructor() {
		this.__forceAllowLocalhost = !1;
	}
	get xi() {
		return this.__forceAllowLocalhost;
	}
	set xi(t) {
		li.error("WebPerformanceObserver is deprecated and has no impact on network capture. Use `_forceAllowLocalhostNetworkCapture` on `posthog.sessionRecording`"), this.__forceAllowLocalhost = t;
	}
};
var ba = class ba {
	ki(t, e) {
		if (t) {
			var i = this.Si.indexOf(t);
			-1 !== i && this.Si.splice(i, 1);
		}
		return this.Si.push(e), null == e.initialize || e.initialize(), e;
	}
	Ci() {
		return this.config.cookieless_mode === vr || this.config.cookieless_mode === dr && this.consent.isRejected();
	}
	get decideEndpointWasHit() {
		var t, e;
		return null !== (t = null == (e = this.featureFlags) ? void 0 : e.hasLoadedFlags) && void 0 !== t && t;
	}
	get flagsEndpointWasHit() {
		var t, e;
		return null !== (t = null == (e = this.featureFlags) ? void 0 : e.hasLoadedFlags) && void 0 !== t && t;
	}
	constructor() {
		var t;
		this.webPerformance = new ya(), this.Ii = !1, this.version = v.LIB_VERSION, this.Ti = new No(), this.Si = [], this._calculate_event_properties = this.calculateEventProperties.bind(this), this.config = _a(), this.SentryIntegration = qs, this.sentryIntegration = (t) => function(t, e) {
			var i = Hs(t, e);
			return {
				name: zs,
				processEvent: (t) => i(t)
			};
		}(this, t), this.__request_queue = [], this.__loaded = !1, this.analyticsDefaultEndpoint = "/e/", this.Ei = !1, this.Mi = null, this.Pi = null, this.Ri = null, this.scrollManager = new Mo(this), this.pageViewManager = new Vs(this), this.rateLimiter = new Mn(this), this.requestRouter = new Qo(this), this.consent = new Jr(this), this.externalIntegrations = new na(this);
		var e = null !== (t = ba.__defaultExtensionClasses) && void 0 !== t ? t : {};
		this.featureFlags = e.featureFlags && new e.featureFlags(this), this.toolbar = e.toolbar && new e.toolbar(this), this.surveys = e.surveys && new e.surveys(this), this.conversations = e.conversations && new e.conversations(this), this.logs = e.logs && new e.logs(this), this.experiments = e.experiments && new e.experiments(this), this.exceptions = e.exceptions && new e.exceptions(this), this.people = {
			set: (t, e, i) => {
				var r = G(t) ? { [t]: e } : t;
				this.setPersonProperties(r), i?.({});
			},
			set_once: (t, e, i) => {
				var r = G(t) ? { [t]: e } : t;
				this.setPersonProperties(void 0, r), i?.({});
			}
		}, this.on("eventCaptured", ((t) => li.info("send \"" + (null == t ? void 0 : t.event) + "\"", t)));
	}
	init(t, e, i) {
		if (i && i !== pa) {
			var r, s = null !== (r = aa[i]) && void 0 !== r ? r : new ba();
			return s._init(t, e, i), aa[i] = s, aa[pa][i] = s, s;
		}
		return this._init(t, e, i);
	}
	_init(e, i, r) {
		var s, n;
		void 0 === i && (i = {});
		var o = G(e) ? e.trim() : "";
		if (!o) return li.critical("PostHog was initialized without a token. This likely indicates a misconfiguration. Please check the first argument passed to posthog.init()"), this;
		if (this.__loaded) return console.warn("[PostHog.js]", "You have already initialized PostHog! Re-initializing is a no-op"), this;
		this.__loaded = !0, this.config = {}, i.debug = this.Oi(i.debug), this.Li = i, this.Fi = [], i.person_profiles ? this.Pi = i.person_profiles : i.process_person && (this.Pi = i.process_person);
		var a = _a(i.defaults), l = ma(i), u = Sr({}, a, l, {
			name: r,
			token: o
		});
		H(a.rageclick) && H(l.rageclick) && (u.rageclick = Sr({}, a.rageclick, l.rageclick)), H(a.session_recording) && H(l.session_recording) && (u.session_recording = Sr({}, a.session_recording, l.session_recording)), this.set_config(u), this.config.on_xhr_error && li.error("on_xhr_error is deprecated. Use on_request_error instead"), this.compression = i.disable_compression ? void 0 : Un.GZipJS;
		var h = this.Ai();
		this.persistence = new yn(this.config, h), this.sessionPersistence = "sessionStorage" === this.config.persistence || "memory" === this.config.persistence ? this.persistence : new yn(f({}, this.config, { persistence: "sessionStorage" }), h, !1);
		var d = f({}, this.persistence.props), c = f({}, this.sessionPersistence.props);
		this.register({ $initialization_time: (/* @__PURE__ */ new Date()).toISOString() }), this.$i = new Co(((t) => this.Di(t)), this.config.request_queue_config), this.Ni = new Fo(this), this.__request_queue = [];
		var p = this.Ci();
		if (p || (this.sessionManager = new jo(this), this.sessionPropsManager = new Lo(this, this.sessionManager, this.persistence)), this.config.__preview_deferred_init_extensions ? (li.info("Deferring extension initialization to improve startup performance"), setTimeout((() => {
			this.qi(p);
		}), 0)) : (li.info("Initializing extensions synchronously"), this.qi(p)), v.DEBUG = v.DEBUG || this.config.debug, v.DEBUG && li.info("Starting in debug mode", {
			this: this,
			config: i,
			thisC: f({}, this.config),
			p: d,
			s: c
		}), !this.config.identity_distinct_id || null != (s = i.bootstrap) && s.distinctID || (i.bootstrap = f({}, i.bootstrap, {
			distinctID: this.config.identity_distinct_id,
			isIdentifiedID: !0
		})), void 0 !== (null == (n = i.bootstrap) ? void 0 : n.distinctID)) {
			var _ = i.bootstrap.distinctID, g = this.get_distinct_id(), m = this.persistence.get_property(Xi);
			if (i.bootstrap.isIdentifiedID && null != g && g !== _ && m === cr) this.identify(_);
			else if (i.bootstrap.isIdentifiedID && null != g && g !== _ && m === pr) li.warn("Bootstrap distinctID differs from an already-identified user. The existing identity is preserved. Call reset() before reinitializing if you intend to switch users.");
			else {
				var y = this.config.get_device_id(Nr()), b = i.bootstrap.isIdentifiedID ? y : _;
				this.persistence.set_property(Xi, i.bootstrap.isIdentifiedID ? pr : cr), this.register({
					distinct_id: _,
					$device_id: b
				});
			}
		}
		if (p) this.register_once({
			distinct_id: or,
			$device_id: null
		}, "");
		else if (!this.get_distinct_id()) {
			var w = this.config.get_device_id(Nr());
			this.register_once({
				distinct_id: w,
				$device_id: w
			}, ""), this.persistence.set_property(Xi, cr);
		}
		return Or(t, "onpagehide" in self ? "pagehide" : "unload", this._handle_unload.bind(this), { passive: !1 }), i.segment ? function(t, e) {
			var i = t.config.segment;
			if (!i) return e();
			(function(t, e) {
				var i = t.config.segment;
				if (!i) return e();
				var r = (i) => {
					var r = () => i.anonymousId() || Nr();
					t.config.get_device_id = r, i.id() && (t.register({
						distinct_id: i.id(),
						$device_id: r()
					}), t.persistence.set_property(Xi, pr)), e();
				}, s = i.user();
				"then" in s && z(s.then) ? s.then(r) : r(s);
			})(t, (() => {
				i.register(((t) => {
					"undefined" != typeof Promise && Promise.resolve || Bs.warn("This browser does not have Promise support, and can not use the segment integration");
					var e = (e, i) => {
						if (!i) return e;
						e.event.userId || e.event.anonymousId === t.get_distinct_id() || (Bs.info("No userId set, resetting PostHog"), t.reset()), e.event.userId && e.event.userId !== t.get_distinct_id() && (Bs.info("UserId set, identifying with PostHog"), t.identify(e.event.userId));
						var r = t.calculateEventProperties(i, e.event.properties);
						return e.event.properties = Object.assign({}, r, e.event.properties), e;
					};
					return {
						name: "PostHog JS",
						type: "enrichment",
						version: "1.0.0",
						isLoaded: () => !0,
						load: () => Promise.resolve(),
						track: (t) => e(t, t.event.event),
						page: (t) => e(t, mr),
						identify: (t) => e(t, br),
						screen: (t) => e(t, "$screen")
					};
				})(t)).then((() => {
					e();
				}));
			}));
		}(this, (() => this.Bi())) : this.Bi(), z(this.config._onCapture) && this.config._onCapture !== ua && (li.warn("onCapture is deprecated. Please use `before_send` instead"), this.on("eventCaptured", ((t) => this.config._onCapture(t.event, t)))), this.config.ip && li.warn("The `ip` config option has NO EFFECT AT ALL and has been deprecated. Use a custom transformation or \"Discard IP data\" project setting instead. See https://posthog.com/tutorials/web-redact-properties#hiding-customer-ip-address for more information."), this.config.disableDeviceModel || function() {
			return zo.apply(this, arguments);
		}().then(((t) => {
			t && this.register({ [pi]: t });
		})).catch(ua), this;
	}
	qi(t) {
		var e, i, r, s, n, o, a, l = performance.now(), u = f({}, ba.__defaultExtensionClasses, this.config.__extensionClasses), h = [];
		u.featureFlags && this.Si.push(this.featureFlags = null !== (e = this.featureFlags) && void 0 !== e ? e : new u.featureFlags(this)), u.exceptions && this.Si.push(this.exceptions = null !== (i = this.exceptions) && void 0 !== i ? i : new u.exceptions(this)), u.historyAutocapture && this.Si.push(this.historyAutocapture = new u.historyAutocapture(this)), u.tracingHeaders && this.Si.push(this.tracingHeaders = new u.tracingHeaders(this)), u.siteApps && this.Si.push(this.siteApps = new u.siteApps(this)), u.sessionRecording && !t && this.Si.push(this.sessionRecording = new u.sessionRecording(this)), this.config.disable_scroll_properties || h.push((() => {
			this.scrollManager.startMeasuringScrollPosition();
		})), u.autocapture && this.Si.push(this.autocapture = new u.autocapture(this)), u.surveys && this.Si.push(this.surveys = null !== (r = this.surveys) && void 0 !== r ? r : new u.surveys(this)), u.logs && this.Si.push(this.logs = null !== (s = this.logs) && void 0 !== s ? s : new u.logs(this)), u.conversations && this.Si.push(this.conversations = null !== (n = this.conversations) && void 0 !== n ? n : new u.conversations(this)), u.productTours && this.Si.push(this.productTours = new u.productTours(this)), u.heatmaps && this.Si.push(this.heatmaps = new u.heatmaps(this)), u.webVitalsAutocapture && this.Si.push(this.webVitalsAutocapture = new u.webVitalsAutocapture(this)), u.exceptionObserver && this.Si.push(this.exceptionObserver = new u.exceptionObserver(this)), u.deadClicksAutocapture && this.Si.push(this.deadClicksAutocapture = new u.deadClicksAutocapture(this, Us)), u.toolbar && this.Si.push(this.toolbar = null !== (o = this.toolbar) && void 0 !== o ? o : new u.toolbar(this)), u.experiments && this.Si.push(this.experiments = null !== (a = this.experiments) && void 0 !== a ? a : new u.experiments(this)), this.Si.forEach(((t) => {
			t.initialize && h.push((() => {
				null == t.initialize || t.initialize();
			}));
		})), h.push((() => {
			if (this.ji) {
				var t = this.ji;
				this.ji = void 0, this.pr(t);
			}
		})), this.Hi(h, l);
	}
	Hi(t, e) {
		for (; t.length > 0;) {
			if (this.config.__preview_deferred_init_extensions && performance.now() - e >= 30 && t.length > 0) return void setTimeout((() => {
				this.Hi(t, e);
			}), 0);
			var i = t.shift();
			if (i) try {
				i();
			} catch (t) {
				li.error("Error initializing extension:", t);
			}
		}
		var r = Math.round(performance.now() - e);
		this.register_for_session({
			[ar]: this.config.__preview_deferred_init_extensions ? "deferred" : "synchronous",
			[lr]: r
		}), this.config.__preview_deferred_init_extensions && li.info("PostHog extensions initialized (" + r + "ms)");
	}
	pr(t) {
		var e;
		if (!r || !r.body) return li.info("document not ready yet, trying again in 500 milliseconds..."), void setTimeout((() => {
			this.pr(t);
		}), 500);
		this.config.__preview_deferred_init_extensions && (this.ji = t), this.Ui = t, this.compression = void 0, t.supportedCompression && !this.config.disable_compression && (this.compression = M(t.supportedCompression, Un.GZipJS) ? Un.GZipJS : M(t.supportedCompression, Un.Base64) ? Un.Base64 : void 0), null != (e = t.analytics) && e.endpoint && (this.analyticsDefaultEndpoint = t.analytics.endpoint), this.set_config({ person_profiles: this.Pi ? this.Pi : fr }), this.Si.forEach(((e) => null == e.onRemoteConfig ? void 0 : e.onRemoteConfig(t)));
	}
	Bi() {
		try {
			this.config.loaded(this);
		} catch (t) {
			li.critical("`loaded` function failed", t);
		}
		if (this.zi(), this.config.internal_or_test_user_hostname && null != s && s.hostname) {
			var t = s.hostname, e = this.config.internal_or_test_user_hostname;
			("string" == typeof e ? t === e : e.test(t)) && this.setInternalOrTestUser();
		}
		this.config.capture_pageview && setTimeout((() => {
			(this.consent.isOptedIn() || this.Ci()) && this.Vi();
		}), 1), this.Wi = new Ln(this), this.Wi.load();
	}
	zi() {
		var t;
		this.is_capturing() && this.config.request_batching && (null == (t = this.$i) || t.enable());
	}
	_dom_loaded() {
		this.is_capturing() && Er(this.__request_queue, ((t) => this.Di(t))), this.__request_queue = [], this.zi();
	}
	_handle_unload() {
		var t, e, i, r;
		null == (t = this.surveys) || null == t.handlePageUnload || t.handlePageUnload(), this.config.request_batching ? (this.Gi() && this.capture(yr), null == (e = this.logs) || e.flushLogs("sendBeacon"), null == (i = this.$i) || i.unload(), null == (r = this.Ni) || r.unload()) : this.Gi() && this.capture(yr, null, { transport: "sendBeacon" });
	}
	_send_request(t) {
		this.__loaded ? fa ? this.__request_queue.push(t) : this.rateLimiter.isServerRateLimited(t.batchKey) ? t.fireCallbackOnDrop && (null == t.callback || t.callback({ statusCode: 429 })) : (t.transport = t.transport || this.config.api_transport, t.headers = f({}, this.config.request_headers, t.headers), t.compression = "best-available" === t.compression ? this.compression : t.compression, (V(this.config.disable_beacon) ? this.config.__preview_disable_beacon : this.config.disable_beacon) && (t.disableTransport = ["sendBeacon"]), t.fetchOptions = t.fetchOptions || this.config.fetch_options, ((t) => {
			var e, i, r, s = f({}, t);
			s.timeout = s.timeout || 6e4, s.url = Po(s.url, s.compression);
			var n = null !== (e = s.transport) && void 0 !== e ? e : "fetch", o = Io.filter(((t) => !s.disableTransport || !t.transport || !s.disableTransport.includes(t.transport))), a = null !== (i = null == (r = function(t, e) {
				for (var i = 0; t.length > i; i++) if (t[i].transport === n) return t[i];
			}(o)) ? void 0 : r.method) && void 0 !== i ? i : o[0].method;
			if (!a) throw new Error("No available transport method");
			"sendBeacon" !== n && s.data && s.compression === Un.GZipJS && l && "undefined" != typeof Promise && !wo ? Ro(s).then(((t) => {
				a(t);
			})).catch(((e) => {
				if (P(e)) return wo = !0, void a(f({}, s, {
					compression: void 0,
					url: Po(t.url, void 0)
				}));
				((t) => {
					if (!t || "object" != typeof t) return !1;
					var e = "name" in t ? String(t.name) : "";
					return P(t) || e === T;
				})(e) && (wo = !0), a(s);
			})) : a(s);
		})(f({}, t, { callback: (e) => {
			var i, r;
			this.rateLimiter.checkForLimiting(e), 400 > e.statusCode || null == (i = (r = this.config).on_request_error) || i.call(r, e), null == t.callback || t.callback(e);
		} }))) : t.fireCallbackOnDrop && (null == t.callback || t.callback({ statusCode: 0 }));
	}
	Di(t) {
		this.Ni ? this.Ni.retriableRequest(t) : this._send_request(t);
	}
	_execute_array(t) {
		la++;
		try {
			var e, i = [], r = [], s = [];
			Er(t, ((t) => {
				if (t) if (B(e = t[0])) s.push(t);
				else if (z(t)) try {
					t.call(this);
				} catch (e) {
					li.error("Error executing queued PostHog call", t, e);
				}
				else B(t) && "alias" === e ? i.push(t) : B(t) && -1 !== e.indexOf("capture") && z(this[e]) ? s.push(t) : r.push(t);
			}));
			var n = function(t, e) {
				Er(t, (function(t) {
					try {
						if (B(t[0])) {
							var i = e;
							xr(t, (function(t) {
								i = i[t[0]].apply(i, t.slice(1));
							}));
						} else e[t[0]].apply(e, t.slice(1));
					} catch (e) {
						li.error("Error executing queued PostHog call", t, e);
					}
				}));
			};
			n(i, this), n(r, this), n(s, this);
		} finally {
			la--;
		}
	}
	push(t) {
		if (la > 0 && B(t) && G(t[0])) {
			var e = ba.prototype[t[0]];
			z(e) && e.apply(this, t.slice(1));
		} else this._execute_array([t]);
	}
	capture(t, e, i) {
		var r, s, n, o, a;
		if (this.__loaded && this.persistence && this.sessionPersistence && this.$i) {
			if (this.is_capturing()) if (!V(t) && G(t)) {
				var l = !this.config.opt_out_useragent_filter && this._is_bot();
				if (!l || this.config.__preview_capture_bot_pageviews) {
					var u = null != i && i.skip_client_rate_limiting ? void 0 : this.rateLimiter.clientRateLimitContext();
					if (null == u || !u.isRateLimited) {
						null != e && e.$current_url && !G(null == e ? void 0 : e.$current_url) && (li.error("Invalid `$current_url` property provided to `posthog.capture`. Input must be a string. Ignoring provided value."), null == e || delete e.$current_url), "$exception" !== t || null != i && i.Zi || li.warn("Using `posthog.capture('$exception')` is unreliable because it does not attach required metadata. Use `posthog.captureException(error)` instead, which attaches required metadata automatically."), this.sessionPersistence.update_search_keyword(), this.config.save_campaign_params && this.sessionPersistence.update_campaign_params(), this.config.save_referrer && this.sessionPersistence.update_referrer_info(), (this.config.save_campaign_params || this.config.save_referrer) && this.persistence.set_initial_person_info();
						var h = /* @__PURE__ */ new Date(), d = (null == i ? void 0 : i.timestamp) || h, v = fe(null == i ? void 0 : i.uuid, Nr), c = {
							uuid: v,
							event: t,
							properties: this.calculateEventProperties(t, e || {}, d, v)
						};
						t === mr && this.config.__preview_capture_bot_pageviews && l && (c.event = "$bot_pageview", c.properties.$browser_type = "bot"), u && (c.properties.$lib_rate_limit_remaining_tokens = u.remainingTokens), null != i && i.$set && (c.$set = null == i ? void 0 : i.$set);
						var p = null == i ? void 0 : i.$unset;
						p && (c.$unset = p);
						var _, g, m, y = this.Qi(null == i ? void 0 : i.$set_once, t !== wr, t === br);
						if (y && (c.$set_once = y), null != i && i._noTruncate || (s = this.config.properties_string_max_length, n = c, o = (t) => G(t) ? t.slice(0, s) : t, a = /* @__PURE__ */ new Set(), c = function t(e, i) {
							return e !== Object(e) ? o ? o(e) : e : a.has(e) ? void 0 : (a.add(e), B(e) ? (r = [], Er(e, ((e) => {
								r.push(t(e));
							}))) : (r = {}, xr(e, ((e, i) => {
								a.has(e) || (r[i] = t(e, i));
							}))), r);
							var r;
						}(n)), c.timestamp = d, V(null == i ? void 0 : i.timestamp) || (c.properties.$event_time_override_provided = !0, c.properties.$event_time_override_system_time = h), t === Rn.DISMISSED || t === Rn.SENT) {
							var b = null == e ? void 0 : e[Pn.SURVEY_ID], w = null == e ? void 0 : e[Pn.SURVEY_ITERATION];
							ta({
								id: b,
								current_iteration: w
							}), c.$set = f({}, c.$set, { [(_ = {
								id: b,
								current_iteration: w
							}, g = t === Rn.SENT ? "responded" : "dismissed", m = "$survey_" + g + "/" + _.id, _.current_iteration && _.current_iteration > 0 && (m = "$survey_" + g + "/" + _.id + "/" + _.current_iteration), m)]: !0 });
						} else t === Rn.SHOWN && (c.$set = f({}, c.$set, { [Pn.SURVEY_LAST_SEEN_DATE]: (/* @__PURE__ */ new Date()).toISOString() }));
						if (t === Cn.SHOWN) {
							var E = null == e ? void 0 : e[An.TOUR_TYPE];
							E && (c.$set = f({}, c.$set, { [An.TOUR_LAST_SEEN_DATE + "/" + E]: (/* @__PURE__ */ new Date()).toISOString() }));
						}
						var x = f({}, c.properties.$set, c.$set);
						if (q(x) || this.setPersonPropertiesForFlags(x), !K(this.config.before_send)) {
							var S = this.it(c);
							if (!S) return;
							(c = S).uuid = fe(c.uuid, Nr);
						}
						this.Ti.emit("eventCaptured", c);
						var T = {
							method: "POST",
							url: null !== (r = null == i ? void 0 : i._url) && void 0 !== r ? r : this.requestRouter.endpointFor("api", this.analyticsDefaultEndpoint),
							data: c,
							compression: "best-available",
							batchKey: null == i ? void 0 : i._batchKey,
							transport: null == i ? void 0 : i.transport
						};
						return !this.config.request_batching || i && (null == i || !i._batchKey) || null != i && i.send_instantly ? this.Di(T) : this.$i.enqueue(T), c;
					}
					li.critical("This capture call is ignored due to client rate limiting.");
				}
			} else li.error("No event name provided to posthog.capture");
		} else li.uninitializedWarning("posthog.capture");
	}
	_addCaptureHook(t) {
		return this.on("eventCaptured", ((e) => t(e.event, e)));
	}
	calculateEventProperties(e, i, n, o, a) {
		if (n = n || /* @__PURE__ */ new Date(), !this.persistence || !this.sessionPersistence) return i;
		var l = a ? void 0 : this.persistence.remove_event_timer(e), h = f({}, i);
		if (h.token = this.config.token, h.$config_defaults = this.config.defaults, this.Ci() && (h.$cookieless_mode = !0), "$snapshot" === e) {
			var d = f({}, this.persistence.properties(), this.sessionPersistence.properties());
			return h.distinct_id = d.distinct_id, (!G(h.distinct_id) && !J(h.distinct_id) || W(h.distinct_id)) && li.error("Invalid distinct_id for replay event. This indicates a bug in your implementation"), h;
		}
		var c, p = function(e, i, r, n) {
			var o, a, l, h;
			if (void 0 === n && (n = !1), !u) return {};
			var d, c, p, f, _, g, m, y, b, w = e ? [...en, ...i || []] : [], [E, x] = function(t) {
				for (var e = 0; ve.length > e; e++) {
					var [i, r] = ve[e], s = i.exec(t), n = s && (z(r) ? r(s, t) : r);
					if (n) return n;
				}
				return ["", ""];
			}(u), S = null != (d = "undefined" != typeof navigator ? navigator : void 0) && d.brave ? { brave: !0 } : {}, T = { detectGoogleSearchApp: r }, k = Sr(Rr({
				$os: E,
				$os_version: x,
				$browser: ue(u, navigator.vendor, S, T),
				$device: ce(u),
				$device_type: (p = u, f = {
					userAgentDataPlatform: null == (o = navigator) || null == (o = o.userAgentData) ? void 0 : o.platform,
					maxTouchPoints: null == (a = navigator) ? void 0 : a.maxTouchPoints,
					screenWidth: null == t || null == (l = t.screen) ? void 0 : l.width,
					screenHeight: null == t || null == (h = t.screen) ? void 0 : h.height,
					devicePixelRatio: null == t ? void 0 : t.devicePixelRatio
				}, b = ce(p), b === ft || b === pt || "Kobo" === b || "Kindle Fire" === b || b === Vt ? ct : b === Ft || b === Dt || b === Mt || b === zt ? "Console" : b === gt ? "Wearable" : b ? ht : "Android" === (null == f ? void 0 : f.userAgentDataPlatform) && (null !== (_ = null == f ? void 0 : f.maxTouchPoints) && void 0 !== _ ? _ : 0) > 0 ? 600 > Math.min(null !== (g = null == f ? void 0 : f.screenWidth) && void 0 !== g ? g : 0, null !== (m = null == f ? void 0 : f.screenHeight) && void 0 !== m ? m : 0) / (null !== (y = null == f ? void 0 : f.devicePixelRatio) && void 0 !== y ? y : 1) ? ht : ct : "Desktop"),
				$timezone: pn(),
				$timezone_offset: fn()
			}), {
				$current_url: Xs(n ? _e(null == s ? void 0 : s.href) : null == s ? void 0 : s.href, w, sn),
				$host: null == s ? void 0 : s.host,
				$pathname: null == s ? void 0 : s.pathname,
				$raw_user_agent: u.length > 1e3 ? u.substring(0, 997) + "..." : u,
				$browser_version: de(u, navigator.vendor, S, T),
				$browser_language: un(),
				$browser_language_prefix: (c = un(), "string" == typeof c ? c.split("-")[0] : void 0),
				$screen_height: null == t ? void 0 : t.screen.height,
				$screen_width: null == t ? void 0 : t.screen.width,
				$viewport_height: null == t ? void 0 : t.innerHeight,
				$viewport_width: null == t ? void 0 : t.innerWidth,
				$lib: v.LIB_NAME,
				$lib_version: v.LIB_VERSION,
				$insert_id: Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10),
				$time: Date.now() / 1e3
			});
			return v.SDK_DIST_CHANNEL && (k.$sdk_dist_channel = v.SDK_DIST_CHANNEL), k;
		}(this.config.mask_personal_data_properties, this.config.custom_personal_data_properties, this.config.detect_google_search_app, this.config.disable_capture_url_hashes);
		if (this.sessionManager) {
			var { sessionId: _, windowId: g } = this.sessionManager.checkAndGetSessionAndWindowId(a, n.getTime());
			h.$session_id = _, h.$window_id = g;
		}
		this.sessionPropsManager && Sr(h, this.sessionPropsManager.getSessionProps());
		try {
			var m;
			this.sessionRecording && Sr(h, this.sessionRecording.sdkDebugProperties), h.$sdk_debug_retry_queue_size = null == (m = this.Ni) ? void 0 : m.length;
		} catch (t) {
			h.$sdk_debug_error_capturing_properties = String(t);
		}
		if (this.requestRouter.region === Yo && (h.$lib_custom_api_host = this.config.api_host), c = e !== mr || a ? e !== yr || a ? this.pageViewManager.doEvent() : this.pageViewManager.doPageLeave(n) : this.pageViewManager.doPageView(n, o), h = Sr(h, c), e === mr && r && (h.title = r.title), !V(l)) {
			var y = n.getTime() - l;
			h.$duration = parseFloat((y / 1e3).toFixed(3));
		}
		u && this.config.opt_out_useragent_filter && (h.$browser_type = this._is_bot() ? "bot" : "browser"), (h = Sr({}, p, this.persistence.properties(), this.sessionPersistence.properties(), h)).$is_identified = this._isIdentified(), B(this.config.property_denylist) ? xr(this.config.property_denylist, (function(t) {
			delete h[t];
		})) : li.error(ca + this.config.property_denylist + " or property_blacklist config: " + this.config.property_blacklist);
		var b = this.config.sanitize_properties;
		b && (li.error(va), h = b(h, e));
		var w = this.Ji();
		return h.$process_person_profile = w, w && !a && this.Yi("_calculate_event_properties"), h;
	}
	Qi(t, e, i) {
		var r;
		if (void 0 === e && (e = !0), void 0 === i && (i = !1), !this.persistence || !this.Ji()) return t;
		if (this.Ii && !i) return t;
		var o = Sr({}, this.persistence.get_initial_props(), (null == (r = this.sessionPropsManager) ? void 0 : r.getSetOnceProps()) || {}, t || {}), a = this.config.sanitize_properties;
		return a && (li.error(va), o = a(o, "$set_once")), e && (this.Ii = !0), q(o) ? void 0 : o;
	}
	register(t, e) {
		var i;
		null == (i = this.persistence) || i.register(t, e);
	}
	register_once(t, e, i) {
		var r;
		null == (r = this.persistence) || r.register_once(t, e, i);
	}
	register_for_session(t) {
		var e;
		null == (e = this.sessionPersistence) || e.register(t);
	}
	unregister(t) {
		var e;
		null == (e = this.persistence) || e.unregister(t);
	}
	unregister_for_session(t) {
		var e;
		null == (e = this.sessionPersistence) || e.unregister(t);
	}
	Ki(t, e) {
		this.register({ [t]: e });
	}
	getFeatureFlag(t, e) {
		var i;
		return null == (i = this.featureFlags) ? void 0 : i.getFeatureFlag(t, e);
	}
	getFeatureFlagPayload(t) {
		var e;
		return null == (e = this.featureFlags) ? void 0 : e.getFeatureFlagPayload(t);
	}
	getFeatureFlagResult(t, e) {
		var i;
		return null == (i = this.featureFlags) ? void 0 : i.getFeatureFlagResult(t, e);
	}
	getAllFeatureFlags() {
		var t, e;
		return null !== (t = null == (e = this.featureFlags) ? void 0 : e.getAllFeatureFlags()) && void 0 !== t ? t : [];
	}
	isFeatureEnabled(t, e) {
		var i;
		return null == (i = this.featureFlags) ? void 0 : i.isFeatureEnabled(t, e);
	}
	reloadFeatureFlags() {
		var t;
		null == (t = this.featureFlags) || t.reloadFeatureFlags();
	}
	updateFlags(t, e, i) {
		var r;
		null == (r = this.featureFlags) || r.updateFlags(t, e, i);
	}
	updateEarlyAccessFeatureEnrollment(t, e, i) {
		var r;
		null == (r = this.featureFlags) || r.updateEarlyAccessFeatureEnrollment(t, e, i);
	}
	getEarlyAccessFeatures(t, e, i) {
		var r;
		return void 0 === e && (e = !1), null == (r = this.featureFlags) ? void 0 : r.getEarlyAccessFeatures(t, e, i);
	}
	on(t, e) {
		return this.Ti.on(t, e);
	}
	onFeatureFlags(t) {
		return this.featureFlags ? this.featureFlags.onFeatureFlags(t) : (t([], {}, { errorsLoading: !0 }), () => {});
	}
	onSurveysLoaded(t) {
		return this.surveys ? this.surveys.onSurveysLoaded(t) : (t([], {
			isLoaded: !1,
			error: da
		}), () => {});
	}
	onSessionId(t) {
		var e, i;
		return null !== (e = null == (i = this.sessionManager) ? void 0 : i.onSessionId(t)) && void 0 !== e ? e : () => {};
	}
	getSurveys(t, e) {
		void 0 === e && (e = !1), this.surveys ? this.surveys.getSurveys(t, e) : t([], {
			isLoaded: !1,
			error: da
		});
	}
	getActiveMatchingSurveys(t, e) {
		void 0 === e && (e = !1), this.surveys ? this.surveys.getActiveMatchingSurveys(t, e) : t([], {
			isLoaded: !1,
			error: da
		});
	}
	renderSurvey(t, e) {
		var i;
		null == (i = this.surveys) || i.renderSurvey(t, e);
	}
	displaySurvey(t, e) {
		var i;
		void 0 === e && (e = ia), null == (i = this.surveys) || i.displaySurvey(t, e);
	}
	cancelPendingSurvey(t) {
		var e;
		null == (e = this.surveys) || e.cancelPendingSurvey(t);
	}
	canRenderSurvey(t) {
		var e, i;
		return null !== (e = null == (i = this.surveys) ? void 0 : i.canRenderSurvey(t)) && void 0 !== e ? e : {
			visible: !1,
			disabledReason: da
		};
	}
	canRenderSurveyAsync(t, e) {
		var i, r;
		return void 0 === e && (e = !1), null !== (i = null == (r = this.surveys) ? void 0 : r.canRenderSurveyAsync(t, e)) && void 0 !== i ? i : Promise.resolve({
			visible: !1,
			disabledReason: da
		});
	}
	Xi(t) {
		return !t || W(t) ? (li.critical("Unique user id has not been set in posthog.identify"), !1) : t === or ? (li.critical("The string \"" + t + "\" was set in posthog.identify which indicates an error. This ID is only used as a sentinel value."), !1) : !["distinct_id", "distinctid"].includes(t.toLowerCase()) && !["undefined", "null"].includes(t.toLowerCase()) || (li.critical("The string \"" + t + "\" was set in posthog.identify which indicates an error. This ID should be unique to the user and not a hardcoded string."), !1);
	}
	identify(t, e, i) {
		if (!this.__loaded || !this.persistence) return li.uninitializedWarning("posthog.identify");
		if (J(t) && (t = t.toString(), li.warn("The first argument to posthog.identify was a number, but it should be a string. It has been converted to a string.")), this.Xi(t) && this.Yi("posthog.identify")) {
			var r = this.get_distinct_id();
			this.register({ $user_id: t }), this.get_property(ci) || this.register_once({
				$had_persisted_distinct_id: !0,
				$device_id: r
			}, ""), t !== r && t !== this.get_property(fi) && (this.unregister(fi), this.register({ distinct_id: t }));
			var s, n = (this.persistence.get_property(Xi) || cr) === cr;
			t !== r && n ? (this.persistence.set_property(Xi, pr), this.setPersonPropertiesForFlags({
				$set: e || {},
				$set_once: i || {}
			}, !1), this.capture(br, {
				distinct_id: t,
				$anon_distinct_id: r
			}, {
				$set: e || {},
				$set_once: i || {}
			}), this.Ri = qo(t, e, i), null == (s = this.featureFlags) || s.setAnonymousDistinctId(r)) : (e || i) && this.setPersonProperties(e, i), t !== r && (this.reloadFeatureFlags(), this.unregister(Yi));
		}
	}
	setPersonProperties(t, e) {
		if ((t || e) && this.Yi("posthog.setPersonProperties")) {
			var i = qo(this.get_distinct_id(), t, e);
			this.Ri !== i ? (this.setPersonPropertiesForFlags({
				$set: t || {},
				$set_once: e || {}
			}, !0), this.capture("$set", {
				$set: t || {},
				$set_once: e || {}
			}), this.Ri = i) : li.info("A duplicate setPersonProperties call was made with the same properties. It has been ignored.");
		}
	}
	unsetPersonProperties(t) {
		var e, i = (B(t) ? t : [t]).filter(((t) => G(t) && t.length > 0));
		0 !== i.length && this.Yi("posthog.unsetPersonProperties") && (null == (e = this.featureFlags) || e.unsetPersonPropertiesForFlags(i, !0), this.capture("$set", { $unset: i }), this.Ri = null);
	}
	group(t, e, i) {
		if (t && e) {
			var r = this.getGroups(), s = r[t] !== e;
			if (s && this.resetGroupPropertiesForFlags(t), this.register({ $groups: f({}, r, { [t]: e }) }), s || i) {
				var n = {
					$group_type: t,
					$group_key: e
				};
				i && (n.$group_set = i), this.capture(wr, n);
			}
			i && this.setGroupPropertiesForFlags({ [t]: i }), s && !i && this.reloadFeatureFlags();
		} else li.error("posthog.group requires a group type and group key");
	}
	resetGroups() {
		this.register({ $groups: {} }), this.resetGroupPropertiesForFlags(), this.reloadFeatureFlags();
	}
	setPersonPropertiesForFlags(t, e) {
		var i;
		void 0 === e && (e = !0), null == (i = this.featureFlags) || i.setPersonPropertiesForFlags(t, e);
	}
	resetPersonPropertiesForFlags(t) {
		var e;
		void 0 === t && (t = !0), null == (e = this.featureFlags) || e.resetPersonPropertiesForFlags(t);
	}
	setGroupPropertiesForFlags(t, e) {
		var i;
		void 0 === e && (e = !0), this.Yi("posthog.setGroupPropertiesForFlags") && (null == (i = this.featureFlags) || i.setGroupPropertiesForFlags(t, e));
	}
	resetGroupPropertiesForFlags(t) {
		var e;
		null == (e = this.featureFlags) || e.resetGroupPropertiesForFlags(t);
	}
	reset(t) {
		var e, i, r, s, n, o, a, l, u;
		if (li.info("reset"), !this.__loaded) return li.uninitializedWarning("posthog.reset");
		var h, d = this.get_property(ci), v = this.get_property(pi), c = this.get_property($i);
		if (this.consent.reset(), null == (e = this.persistence) || e.clear(), null == (i = this.sessionPersistence) || i.clear(), V(c) || null == (h = this.persistence) || h.register({ [$i]: c }), null == (r = this.surveys) || r.reset(), null == (s = this.Wi) || s.stop(), null == (n = this.featureFlags) || n.reset(), null == (o = this.conversations) || o.reset(), null == (a = this.logs) || a.reset(), null == (l = this.persistence) || l.set_property(Xi, cr), null == (u = this.sessionManager) || u.resetSessionId(), this.Ri = null, this.config.cookieless_mode === vr) this.register_once({
			distinct_id: or,
			$device_id: null
		}, "");
		else {
			var p = this.config.get_device_id(Nr());
			this.register_once({
				distinct_id: p,
				$device_id: t ? p : d
			}, ""), t || V(v) || this.register({ [pi]: v });
		}
		this.register({ $last_posthog_reset: (/* @__PURE__ */ new Date()).toISOString() }, 1), delete this.config.identity_distinct_id, delete this.config.identity_hash, this.reloadFeatureFlags();
	}
	shutdown(t) {
		var e = this;
		return p((function* () {
			var t, i, r;
			e.__loaded ? (null == (t = e.logs) || t.flushLogs("sendBeacon"), null == (i = e.$i) || i.unload(), null == (r = e.Ni) || r.unload()) : li.uninitializedWarning("posthog.shutdown");
		}))();
	}
	setIdentity(t, e) {
		var i;
		this.config.identity_distinct_id = t, this.config.identity_hash = e, this.alias(t), null == (i = this.conversations) || i.en();
	}
	clearIdentity() {
		var t;
		delete this.config.identity_distinct_id, delete this.config.identity_hash, null == (t = this.conversations) || t.tn();
	}
	get_distinct_id() {
		return this.get_property("distinct_id");
	}
	getGroups() {
		return this.get_property("$groups") || {};
	}
	get_session_id() {
		var t, e;
		return null !== (t = null == (e = this.sessionManager) ? void 0 : e.checkAndGetSessionAndWindowId(!0).sessionId) && void 0 !== t ? t : "";
	}
	get_session_replay_url(t) {
		if (!this.sessionManager) return "";
		var { sessionId: e, sessionStartTimestamp: i } = this.sessionManager.checkAndGetSessionAndWindowId(!0), r = this.requestRouter.endpointFor("ui", "/project/" + this.config.token + "/replay/" + e);
		if (null != t && t.withTimestamp && i) {
			var s, n = null !== (s = t.timestampLookBack) && void 0 !== s ? s : 10;
			if (!i) return r;
			r += "?t=" + Math.max(Math.floor(((/* @__PURE__ */ new Date()).getTime() - i) / 1e3) - n, 0);
		}
		return r;
	}
	alias(t, e) {
		return t === this.get_property(vi) ? (li.critical("Attempting to create alias for existing People user - aborting."), -2) : this.Yi("posthog.alias") ? (V(e) && (e = this.get_distinct_id()), t !== e ? (this.Ki(fi, t), this.capture("$create_alias", {
			alias: t,
			distinct_id: e
		})) : (li.warn("alias matches current distinct_id - skipping api call."), this.identify(t), -1)) : void 0;
	}
	set_config(t) {
		var e = f({}, this.config);
		if (H(t)) {
			var i, r, s, n, o, a, l, u, h, d, c;
			Sr(this.config, ma(t));
			var p = this.Ai();
			null == (i = this.persistence) || i.update_config(this.config, e, p), this.sessionPersistence = "sessionStorage" === this.config.persistence || "memory" === this.config.persistence ? this.persistence : new yn(f({}, this.config, { persistence: "sessionStorage" }), p, !1);
			var _ = this.Oi(this.config.debug);
			X(_) && (this.config.debug = _), X(this.config.debug) && (this.config.debug ? (v.DEBUG = !0, qr.N() && qr.q("ph_debug", !0), li.info("set_config", {
				config: t,
				oldConfig: e,
				newConfig: f({}, this.config)
			})) : (v.DEBUG = !1, qr.N() && qr.P("ph_debug"))), null == (r = this.exceptionObserver) || r.onConfigChange(), null == (s = this.exceptions) || s.onConfigChange(), null == (n = this.sessionRecording) || n.startIfEnabledOrStop(), null == (o = this.tracingHeaders) || o.startIfEnabledOrStop(), null == (a = this.autocapture) || a.startIfEnabled(), null == (l = this.heatmaps) || l.startIfEnabled(), null == (u = this.exceptionObserver) || u.startIfEnabledOrStop(), null == (h = this.deadClicksAutocapture) || h.startIfEnabledOrStop(), null == (d = this.surveys) || d.loadIfEnabled(), this.rn(), null == (c = this.externalIntegrations) || c.startIfEnabledOrStop();
		}
	}
	_overrideSDKInfo(t, e) {
		v.LIB_NAME = t, v.LIB_VERSION = e;
	}
	startSessionRecording(t) {
		var e, i, r, s, n, o = !0 === t, a = {
			sampling: o || !(null == t || !t.sampling),
			linked_flag: o || !(null == t || !t.linked_flag),
			url_trigger: o || !(null == t || !t.url_trigger),
			event_trigger: o || !(null == t || !t.event_trigger)
		};
		Object.values(a).some(Boolean) && (null == (e = this.sessionManager) || e.checkAndGetSessionAndWindowId(), a.sampling && (null == (i = this.sessionRecording) || i.overrideSampling()), a.linked_flag && (null == (r = this.sessionRecording) || r.overrideLinkedFlag()), a.url_trigger && (null == (s = this.sessionRecording) || s.overrideTrigger("url")), a.event_trigger && (null == (n = this.sessionRecording) || n.overrideTrigger("event")));
		this.set_config({ disable_session_recording: !1 });
	}
	stopSessionRecording() {
		this.set_config({ disable_session_recording: !0 });
	}
	sessionRecordingStarted() {
		var t;
		return !(null == (t = this.sessionRecording) || !t.started);
	}
	captureException(t, e) {
		if (this.exceptions) {
			var i = /* @__PURE__ */ new Error("PostHog syntheticException"), r = this.exceptions.buildProperties(t, {
				handled: !0,
				syntheticException: i
			});
			return this.exceptions.sendExceptionEvent(f({}, r, e));
		}
	}
	addExceptionStep(t, e) {
		var i;
		null == (i = this.exceptions) || i.addExceptionStep(t, e);
	}
	captureLog(t) {
		var e;
		null == (e = this.logs) || e.captureLog(t);
	}
	get logger() {
		var t, e;
		return null !== (t = null == (e = this.logs) ? void 0 : e.logger) && void 0 !== t ? t : ba.nn;
	}
	startExceptionAutocapture(t) {
		this.set_config({ capture_exceptions: null == t || t });
	}
	stopExceptionAutocapture() {
		this.set_config({ capture_exceptions: !1 });
	}
	loadToolbar(t) {
		var e, i;
		return null !== (e = null == (i = this.toolbar) ? void 0 : i.loadToolbar(t)) && void 0 !== e && e;
	}
	get_property(t) {
		var e;
		return null == (e = this.persistence) ? void 0 : e.props[t];
	}
	getSessionProperty(t) {
		var e;
		return null == (e = this.sessionPersistence) ? void 0 : e.props[t];
	}
	toString() {
		var t, e = null !== (t = this.config.name) && void 0 !== t ? t : pa;
		return e !== pa && (e = pa + "." + e), e;
	}
	_isIdentified() {
		var t, e;
		return (null == (t = this.persistence) ? void 0 : t.get_property(Xi)) === pr || (null == (e = this.sessionPersistence) ? void 0 : e.get_property(Xi)) === pr;
	}
	Ji() {
		var t, e;
		return !("never" === this.config.person_profiles || this.config.person_profiles === fr && !this._isIdentified() && q(this.getGroups()) && (null == (t = this.persistence) || null == (t = t.props) || !t[fi]) && (null == (e = this.persistence) || null == (e = e.props) || !e[sr]));
	}
	Gi() {
		return !0 === this.config.capture_pageleave || "if_capture_pageview" === this.config.capture_pageleave && (!0 === this.config.capture_pageview || "history_change" === this.config.capture_pageview);
	}
	createPersonProfile() {
		this.Ji() || this.Yi("posthog.createPersonProfile") && this.setPersonProperties({}, {});
	}
	setInternalOrTestUser() {
		this.Yi("posthog.setInternalOrTestUser") && this.setPersonProperties({ $internal_or_test_user: !0 });
	}
	Yi(t) {
		return "never" === this.config.person_profiles ? (li.error(t + " was called, but process_person is set to \"never\". This call will be ignored."), !1) : (this.Ki(sr, !0), !0);
	}
	Ai() {
		if ("always" === this.config.cookieless_mode) return !0;
		var t = this.consent.isOptedOut();
		return this.config.disable_persistence || t && !(!this.config.opt_out_persistence_by_default && this.config.cookieless_mode !== dr);
	}
	rn() {
		var t, e, i, r, s = this.Ai();
		return (null == (t = this.persistence) ? void 0 : t.Vt) !== s && (null == (i = this.persistence) || i.set_disabled(s)), (null == (e = this.sessionPersistence) ? void 0 : e.Vt) !== s && (null == (r = this.sessionPersistence) || r.set_disabled(s)), s;
	}
	opt_in_capturing(t) {
		var e;
		if (this.config.cookieless_mode !== vr) {
			if (this.Ci()) {
				var i, r, s, n, o;
				this.reset(!0), null == (i = this.sessionManager) || i.destroy(), null == (r = this.pageViewManager) || r.destroy(), this.sessionManager = new jo(this), this.pageViewManager = new Vs(this), this.persistence && (this.sessionPropsManager = new Lo(this, this.sessionManager, this.persistence));
				var a, l = null !== (s = null == (n = this.config.__extensionClasses) ? void 0 : n.sessionRecording) && void 0 !== s ? s : null == (o = ba.__defaultExtensionClasses) ? void 0 : o.sessionRecording;
				l && (this.sessionRecording = this.ki(this.sessionRecording, new l(this)), this.Ui && (null == (a = this.sessionRecording) || null == a.onRemoteConfig || a.onRemoteConfig(this.Ui)));
			}
			var u, h;
			this.consent.optInOut(!0), this.rn(), this.zi(), null == (e = this.sessionRecording) || e.startIfEnabledOrStop(), this.config.cookieless_mode == dr && (null == (u = this.surveys) || u.loadIfEnabled()), (V(null == t ? void 0 : t.captureEventName) || null != t && t.captureEventName) && this.capture(null !== (h = null == t ? void 0 : t.captureEventName) && void 0 !== h ? h : "$opt_in", null == t ? void 0 : t.captureProperties, { send_instantly: !0 }), this.config.capture_pageview && this.Vi();
		} else li.warn(ha);
	}
	opt_out_capturing() {
		var t, e, i;
		this.config.cookieless_mode !== vr ? (this.config.cookieless_mode === dr && this.consent.isOptedIn() && this.reset(!0), this.consent.optInOut(!1), this.rn(), this.config.cookieless_mode === dr && (this.register({
			distinct_id: or,
			$device_id: null
		}), null == (t = this.sessionRecording) || t.stopRecording(), this.sessionRecording = void 0, null == (e = this.sessionManager) || e.destroy(), null == (i = this.pageViewManager) || i.destroy(), this.sessionManager = void 0, this.sessionPropsManager = void 0, this.config.capture_pageview && this.Vi(), this.zi())) : li.warn(ha);
	}
	has_opted_in_capturing() {
		return this.consent.isOptedIn();
	}
	has_opted_out_capturing() {
		return this.consent.isOptedOut();
	}
	get_explicit_consent_status() {
		var t = this.consent.consent;
		return 1 === t ? "granted" : 0 === t ? "denied" : "pending";
	}
	is_capturing() {
		return this.config.cookieless_mode === vr || (this.config.cookieless_mode === dr ? this.consent.isRejected() || this.consent.isOptedIn() : !this.has_opted_out_capturing());
	}
	clear_opt_in_out_capturing() {
		this.consent.reset(), this.rn();
	}
	_is_bot() {
		return i ? Bo(i, this.config.custom_blocked_useragents) : void 0;
	}
	Vi() {
		r && ("visible" === r.visibilityState ? this.Ei || (this.Ei = !0, this.capture(mr, { title: r.title }, { send_instantly: !0 }), this.Mi && (r.removeEventListener(_r, this.Mi), this.Mi = null)) : this.Mi || (this.Mi = this.Vi.bind(this), Or(r, _r, this.Mi)));
	}
	debug(e) {
		!1 === e ? (t?.console.log("You've disabled debug mode."), this.set_config({ debug: !1 })) : (t?.console.log("You're now in debug mode. All calls to PostHog will be logged in your console.\nYou can disable this with `posthog.debug(false)`."), this.set_config({ debug: !0 }));
	}
	mr() {
		var t, e, i, r, s, n, o = this.Li || {};
		return "advanced_disable_flags" in o ? !!o.advanced_disable_flags : !1 !== this.config.advanced_disable_flags ? !!this.config.advanced_disable_flags : !0 === this.config.advanced_disable_decide ? (li.warn("Config field 'advanced_disable_decide' is deprecated. Please use 'advanced_disable_flags' instead. The old field will be removed in a future major version."), !0) : (i = "advanced_disable_decide", r = li, s = (e = "advanced_disable_flags") in (t = o) && !K(t[e]), n = i in t && !K(t[i]), s ? t[e] : !!n && (r && r.warn("Config field '" + i + "' is deprecated. Please use '" + e + "' instead. The old field will be removed in a future major version."), t[i]));
	}
	it(t) {
		var e;
		if (K(this.config.before_send)) return t;
		var i = Object.keys(null !== (e = t.properties) && void 0 !== e ? e : {}).filter(et), r = B(this.config.before_send) ? this.config.before_send : [this.config.before_send], s = t;
		for (var n of r) {
			if (s = n(s), K(s)) {
				var o = "Event '" + t.event + "' was rejected in beforeSend function";
				return tt(t.event) ? li.warn(o + ". This can cause unexpected behavior.") : li.info(o), null;
			}
			s.properties && !q(s.properties) || li.warn("Event '" + t.event + "' has no properties after beforeSend function, this is likely an error.");
		}
		for (var a of i) if (s.properties && K(s.properties[a])) return li.warn("Event '" + t.event + "' had its '" + a + "' property removed in a beforeSend function. This property is required for ingestion, so the event will be dropped."), null;
		return s;
	}
	getPageViewId() {
		var t;
		return null == (t = this.pageViewManager.Ot) ? void 0 : t.pageViewId;
	}
	captureTraceFeedback(t, e) {
		this.capture("$ai_feedback", {
			$ai_trace_id: String(t),
			$ai_feedback_text: e
		});
	}
	captureTraceMetric(t, e, i) {
		this.capture("$ai_metric", {
			$ai_trace_id: String(t),
			$ai_metric_name: e,
			$ai_metric_value: String(i)
		});
	}
	Oi(t) {
		var e = X(t) && !t, i = qr.N() && "true" === qr.A("ph_debug");
		return !e && (!!i || t);
	}
};
ba.__defaultExtensionClasses = {}, ba.nn = {
	trace: oa = () => {},
	debug: oa,
	info: oa,
	warn: oa,
	error: oa,
	fatal: oa
}, function(t, e) {
	for (var i = 0; e.length > i; i++) t.prototype[e[i]] = kr(t.prototype[e[i]]);
}(ba, ["identify"]);
var wa = class {
	constructor(t) {
		this.disabled = !1 === t;
		var e = H(t) ? t : {};
		this.thresholdPx = e.threshold_px || 30, this.timeoutMs = e.timeout_ms || 1e3, this.clickCount = e.click_count || 3, this.clicks = [];
	}
	isRageClick(t, e, i) {
		if (this.disabled) return !1;
		var r = this.clicks[this.clicks.length - 1];
		if (r && Math.abs(t - r.x) + Math.abs(e - r.y) < this.thresholdPx && this.timeoutMs > i - r.timestamp) {
			if (this.clicks.push({
				x: t,
				y: e,
				timestamp: i
			}), this.clicks.length === this.clickCount) return !0;
		} else this.clicks = [{
			x: t,
			y: e,
			timestamp: i
		}];
		return !1;
	}
};
var Ea = "$copy_autocapture", xa = ui("[AutoCapture]");
function Sa(t, e) {
	return e.length > t ? e.slice(0, t) + "..." : e;
}
function Ta(t) {
	if (t.previousElementSibling) return t.previousElementSibling;
	var e = t;
	do
		e = e.previousSibling;
	while (e && !is(e));
	return e;
}
function $a(e, i) {
	var r, s, { e: n, maskAllElementAttributes: o, maskAllText: a, elementAttributeIgnoreList: l, elementsChainAsString: u, disableCaptureUrlHashes: h } = i;
	if (!is(e)) return { props: {} };
	for (var d = [e], v = e; v.parentNode && !rs(v, "body");) if (ns(v.parentNode)) d.push(v.parentNode.host), v = v.parentNode.host;
	else {
		if (!is(v.parentNode)) break;
		d.push(v.parentNode), v = v.parentNode;
	}
	var c, p, _ = [], g = {}, m = !1, y = !1;
	if (xr(d, ((t) => {
		var e = Ss(t);
		if (rs(t, "a")) {
			var i = t.getAttribute("href");
			m = !!(e && i && Cs(i)) && (h ? _e(i) : i);
		}
		M(ls(t), "ph-no-capture") && (y = !0), _.push(function(t, e, i, r, s) {
			void 0 === s && (s = !1);
			var n = t.tagName.toLowerCase(), o = { tag_name: n };
			vs.indexOf(n) > -1 && !i && (o.$el_text = "a" === n.toLowerCase() || "button" === n.toLowerCase() ? Sa(1024, As(t)) : Sa(1024, hs(t)));
			var a = ls(t);
			a.length > 0 && (o.classes = a.filter((function(t) {
				return "" !== t;
			}))), xr(t.attributes, (function(i) {
				var n;
				if ((!Ts(t) || -1 !== [
					"name",
					"id",
					"class",
					"aria-label"
				].indexOf(i.name)) && (null == r || !r.includes(i.name)) && !e && Cs(i.value) && (!G(n = i.name) || "_ngcontent" !== n.substring(0, 10) && "_nghost" !== n.substring(0, 7))) {
					var a = i.value;
					"class" === i.name && (a = os(a).join(" ")), o["attr__" + i.name] = Sa(1024, "href" === i.name && s ? _e(a) : a);
				}
			}));
			for (var l = 1, u = 1, h = t; h = Ta(h);) l++, h.tagName === t.tagName && u++;
			return o.nth_child = l, o.nth_of_type = u, o;
		}(t, o, a, l, h));
		Sr(g, function(t) {
			if (!Ss(t)) return {};
			var e = {};
			return xr(t.attributes, (function(t) {
				if (t.name && 0 === t.name.indexOf("data-ph-capture-attribute")) {
					var i = t.name.replace("data-ph-capture-attribute-", ""), r = t.value;
					i && r && Cs(r) && (e[i] = r);
				}
			})), e;
		}(t));
	})), y) return {
		props: {},
		explicitNoCapture: y
	};
	if (a || (_[0].$el_text = rs(e, "a") || rs(e, "button") ? As(e) : hs(e)), m) {
		var b, w;
		_[0].attr__href = m;
		var E = null == (b = Js(m)) ? void 0 : b.host, x = null == t || null == (w = t.location) ? void 0 : w.host;
		E && x && E !== x && (c = m);
	}
	return { props: Sr({
		$event_type: n.type,
		$ce_version: 1
	}, u ? {} : { $elements: _ }, { $elements_chain: (p = _, function(t) {
		return t.map(((t) => {
			var e, i, r = "";
			if (t.tag_name && (r += t.tag_name), t.attr_class) for (var s of (t.attr_class.sort(), t.attr_class)) r += "." + s.replace(/"/g, "");
			var n = f({}, t.text ? { text: t.text } : {}, {
				"nth-child": null !== (e = t.nth_child) && void 0 !== e ? e : 0,
				"nth-of-type": null !== (i = t.nth_of_type) && void 0 !== i ? i : 0
			}, t.href ? { href: t.href } : {}, t.attr_id ? { attr_id: t.attr_id } : {}, t.attributes), o = {};
			return Tr(n).sort(((t, e) => {
				var [i] = t, [r] = e;
				return i.localeCompare(r);
			})).forEach(((t) => {
				var [e, i] = t;
				return o[Ms(e.toString())] = Ms(i.toString());
			})), (r += ":") + Tr(o).map(((t) => {
				var [e, i] = t;
				return e + "=\"" + i + "\"";
			})).join("");
		})).join(";");
	}(function(t) {
		return t.map(((t) => {
			var e, i, r = {
				text: null == (e = t.$el_text) ? void 0 : e.slice(0, 400),
				tag_name: t.tag_name,
				href: null == (i = t.attr__href) ? void 0 : i.slice(0, 2048),
				attr_class: Ds(t),
				attr_id: t.attr__id,
				nth_child: t.nth_child,
				nth_of_type: t.nth_of_type,
				attributes: {}
			};
			return Tr(t).filter(((t) => {
				var [e] = t;
				return 0 === e.indexOf("attr__");
			})).forEach(((t) => {
				var [e, i] = t;
				return r.attributes[e] = i;
			})), r;
		}));
	}(p))) }, null != (r = _[0]) && r.$el_text ? { $el_text: null == (s = _[0]) ? void 0 : s.$el_text } : {}, c && "click" === n.type ? { $external_click_url: c } : {}, g) };
}
var ka = ui("[ExceptionAutocapture]"), Ra = ui("[TracingHeaders]"), Pa = ui("[Web Vitals]"), Ia = 9e5, Oa = "disabled", Ca = "lazy_loading", Aa = "awaiting_config", Fa = "missing_config";
ui("[SessionRecording]"), ui("[SessionRecording]");
var Ma = "[SessionRecording]", Da = ui(Ma), La = ui("[Heatmaps]");
function Na(t) {
	return H(t) && "clientX" in t && "clientY" in t && J(t.clientX) && J(t.clientY);
}
var Ua = ui("[Product Tours]"), ja = (t) => {
	var e;
	return !t.config.disable_product_tours && !(null == (e = t.persistence) || !e.get_property(Si));
}, Ba = ["$set_once", "$set"], za = ui("[SiteApps]"), Ha = "Error while initializing PostHog app with config id ";
function qa(t, e, i) {
	if (K(t)) return !1;
	switch (i) {
		case "exact": return t === e;
		case "contains":
			var r = e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/_/g, ".").replace(/%/g, ".*");
			return new RegExp(r, "i").test(t);
		case "regex": try {
			return new RegExp(e).test(t);
		} catch (t) {
			return !1;
		}
		default: return !1;
	}
}
var Va = class {
	constructor(t) {
		this.sn = new No(), this.an = (t, e) => this.ln(t, e) && this.un(t, e) && this.hn(t, e) && this.dn(t, e), this.ln = (t, e) => null == e || !e.event || (null == t ? void 0 : t.event) === (null == e ? void 0 : e.event), this._instance = t, this.cn = /* @__PURE__ */ new Set(), this.vn = /* @__PURE__ */ new Set();
	}
	init() {
		var t, e;
		V(null == (t = this._instance) ? void 0 : t._addCaptureHook) || null == (e = this._instance) || e._addCaptureHook(((t, e) => {
			this.on(t, e);
		}));
	}
	register(t) {
		var e, i;
		if (!V(null == (e = this._instance) ? void 0 : e._addCaptureHook) && (t.forEach(((t) => {
			var e, i;
			null == (e = this.vn) || e.add(t), null == (i = t.steps) || i.forEach(((t) => {
				var e;
				null == (e = this.cn) || e.add((null == t ? void 0 : t.event) || "");
			}));
		})), null != (i = this._instance) && i.autocapture)) {
			var r, s = /* @__PURE__ */ new Set();
			t.forEach(((t) => {
				var e;
				null == (e = t.steps) || e.forEach(((t) => {
					null != t && t.selector && s.add(null == t ? void 0 : t.selector);
				}));
			})), null == (r = this._instance) || r.autocapture.setElementSelectors(s);
		}
	}
	on(t, e) {
		var i;
		null != e && 0 != t.length && (this.cn.has(t) || this.cn.has(null == e ? void 0 : e.event)) && this.vn && (null == (i = this.vn) ? void 0 : i.size) > 0 && this.vn.forEach(((t) => {
			this.fn(e, t) && this.sn.emit("actionCaptured", t.name);
		}));
	}
	pn(t) {
		this.onAction("actionCaptured", ((e) => t(e)));
	}
	fn(t, e) {
		if (null == (null == e ? void 0 : e.steps)) return !1;
		for (var i of e.steps) if (this.an(t, i)) return !0;
		return !1;
	}
	onAction(t, e) {
		return this.sn.on(t, e);
	}
	un(t, e) {
		if (null != e && e.url) {
			var i, r = null == t || null == (i = t.properties) ? void 0 : i.$current_url;
			if (!r || "string" != typeof r) return !1;
			if (!qa(r, e.url, e.url_matching || "contains")) return !1;
		}
		return !0;
	}
	hn(t, e) {
		return !!this.gn(t, e) && !!this.mn(t, e) && !!this.yn(t, e);
	}
	gn(t, e) {
		var i;
		if (null == e || !e.href) return !0;
		var r = this.bn(t);
		if (r.length > 0) return r.some(((t) => qa(t.href, e.href, e.href_matching || "exact")));
		var s, n = (null == t || null == (i = t.properties) ? void 0 : i.$elements_chain) || "";
		return !!n && qa((s = n.match(/(?::|")href="(.*?)"/)) ? s[1] : "", e.href, e.href_matching || "exact");
	}
	mn(t, e) {
		var i;
		if (null == e || !e.text) return !0;
		var r = this.bn(t);
		if (r.length > 0) return r.some(((t) => qa(t.text, e.text, e.text_matching || "exact") || qa(t.$el_text, e.text, e.text_matching || "exact")));
		var s, n, o, a = (null == t || null == (i = t.properties) ? void 0 : i.$elements_chain) || "";
		return !!a && (s = function(t) {
			for (var e, i = [], r = /(?::|")text="(.*?)"/g; !K(e = r.exec(t));) i.includes(e[1]) || i.push(e[1]);
			return i;
		}(a), n = e.text, o = e.text_matching || "exact", s.some(((t) => qa(t, n, o))));
	}
	yn(t, e) {
		var i, r;
		if (null == e || !e.selector) return !0;
		var s = null == t || null == (i = t.properties) ? void 0 : i.$element_selectors;
		if (null != s && s.includes(e.selector)) return !0;
		var n = (null == t || null == (r = t.properties) ? void 0 : r.$elements_chain) || "";
		if (e.selector_regex && n) try {
			return new RegExp(e.selector_regex).test(n);
		} catch (t) {
			return !1;
		}
		return !1;
	}
	bn(t) {
		var e;
		return null == (null == t || null == (e = t.properties) ? void 0 : e.$elements) ? [] : null == t ? void 0 : t.properties.$elements;
	}
	dn(t, e) {
		return null == e || !e.properties || 0 === e.properties.length || Wo(e.properties.reduce(((t, e) => {
			var i = B(e.value) ? e.value.map(String) : null != e.value ? [String(e.value)] : [];
			return t[e.key] = {
				values: i,
				operator: e.operator || "exact"
			}, t;
		}), {}), null == t ? void 0 : t.properties);
	}
};
var Ga = class {
	constructor(t) {
		this._n = [], this._instance = t, this.wn = /* @__PURE__ */ new Map(), this.xn = /* @__PURE__ */ new Map(), this.kn = /* @__PURE__ */ new Map();
	}
	Sn(t, e) {
		return !!t && Wo(t.propertyFilters, null == e ? void 0 : e.properties);
	}
	Cn(t, e) {
		var i = /* @__PURE__ */ new Map();
		return t.forEach(((t) => {
			var r;
			null == (r = t.conditions) || null == (r = r[e]) || null == (r = r.values) || r.forEach(((e) => {
				if (null != e && e.name) {
					var r = i.get(e.name) || [];
					r.push(t.id), i.set(e.name, r);
				}
			}));
		})), i;
	}
	In(t, e, i) {
		var r = (i === bn.Activation ? this.wn : this.xn).get(t), s = [];
		return this.Tn(((t) => {
			s = t.filter(((t) => null == r ? void 0 : r.includes(t.id)));
		})), s.filter(((r) => {
			var s, n = null == (s = r.conditions) || null == (s = s[i]) || null == (s = s.values) ? void 0 : s.find(((e) => e.name === t));
			return this.Sn(n, e);
		}));
	}
	register(t) {
		var e;
		V(null == (e = this._instance) ? void 0 : e._addCaptureHook) || (this.En(t), this.Mn(t));
	}
	Mn(t) {
		var e = t.filter(((t) => {
			var e, i;
			return (null == (e = t.conditions) ? void 0 : e.actions) && (null == (i = t.conditions) || null == (i = i.actions) || null == (i = i.values) ? void 0 : i.length) > 0;
		}));
		0 !== e.length && (this.Pn ?? (this.Pn = new Va(this._instance), this.Pn.init(), this.Pn.pn(((t) => {
			this.onAction(t);
		}))), e.forEach(((t) => {
			var e, i, r, s, n;
			t.conditions && null != (e = t.conditions) && e.actions && null != (i = t.conditions) && null != (i = i.actions) && i.values && (null == (r = t.conditions) || null == (r = r.actions) || null == (r = r.values) ? void 0 : r.length) > 0 && (null == (s = this.Pn) || s.register(t.conditions.actions.values), null == (n = t.conditions) || null == (n = n.actions) || null == (n = n.values) || n.forEach(((e) => {
				if (e && e.name) {
					var i = this.kn.get(e.name);
					i && i.push(t.id), this.kn.set(e.name, i || [t.id]);
				}
			})));
		})));
	}
	En(t) {
		var e, i = t.filter(((t) => {
			var e, i;
			return (null == (e = t.conditions) ? void 0 : e.events) && (null == (i = t.conditions) || null == (i = i.events) || null == (i = i.values) ? void 0 : i.length) > 0;
		})), r = t.filter(((t) => {
			var e, i;
			return (null == (e = t.conditions) ? void 0 : e.cancelEvents) && (null == (i = t.conditions) || null == (i = i.cancelEvents) || null == (i = i.values) ? void 0 : i.length) > 0;
		}));
		0 === i.length && 0 === r.length || (null == (e = this._instance) || e._addCaptureHook(((t, e) => {
			this.onEvent(t, e);
		})), this.wn = this.Cn(t, bn.Activation), this.xn = this.Cn(t, bn.Cancellation));
	}
	onEvent(t, e) {
		var i, r, s = this.Rn(), n = (null == e || null == (i = e.properties) ? void 0 : i.$survey_id) || (null == e || null == (r = e.properties) ? void 0 : r.$product_tour_id);
		if (n && this.getActivatedIds().includes(n)) {
			var o = this.On(t, n);
			if ("consume" === o) return s.info("event consumed activated item, removing it", {
				event: t,
				itemId: n
			}), void this.Ln([n]);
			if ("persist" === o) return s.info("shown item promoted to persisted activation", {
				event: t,
				itemId: n
			}), void this.Fn(n);
		}
		if (this.xn.has(t)) {
			var a = this.In(t, e, bn.Cancellation);
			a.length > 0 && (s.info("cancel event matched, cancelling items", {
				event: t,
				itemsToCancel: a.map(((t) => t.id))
			}), this.Ln(a.map(((t) => t.id))), a.forEach(((t) => this.An(t.id))));
		}
		if (this.wn.has(t)) {
			s.info("event name matched", {
				event: t,
				eventPayload: e,
				items: this.wn.get(t)
			});
			var l = this.In(t, e, bn.Activation);
			this.$n(l.map(((t) => t.id)));
		}
	}
	onAction(t) {
		this.kn.has(t) && this.$n(this.kn.get(t) || []);
	}
	$n(t) {
		0 !== t.length && (this._n = [.../* @__PURE__ */ new Set([...this._n, ...t])], this.Rn().info("updating activated items", { activatedItems: this.getActivatedIds() }));
	}
	Fn(t) {
		this._n = this._n.filter(((e) => e !== t));
		var e = this.Dn();
		e.includes(t) || this.Nn([...e, t]);
	}
	Ln(t) {
		var e = new Set(t);
		this._n = this._n.filter(((t) => !e.has(t)));
		var i = this.Dn(), r = i.filter(((t) => !e.has(t)));
		r.length !== i.length && this.Nn(r);
	}
	Dn() {
		var t, e = this.qn();
		return (null == (t = this._instance) || null == (t = t.persistence) ? void 0 : t.props[e]) || [];
	}
	getActivatedIds() {
		return [.../* @__PURE__ */ new Set([...this.Dn(), ...this._n])].filter(((t) => !this.Bn(t)));
	}
	reset() {
		this._n = [], this.Dn().length > 0 && this.Nn([]);
	}
	getEventToItemsMap() {
		return this.wn;
	}
	jn() {
		return this.Pn;
	}
};
var Wa = class extends Ga {
	constructor(t) {
		super(t);
	}
	qn() {
		return Gi;
	}
	Hn() {
		return Rn.SHOWN;
	}
	Tn(t) {
		var e;
		null == (e = this._instance) || e.getSurveys(t);
	}
	An(t) {
		var e;
		null == (e = this._instance) || e.cancelPendingSurvey(t);
	}
	Rn() {
		return Xo;
	}
	Nn(t) {
		var e;
		null == (e = this._instance) || null == (e = e.persistence) || e.register({ [Gi]: t });
	}
	Bn() {
		return !1;
	}
	On(t, e) {
		var i;
		this.Tn(((t) => {
			i = t.find(((t) => t.id === e));
		}));
		return !i || function(t) {
			var e, i, r, s = (null !== (e = null == (i = t.conditions) || null == (i = i.events) || null == (i = i.values) ? void 0 : i.length) && void 0 !== e ? e : 0) > 0;
			return t.schedule === kn.Always || !(null == (r = t.conditions) || null == (r = r.events) || !r.repeatedActivation || !s);
		}(i) ? t === Rn.SHOWN ? "consume" : "ignore" : t === Rn.SHOWN ? "persist" : t === Rn.DISMISSED || t === Rn.SENT ? "consume" : "ignore";
	}
	getSurveys() {
		return this.getActivatedIds();
	}
	getEventToSurveys() {
		return this.getEventToItemsMap();
	}
};
var Ya = "SDK is not enabled or survey functionality is not yet loaded", Ka = "Disabled. Not loading surveys.", Ja = null != t && t.location ? Zs(t.location.hash, "__posthog") || Zs(location.hash, "state") : null, Qa = "_postHogToolbarParams", Xa = ui("[Toolbar]"), Za = ui("[FeatureFlags]"), tl = ui("[FeatureFlags]", { debugEnabled: !0 }), el = "\" failed. Feature flags didn't load in time.", il = (t) => {
	for (var e = {}, i = 0; t.length > i; i++) e[t[i]] = !0;
	return e;
}, rl = (t) => {
	var e = {};
	for (var [i, r] of Tr(t || {})) r && (e[i] = r);
	return e;
}, sl = ui("[Error tracking]"), nl = "Refusing to render web experiment since the viewer is a likely bot", ol = {
	icontains: (t, e) => e.toLowerCase().indexOf(t.toLowerCase()) > -1,
	not_icontains: (t, e) => -1 === e.toLowerCase().indexOf(t.toLowerCase()),
	regex: (t, e) => Ho(e, t),
	not_regex: (t, e) => !Ho(e, t),
	exact: (t, e) => e === t,
	is_not: (t, e) => e !== t
};
var al = class al {
	get Se() {
		return this._instance.config;
	}
	constructor(t) {
		var e = this;
		this.getWebExperimentsAndEvaluateDisplayLogic = function(t) {
			void 0 === t && (t = !1), e.getWebExperiments(((t) => {
				al.Un("retrieved web experiments from the server"), e.zn = /* @__PURE__ */ new Map(), t.forEach(((t) => {
					if (t.feature_flag_key) {
						var i;
						e.zn && (al.Un("setting flag key ", t.feature_flag_key, " to web experiment ", t), null == (i = e.zn) || i.set(t.feature_flag_key, t));
						var r = e._instance.getFeatureFlag(t.feature_flag_key);
						G(r) && t.variants[r] && e.Vn(t.name, r, t.variants[r].transforms);
					} else if (t.variants) for (var s in t.variants) {
						var n = t.variants[s];
						al.Wn(n, e._instance) && e.Vn(t.name, s, n.transforms);
					}
				}));
			}), t);
		}, this._instance = t, this._instance.onFeatureFlags(((t) => {
			this.onFeatureFlags(t);
		}));
	}
	initialize() {}
	onFeatureFlags(t) {
		if (this._is_bot()) al.Un(nl);
		else if (!this.Se.disable_web_experiments) {
			if (K(this.zn)) return this.zn = /* @__PURE__ */ new Map(), this.loadIfEnabled(), void this.previewWebExperiment();
			al.Un("applying feature flags", t), t.forEach(((t) => {
				var e;
				if (this.zn && null != (e = this.zn) && e.has(t)) {
					var i, r = this._instance.getFeatureFlag(t), s = null == (i = this.zn) ? void 0 : i.get(t);
					r && null != s && s.variants[r] && this.Vn(s.name, r, s.variants[r].transforms);
				}
			}));
		}
	}
	previewWebExperiment() {
		var t = al.getWindowLocation();
		if (null != t && t.search) {
			var e = Qs(null == t ? void 0 : t.search, "__experiment_id"), i = Qs(null == t ? void 0 : t.search, "__experiment_variant");
			e && i && (al.Un("previewing web experiments " + e + " && " + i), this.getWebExperiments(((t) => {
				this.Gn(parseInt(e), i, t);
			}), !1, !0));
		}
	}
	loadIfEnabled() {
		this.Se.disable_web_experiments || this.getWebExperimentsAndEvaluateDisplayLogic();
	}
	getWebExperiments(t, e, i) {
		if (this.Se.disable_web_experiments && !i) return t([]);
		var r = this._instance.get_property("$web_experiments");
		if (r && !e) return t(r);
		this._instance._send_request({
			url: this._instance.requestRouter.endpointFor("api", "/api/web_experiments/?token=" + this.Se.token),
			method: "GET",
			callback: (e) => t(200 === e.statusCode && e.json && e.json.experiments || [])
		});
	}
	Gn(t, e, i) {
		var r = i.filter(((e) => e.id === t));
		r && r.length > 0 && (al.Un("Previewing web experiment [" + r[0].name + "] with variant [" + e + "]"), this.Vn(r[0].name, e, r[0].variants[e].transforms));
	}
	static Wn(t, e) {
		return !K(t.conditions) && al.Zn(t, e) && al.Qn(t);
	}
	static Zn(t, e) {
		var i;
		if (K(t.conditions) || K(null == (i = t.conditions) ? void 0 : i.url)) return !0;
		var r = al.getWindowLocation();
		if (r) {
			var s, n, o, a = Qr(e, r.href);
			return null == (s = t.conditions) || !s.url || ol[null !== (n = null == (o = t.conditions) ? void 0 : o.urlMatchType) && void 0 !== n ? n : "icontains"](t.conditions.url, a);
		}
		return !1;
	}
	static getWindowLocation() {
		return null == t ? void 0 : t.location;
	}
	static Qn(t) {
		var e;
		if (K(t.conditions) || K(null == (e = t.conditions) ? void 0 : e.utm)) return !0;
		var i = on();
		if (i.utm_source) {
			var r, s, n, o, a, l, u, h, d = null == (r = t.conditions) || null == (r = r.utm) || !r.utm_campaign || (null == (s = t.conditions) || null == (s = s.utm) ? void 0 : s.utm_campaign) == i.utm_campaign, v = null == (n = t.conditions) || null == (n = n.utm) || !n.utm_source || (null == (o = t.conditions) || null == (o = o.utm) ? void 0 : o.utm_source) == i.utm_source, c = null == (a = t.conditions) || null == (a = a.utm) || !a.utm_medium || (null == (l = t.conditions) || null == (l = l.utm) ? void 0 : l.utm_medium) == i.utm_medium, p = null == (u = t.conditions) || null == (u = u.utm) || !u.utm_term || (null == (h = t.conditions) || null == (h = h.utm) ? void 0 : h.utm_term) == i.utm_term;
			return d && c && p && v;
		}
		return !1;
	}
	static Un(t) {
		for (var e = arguments.length, i = new Array(e > 1 ? e - 1 : 0), r = 1; e > r; r++) i[r - 1] = arguments[r];
		li.info("[WebExperiments] " + t, i);
	}
	Vn(t, e, i) {
		this._is_bot() ? al.Un(nl) : "control" !== e ? i.forEach(((i) => {
			if (i.selector) {
				var r;
				al.Un("applying transform of variant " + e + " for experiment " + t + " ", i);
				(null == (r = document) ? void 0 : r.querySelectorAll(i.selector))?.forEach(((t) => {
					var e = t;
					i.html && (e.innerHTML = i.html), i.css && e.setAttribute("style", i.css);
				}));
			}
		})) : al.Un("Control variants leave the page unmodified.");
	}
	_is_bot() {
		return i && this._instance ? Bo(i, this.Se.custom_blocked_useragents) : void 0;
	}
};
var ll = ui("[Conversations]"), ul = "Conversations not available yet.", hl = "console", dl = { featureFlags: class {
	constructor(t) {
		this.Jn = !1, this.Yn = !1, this.Kn = !1, this.Xn = !1, this.es = !1, this.ts = !1, this.rs = !1, this.ns = !1, this._instance = t, this.featureFlagEventHandlers = [];
	}
	get Se() {
		return this._instance.config;
	}
	get zr() {
		return this._instance.persistence;
	}
	ss(t) {
		return this._instance.get_property(t);
	}
	os() {
		var t, e;
		return null !== (t = null == (e = this.zr) ? void 0 : e.Gt(this.Se.feature_flag_cache_ttl_ms)) && void 0 !== t && t;
	}
	ls() {
		return !!this.os() && (this.ns || this.Kn || (this.ns = !0, Za.warn("Feature flag cache is stale, triggering refresh..."), this.reloadFeatureFlags()), !0);
	}
	us() {
		var t, e = null !== (t = this.Se.evaluation_contexts) && void 0 !== t ? t : this.Se.evaluation_environments;
		return !this.Se.evaluation_environments || this.Se.evaluation_contexts || this.rs || (Za.warn("evaluation_environments is deprecated. Use evaluation_contexts instead. evaluation_environments will be removed in a future version."), this.rs = !0), null != e && e.length ? e.filter(((t) => {
			var e = t && "string" == typeof t && t.trim().length > 0;
			return e || Za.error("Invalid evaluation context found:", t, "Expected non-empty string"), e;
		})) : [];
	}
	hs() {
		return this.us().length > 0;
	}
	ds() {
		var t = this.Se.flag_keys;
		if (!V(t)) {
			if (B(t)) return t.filter(((t) => {
				var e = t && "string" == typeof t && t.trim().length > 0;
				return e || Za.error("Invalid flag key found:", t, "Expected non-empty string"), e;
			}));
			Za.error("Invalid flag_keys found:", t, "Expected array of non-empty strings");
		}
	}
	initialize() {
		var t, e, { config: i } = this._instance, r = null !== (t = null == (e = i.bootstrap) ? void 0 : e.featureFlags) && void 0 !== t ? t : {};
		if (Object.keys(r).length) {
			var s, n, o = null !== (s = null == (n = i.bootstrap) ? void 0 : n.featureFlagPayloads) && void 0 !== s ? s : {}, a = Object.keys(r).filter(((t) => !!r[t])).reduce(((t, e) => (t[e] = r[e] || !1, t)), {}), l = Object.keys(o).filter(((t) => a[t])).reduce(((t, e) => (o[e] && (t[e] = o[e]), t)), {});
			this.receivedFeatureFlags({
				featureFlags: a,
				featureFlagPayloads: l
			});
		}
	}
	updateFlags(t, e, i) {
		var r, s, n = null != i && i.merge && null !== (r = this.ss(Fi)) && void 0 !== r ? r : {}, o = null != i && i.merge && null !== (s = this.ss(Ni)) && void 0 !== s ? s : {}, a = f({}, n, t), l = f({}, o, e), u = {};
		for (var [h, d] of Object.entries(a)) u[h] = {
			key: h,
			enabled: m(d),
			variant: y(d),
			reason: void 0,
			metadata: V(null == l ? void 0 : l[h]) ? void 0 : {
				id: 0,
				version: void 0,
				description: void 0,
				payload: l[h]
			}
		};
		this.receivedFeatureFlags({ flags: u });
	}
	get hasLoadedFlags() {
		return this.Yn;
	}
	getFlags() {
		return Object.keys(this.getFlagVariants());
	}
	getFlagsWithDetails() {
		var t = this.ss(Li), e = this.ss(ji), i = this.ss(Bi);
		if (!i && !e) return t || {};
		var r = Sr({}, t || {});
		for (var n of [.../* @__PURE__ */ new Set([...Object.keys(i || {}), ...Object.keys(e || {})])]) {
			var o, a, l = r[n], u = null == e ? void 0 : e[n], h = V(u) ? null !== (o = null == l ? void 0 : l.enabled) && void 0 !== o && o : !!u, d = V(u) ? l.variant : "string" == typeof u ? u : void 0, v = null == i ? void 0 : i[n], c = f({}, l, {
				enabled: h,
				variant: h ? null != d ? d : null == l ? void 0 : l.variant : void 0
			});
			h !== (null == l ? void 0 : l.enabled) && (c.original_enabled = null == l ? void 0 : l.enabled), d !== (null == l ? void 0 : l.variant) && (c.original_variant = null == l ? void 0 : l.variant), v && (c.metadata = f({}, null == l ? void 0 : l.metadata, {
				payload: v,
				original_payload: null == l || null == (a = l.metadata) ? void 0 : a.payload
			})), r[n] = c;
		}
		return this.Jn || (Za.warn(" Overriding feature flag details!", {
			flagDetails: t,
			overriddenPayloads: i,
			finalDetails: r
		}), this.Jn = !0), r;
	}
	getAllFeatureFlags() {
		var t = this.getFlagVariants(), e = this.getFlagPayloads();
		return Object.keys(t).map(((i) => {
			var r = t[i];
			return {
				key: i,
				enabled: m(r),
				variant: y(r),
				payload: g(e[i])
			};
		}));
	}
	getFlagVariants() {
		var t = this.ss(Fi), e = this.ss(ji);
		if (!e) return t || {};
		for (var i = Sr({}, t), r = Object.keys(e), s = 0; r.length > s; s++) i[r[s]] = e[r[s]];
		return this.Jn || (Za.warn(" Overriding feature flags!", {
			enabledFlags: t,
			overriddenFlags: e,
			finalFlags: i
		}), this.Jn = !0), i;
	}
	getFlagPayloads() {
		var t = this.ss(Ni), e = this.ss(Bi);
		if (!e) return t || {};
		for (var i = Sr({}, t || {}), r = Object.keys(e), s = 0; r.length > s; s++) i[r[s]] = e[r[s]];
		return this.Jn || (Za.warn(" Overriding feature flag payloads!", {
			flagPayloads: t,
			overriddenPayloads: e,
			finalPayloads: i
		}), this.Jn = !0), i;
	}
	reloadFeatureFlags() {
		this.Xn || this.Se.advanced_disable_feature_flags || this.cs || (this._instance.Ti.emit("featureFlagsReloading", !0), this.cs = setTimeout((() => {
			this.vs();
		}), 5));
	}
	fs() {
		clearTimeout(this.cs), this.cs = void 0;
	}
	ensureFlagsLoaded() {
		this.Yn || this.Kn || this.cs || this.reloadFeatureFlags();
	}
	setAnonymousDistinctId(t) {
		this.$anon_distinct_id = t;
	}
	setReloadingPaused(t) {
		this.Xn = t;
	}
	vs(t) {
		var e;
		if (this.fs(), !this._instance.mr()) if (this.Kn) this.es = !0;
		else {
			var i = this.Se.token, r = this.ss(ci), s = {
				token: i,
				distinct_id: this._instance.get_distinct_id(),
				groups: this._instance.getGroups(),
				$anon_distinct_id: this.$anon_distinct_id,
				person_properties: f({}, (null == (e = this.zr) ? void 0 : e.get_initial_props()) || {}, this.ss(zi) || {}),
				group_properties: this.ss(Hi),
				timezone: pn()
			};
			Y(r) || V(r) || (s.$device_id = r), (null != t && t.disableFlags || this.Se.advanced_disable_feature_flags) && (s.disable_flags = !0), this.hs() && (s.evaluation_contexts = this.us());
			var n = this.ds();
			V(n) || (s.flag_keys = n);
			var o = !!this.Se.advanced_only_evaluate_survey_feature_flags, a = this._instance.requestRouter.endpointFor("flags", "/flags/?v=2" + (this.Se.advanced_only_evaluate_survey_feature_flags ? "&only_evaluate_survey_feature_flags=true" : ""));
			this.Kn = !0, this._instance._send_request({
				method: "POST",
				url: a,
				data: s,
				compression: this.Se.disable_compression ? void 0 : Un.Base64,
				timeout: this.Se.feature_flag_request_timeout_ms,
				callback: (t) => {
					var e, i, r, n = !0;
					if (200 === t.statusCode && (this.es || (this.$anon_distinct_id = void 0), n = !1), this.Kn = !1, !s.disable_flags || this.es) {
						this.ts = !n;
						var a = [];
						t.error ? t.error instanceof Error ? a.push("AbortError" === t.error.name ? "timeout" : "connection_error") : a.push("unknown_error") : 200 !== t.statusCode && a.push("api_error_" + t.statusCode), null != (e = t.json) && e.errorsWhileComputingFlags && a.push("errors_while_computing_flags");
						var l, u = !(null == (i = t.json) || null == (i = i.quotaLimited) || !i.includes("feature_flags"));
						if (u && a.push("quota_limited"), null == (r = this.zr) || r.register({ [Ji]: a }), u) Za.warn("You have hit your feature flags quota limit, and will not be able to load feature flags until the quota is reset.  Please visit https://posthog.com/docs/billing/limits-alerts to learn more.");
						else s.disable_flags || this.receivedFeatureFlags(null !== (l = t.json) && void 0 !== l ? l : {}, n, { partialResponse: o }), this.es && (this.es = !1, this.vs());
					}
				}
			});
		}
	}
	getFeatureFlag(t, e) {
		var i;
		if (void 0 === e && (e = {}), !e.fresh || this.ts) if (this.Yn || this.getFlags() && this.getFlags().length > 0) {
			if (!this.ls()) {
				var r = this.getFeatureFlagResult(t, e);
				return null !== (i = null == r ? void 0 : r.variant) && void 0 !== i ? i : null == r ? void 0 : r.enabled;
			}
		} else Za.warn("getFeatureFlag for key \"" + t + el);
	}
	getFeatureFlagDetails(t) {
		return this.getFlagsWithDetails()[t];
	}
	getFeatureFlagPayload(t) {
		var e = this.getFeatureFlagResult(t, { send_event: !1 });
		return null == e ? void 0 : e.payload;
	}
	getFeatureFlagResult(t, e) {
		if (void 0 === e && (e = {}), !e.fresh || this.ts) if (this.Yn || this.getFlags() && this.getFlags().length > 0) {
			if (!this.ls()) {
				var i = this.getFlagVariants(), r = t in i, s = i[t], n = this.getFlagPayloads()[t], o = String(s), a = this.ss(Ui) || void 0, l = this.ss(Qi) || void 0, u = this.ss(Yi) || {};
				if (this.Se.advanced_feature_flags_dedup_per_session) {
					var h, d = this._instance.get_session_id(), v = this.ss(Ki);
					d && d !== v && (u = {}, null == (h = this.zr) || h.register({
						[Yi]: u,
						[Ki]: d
					}));
				}
				if ((e.send_event || !("send_event" in e)) && (!(t in u) || !u[t].includes(o))) {
					var c, p, f, _, m, y, b, w, E, x;
					B(u[t]) ? u[t].push(o) : u[t] = [o], null == (c = this.zr) || c.register({ [Yi]: u });
					var S = this.getFeatureFlagDetails(t), T = [...null !== (p = this.ss(Ji)) && void 0 !== p ? p : []];
					V(s) && T.push("flag_missing");
					var k = {
						$feature_flag: t,
						$feature_flag_response: s,
						$feature_flag_payload: n || null,
						$feature_flag_request_id: a,
						$feature_flag_evaluated_at: l,
						$feature_flag_bootstrapped_response: (null == (f = this.Se.bootstrap) || null == (f = f.featureFlags) ? void 0 : f[t]) || null,
						$feature_flag_bootstrapped_payload: (null == (_ = this.Se.bootstrap) || null == (_ = _.featureFlagPayloads) ? void 0 : _[t]) || null,
						$used_bootstrap_value: !this.ts
					};
					V(null == S || null == (m = S.metadata) ? void 0 : m.version) || (k.$feature_flag_version = S.metadata.version);
					var R, P = null !== (y = null == S || null == (b = S.reason) ? void 0 : b.description) && void 0 !== y ? y : null == S || null == (w = S.reason) ? void 0 : w.code;
					P && (k.$feature_flag_reason = P), null != S && null != (E = S.metadata) && E.id && (k.$feature_flag_id = S.metadata.id), V(null == S ? void 0 : S.original_variant) && V(null == S ? void 0 : S.original_enabled) || (k.$feature_flag_original_response = V(S.original_variant) ? S.original_enabled : S.original_variant), null != S && null != (x = S.metadata) && x.original_payload && (k.$feature_flag_original_payload = null == S || null == (R = S.metadata) ? void 0 : R.original_payload), T.length && (k.$feature_flag_error = T.join(",")), this._instance.capture("$feature_flag_called", k);
				}
				if (r) return {
					key: t,
					enabled: !!s,
					variant: "string" == typeof s ? s : void 0,
					payload: g(n)
				};
			}
		} else Za.warn("getFeatureFlagResult for key \"" + t + el);
	}
	getRemoteConfigPayload(t, e) {
		var i = this.Se.token, r = {
			distinct_id: this._instance.get_distinct_id(),
			token: i
		};
		this.hs() && (r.evaluation_contexts = this.us());
		var s = this.ds();
		V(s) || (r.flag_keys = s), this._instance._send_request({
			method: "POST",
			url: this._instance.requestRouter.endpointFor("flags", "/flags/?v=2"),
			data: r,
			compression: this.Se.disable_compression ? void 0 : Un.Base64,
			timeout: this.Se.feature_flag_request_timeout_ms,
			callback(i) {
				var r, s = null == (r = i.json) ? void 0 : r.featureFlagPayloads;
				e((null == s ? void 0 : s[t]) || void 0);
			}
		});
	}
	isFeatureEnabled(t, e) {
		if (void 0 === e && (e = {}), !e.fresh || this.ts) {
			if (this.Yn || this.getFlags() && this.getFlags().length > 0) {
				var i = this.getFeatureFlag(t, e);
				return V(i) ? void 0 : !!i;
			}
			Za.warn("isFeatureEnabled for key \"" + t + el);
		}
	}
	addFeatureFlagsHandler(t) {
		this.featureFlagEventHandlers.push(t);
	}
	removeFeatureFlagsHandler(t) {
		this.featureFlagEventHandlers = this.featureFlagEventHandlers.filter(((e) => e !== t));
	}
	receivedFeatureFlags(t, e, i) {
		if (this.zr) {
			this.Yn = !0;
			var r = this.getFlagVariants(), s = this.getFlagPayloads(), n = this.getFlagsWithDetails();
			(function(t, e, i, r, s, n) {
				void 0 === i && (i = {}), void 0 === r && (r = {}), void 0 === s && (s = {});
				var o = ((t) => {
					var e = t.flags;
					return e ? (t.featureFlags = Object.fromEntries(Object.keys(e).map(((t) => {
						var i;
						return [t, null !== (i = e[t].variant) && void 0 !== i ? i : e[t].enabled];
					}))), t.featureFlagPayloads = Object.fromEntries(Object.keys(e).filter(((t) => e[t].enabled)).filter(((t) => {
						var i;
						return null == (i = e[t].metadata) ? void 0 : i.payload;
					})).map(((t) => {
						var i;
						return [t, null == (i = e[t].metadata) ? void 0 : i.payload];
					})))) : t.featureFlags && Za.warn("Using an older version of the feature flags endpoint. Please upgrade your PostHog server to the latest version"), t;
				})(t), a = o.flags, l = o.featureFlags, u = o.featureFlagPayloads;
				if (l) {
					var h = t.requestId, d = t.evaluatedAt;
					if (B(l)) {
						Za.warn("v1 of the feature flags endpoint is deprecated. Please use the latest version.");
						var v = {};
						if (l) for (var c = 0; l.length > c; c++) v[l[c]] = !0;
						e && e.register({
							[Mi]: l,
							[Fi]: v
						});
					} else {
						var p = l, _ = u, g = a;
						if (null != n && n.partialResponse) p = f({}, i, p), _ = f({}, r, _), g = f({}, s, g);
						else if (t.errorsWhileComputingFlags) if (a) {
							var m = new Set(Object.keys(a).filter(((t) => {
								var e;
								return !(null != (e = a[t]) && e.failed);
							})));
							p = f({}, i, Object.fromEntries(Object.entries(p).filter(((t) => {
								var [e] = t;
								return m.has(e);
							})))), _ = f({}, r, Object.fromEntries(Object.entries(_ || {}).filter(((t) => {
								var [e] = t;
								return m.has(e);
							})))), g = f({}, s, Object.fromEntries(Object.entries(g || {}).filter(((t) => {
								var [e] = t;
								return m.has(e);
							}))));
						} else p = f({}, i, p), _ = f({}, r, _), g = f({}, s, g);
						e && e.register(f({
							[Mi]: Object.keys(rl(p)),
							[Fi]: p || {},
							[Ni]: _ || {},
							[Li]: g || {}
						}, h ? { [Ui]: h } : {}, d ? { [Qi]: d } : {}));
					}
				}
			})(t, this.zr, r, s, n, i), e || (this.ns = !1), this.ps(e);
		}
	}
	override(t, e) {
		void 0 === e && (e = !1), Za.warn("override is deprecated. Please use overrideFeatureFlags instead."), this.overrideFeatureFlags({
			flags: t,
			suppressWarning: e
		});
	}
	overrideFeatureFlags(t) {
		if (!this._instance.__loaded || !this.zr) return Za.uninitializedWarning("posthog.featureFlags.overrideFeatureFlags");
		if (!1 === t) return this.zr.unregister(ji), this.zr.unregister(Bi), this.ps(), tl.info("All overrides cleared");
		if (B(t)) {
			var e = il(t);
			return this.zr.register({ [ji]: e }), this.ps(), tl.info("Flag overrides set", { flags: t });
		}
		if (t && "object" == typeof t && ("flags" in t || "payloads" in t)) {
			var i, r = t;
			if (this.Jn = Boolean(null !== (i = r.suppressWarning) && void 0 !== i && i), "flags" in r) {
				if (!1 === r.flags) this.zr.unregister(ji), tl.info("Flag overrides cleared");
				else if (r.flags) {
					if (B(r.flags)) {
						var s = il(r.flags);
						this.zr.register({ [ji]: s });
					} else this.zr.register({ [ji]: r.flags });
					tl.info("Flag overrides set", { flags: r.flags });
				}
			}
			"payloads" in r && (!1 === r.payloads ? (this.zr.unregister(Bi), tl.info("Payload overrides cleared")) : r.payloads && (this.zr.register({ [Bi]: r.payloads }), tl.info("Payload overrides set", { payloads: r.payloads }))), this.ps();
			return;
		}
		if (t && "object" == typeof t) return this.zr.register({ [ji]: t }), this.ps(), tl.info("Flag overrides set", { flags: t });
		Za.warn("Invalid overrideOptions provided to overrideFeatureFlags", { overrideOptions: t });
	}
	onFeatureFlags(t) {
		if (this.addFeatureFlagsHandler(t), this.Yn) {
			var { flags: e, flagVariants: i } = this.gs();
			try {
				t(e, i);
			} catch (t) {
				Za.error("Error while running feature flags callback", t);
			}
		}
		return () => this.removeFeatureFlagsHandler(t);
	}
	updateEarlyAccessFeatureEnrollment(t, e, i) {
		var r, s = (this.ss(Di) || []).find(((e) => e.flagKey === t)), n = { ["$feature_enrollment/" + t]: e }, o = {
			$feature_flag: t,
			$feature_enrollment: e,
			$set: n
		};
		s && (o.$early_access_feature_name = s.name), i && (o.$feature_enrollment_stage = i), this._instance.capture("$feature_enrollment_update", o), this.setPersonPropertiesForFlags(n, !1);
		var a = f({}, this.getFlagVariants(), { [t]: e });
		null == (r = this.zr) || r.register({
			[Mi]: Object.keys(rl(a)),
			[Fi]: a
		}), this.ps();
	}
	getEarlyAccessFeatures(t, e, i) {
		void 0 === e && (e = !1);
		var r = this.ss(Di), s = i ? "&" + i.map(((t) => "stage=" + t)).join("&") : "";
		if (r && !e) return t(r);
		this._instance._send_request({
			url: this._instance.requestRouter.endpointFor("api", "/api/early_access_features/?token=" + this.Se.token + s),
			method: "GET",
			callback: (e) => {
				var i, r;
				if (e.json) {
					var s = e.json.earlyAccessFeatures;
					return null == (i = this.zr) || i.unregister(Di), null == (r = this.zr) || r.register({ [Di]: s }), t(s);
				}
			}
		});
	}
	gs() {
		var t = this.getFlags(), e = this.getFlagVariants();
		return {
			flags: t.filter(((t) => e[t])),
			flagVariants: Object.keys(e).filter(((t) => e[t])).reduce(((t, i) => (t[i] = e[i], t)), {})
		};
	}
	ps(t) {
		var { flags: e, flagVariants: i } = this.gs();
		this.featureFlagEventHandlers.forEach(((r) => {
			try {
				r(e, i, { errorsLoading: t });
			} catch (t) {
				Za.error("Error while running feature flags callback", t);
			}
		}));
	}
	setPersonPropertiesForFlags(t, e) {
		void 0 === e && (e = !0);
		var i = this.ss(zi) || {}, r = (null == t ? void 0 : t.$set) || (null != t && t.$set_once ? {} : t), s = null == t ? void 0 : t.$set_once, n = {};
		if (s) for (var o in s) ({}).hasOwnProperty.call(s, o) && (o in i || (n[o] = s[o]));
		this._instance.register({ [zi]: f({}, i, n, r) }), e && this._instance.reloadFeatureFlags();
	}
	unsetPersonPropertiesForFlags(t, e) {
		void 0 === e && (e = !0);
		var i = f({}, this.ss(zi) || {});
		t.forEach(((t) => {
			delete i[t];
		})), this._instance.register({ [zi]: i }), e && this._instance.reloadFeatureFlags();
	}
	resetPersonPropertiesForFlags(t) {
		void 0 === t && (t = !0), this._instance.unregister(zi), t && this._instance.reloadFeatureFlags();
	}
	setGroupPropertiesForFlags(t, e) {
		void 0 === e && (e = !0);
		var i = this.ss(Hi) || {};
		0 !== Object.keys(i).length && Object.keys(i).forEach(((e) => {
			i[e] = f({}, i[e], t[e]), delete t[e];
		})), this._instance.register({ [Hi]: f({}, i, t) }), e && this._instance.reloadFeatureFlags();
	}
	resetGroupPropertiesForFlags(t) {
		if (t) {
			var e = this.ss(Hi) || {};
			this._instance.register({ [Hi]: f({}, e, { [t]: {} }) });
		} else this._instance.unregister(Hi);
	}
	reset() {
		this.Yn = !1, this.Kn = !1, this.Xn = !1, this.es = !1, this.ts = !1, this.$anon_distinct_id = void 0, this.fs(), this.Jn = !1;
	}
} }, vl = { sessionRecording: class {
	get Se() {
		return this._instance.config;
	}
	get zr() {
		return this._instance.persistence;
	}
	get started() {
		var t;
		return !(null == (t = this.ys) || !t.isStarted);
	}
	get status() {
		var t, e;
		return this.bs === Aa || this.bs === Fa ? this.bs : null !== (t = null == (e = this.ys) ? void 0 : e.status) && void 0 !== t ? t : this.bs;
	}
	constructor(t) {
		if (this._forceAllowLocalhostNetworkCapture = !1, this.bs = Oa, this._s = void 0, this._instance = t, !this._instance.sessionManager) throw Da.error("started without valid sessionManager"), /* @__PURE__ */ new Error(Ma + " started without valid sessionManager. This is a bug.");
		if (this.Se.cookieless_mode === vr) throw new Error(Ma + " cannot be used with cookieless_mode=\"always\"");
	}
	initialize() {
		this.startIfEnabledOrStop();
	}
	get ws() {
		var e, i = !(null == (e = this._instance.get_property($i)) || !e.enabled), r = !this.Se.disable_session_recording, s = this.Se.disable_session_recording || this._instance.consent.isOptedOut();
		return t && i && r && !s;
	}
	startIfEnabledOrStop(t) {
		var e;
		if (!this.ws || null == (e = this.ys) || !e.isStarted) {
			var i = !V(Object.assign) && !V(Array.from);
			this.ws && i ? (this.xs(t), Da.info("starting")) : (this.bs = Oa, this.stopRecording());
		}
	}
	xs(t) {
		var e, i, r;
		this.ws && (this.bs !== Aa && this.bs !== Fa && (this.bs = Ca), null != h && null != (e = h.__PosthogExtensions__) && null != (e = e.rrweb) && e.record && null != (i = h.__PosthogExtensions__) && i.initSessionRecording ? this.ks(t) : null == (r = h.__PosthogExtensions__) || null == r.loadExternalDependency || r.loadExternalDependency(this._instance, this.Ss, ((e) => {
			if (e) return Da.error("could not load recorder", e);
			this.ks(t);
		})));
	}
	stopRecording() {
		var t, e;
		null == (t = this._s) || t.call(this), this._s = void 0, null == (e = this.ys) || e.stop();
	}
	Cs() {
		var t, e;
		null == (t = this._s) || t.call(this), this._s = void 0, null == (e = this.ys) || e.discard();
	}
	Is() {
		var t, e;
		null == (t = this.zr) || t.unregister(Ai), null == (e = this.zr) || e.unregister(ki);
	}
	Ts(t, e) {
		if (K(t)) return null;
		var i, r = J(t) ? t : parseFloat(t);
		return "number" != typeof (i = r) || !Number.isFinite(i) || 0 > i || i > 1 ? (Da.warn(e + " must be between 0 and 1. Ignoring invalid value:", t), null) : r;
	}
	Es(t) {
		if (this.zr) {
			var e, i, r = this.zr, s = () => {
				var e, i = !1 === t.sessionRecording ? void 0 : t.sessionRecording, s = this.Ts(null == (e = this.Se.session_recording) ? void 0 : e.sampleRate, "session_recording.sampleRate"), n = this.Ts(null == i ? void 0 : i.sampleRate, "remote config sampleRate"), o = null != s ? s : n;
				K(o) && this.Is();
				var a = null == i ? void 0 : i.minimumDurationMilliseconds;
				r.register({ [$i]: f({
					cache_timestamp: Date.now(),
					enabled: !!i
				}, i, {
					networkPayloadCapture: f({ capturePerformance: t.capturePerformance }, null == i ? void 0 : i.networkPayloadCapture),
					canvasRecording: {
						enabled: null == i ? void 0 : i.recordCanvas,
						fps: null == i ? void 0 : i.canvasFps,
						quality: null == i ? void 0 : i.canvasQuality
					},
					sampleRate: o,
					minimumDurationMilliseconds: V(a) ? null : a,
					endpoint: null == i ? void 0 : i.endpoint,
					triggerMatchType: null == i ? void 0 : i.triggerMatchType,
					masking: null == i ? void 0 : i.masking,
					urlTriggers: null == i ? void 0 : i.urlTriggers,
					version: null == i ? void 0 : i.version,
					triggerGroups: null == i ? void 0 : i.triggerGroups
				}) });
			};
			s(), null == (e = this._s) || e.call(this), this._s = null == (i = this._instance.sessionManager) ? void 0 : i.onSessionId(s);
		}
	}
	onRemoteConfig(t) {
		"sessionRecording" in t ? !1 === t.sessionRecording ? (this.Es(t), this.Cs()) : (this.Es(t), this.startIfEnabledOrStop()) : (this.bs === Aa && (this.bs = Fa, Da.warn("config refresh failed, recording will not start until page reload")), this.startIfEnabledOrStop());
	}
	log(t, e) {
		var i;
		void 0 === e && (e = "log"), null != (i = this.ys) && i.log ? this.ys.log(t, e) : Da.warn("log called before recorder was ready");
	}
	get Ss() {
		var t, e, i = null == (t = this._instance) || null == (t = t.persistence) ? void 0 : t.get_property($i);
		return (null == i || null == (e = i.scriptConfig) ? void 0 : e.script) || "lazy-recorder";
	}
	Ms() {
		var t, e, i = this._instance.get_property($i);
		if (!i) return !1;
		try {
			e = "object" == typeof i ? i : JSON.parse(i);
		} catch (t) {
			return Da.warn("persisted remote config for session recording is invalid and will be ignored", t), !1;
		}
		var r = null !== (t = e.cache_timestamp) && void 0 !== t ? t : Date.now();
		return 36e5 >= Date.now() - r;
	}
	ks(t) {
		var e, i;
		if (null == (e = h.__PosthogExtensions__) || !e.initSessionRecording) return Da.warn("Called on script loaded before session recording is available. This can be caused by adblockers."), void this._instance.register_for_session({ [ur]: !0 });
		if (this.ys || (this.ys = null == (i = h.__PosthogExtensions__) ? void 0 : i.initSessionRecording(this._instance), this.ys._forceAllowLocalhostNetworkCapture = this._forceAllowLocalhostNetworkCapture), !this.Ms()) {
			if (this.bs === Fa || this.bs === Aa) return;
			this.bs = Aa, Da.info("persisted remote config is stale, requesting fresh config before starting"), new Ln(this._instance).load();
			return;
		}
		this.bs = Ca, this.ys.start(t);
	}
	onRRwebEmit(t) {
		var e;
		null == (e = this.ys) || null == e.onRRwebEmit || e.onRRwebEmit(t);
	}
	overrideLinkedFlag() {
		var t, e;
		this.ys || null == (e = this.zr) || e.register({ [Pi]: !0 }), null == (t = this.ys) || t.overrideLinkedFlag();
	}
	overrideSampling() {
		var t, e;
		this.ys || null == (e = this.zr) || e.register({ [Ri]: !0 }), null == (t = this.ys) || t.overrideSampling();
	}
	overrideTrigger(t) {
		var e, i;
		this.ys || null == (i = this.zr) || i.register({ ["url" === t ? Ii : Oi]: !0 }), null == (e = this.ys) || e.overrideTrigger(t);
	}
	get sdkDebugProperties() {
		var t;
		return (null == (t = this.ys) ? void 0 : t.sdkDebugProperties) || { $recording_status: this.status };
	}
	tryAddCustomEvent(t, e) {
		var i;
		return !(null == (i = this.ys) || !i.tryAddCustomEvent(t, e));
	}
} }, cl = {
	autocapture: class {
		constructor(t) {
			this.Ps = !1, this.Rs = null, this.Os = !1, this.instance = t, this.rageclicks = new wa(t.config.rageclick), this.Ls = null;
		}
		initialize() {
			this.startIfEnabled();
		}
		get Se() {
			var t, e, i = H(this.instance.config.autocapture) ? this.instance.config.autocapture : {};
			return i.url_allowlist = null == (t = i.url_allowlist) ? void 0 : t.map(((t) => new RegExp(t))), i.url_ignorelist = null == (e = i.url_ignorelist) ? void 0 : e.map(((t) => new RegExp(t))), i;
		}
		Fs() {
			if (this.isBrowserSupported()) {
				if (t && r) {
					var e = (e) => {
						e = e || (null == t ? void 0 : t.event);
						try {
							this.As(e);
						} catch (t) {
							xa.error("Failed to capture event", t);
						}
					};
					if (Or(r, "submit", e, { capture: !0 }), Or(r, "change", e, { capture: !0 }), Or(r, "click", e, { capture: !0 }), this.Se.capture_copied_text) {
						var i = (e) => {
							e = e || (null == t ? void 0 : t.event);
							try {
								this.As(e, Ea);
							} catch (t) {
								xa.error("Failed to capture copy/cut event", t);
							}
						};
						Or(r, "copy", i, { capture: !0 }), Or(r, "cut", i, { capture: !0 });
					}
				}
			} else xa.info("Disabling Automatic Event Collection because this browser is not supported");
		}
		startIfEnabled() {
			this.isEnabled && !this.Ps && (this.Fs(), this.Ps = !0);
		}
		onRemoteConfig(t) {
			t.elementsChainAsString && (this.Os = t.elementsChainAsString), this.instance.persistence && this.instance.persistence.register({ [gi]: !!t.autocapture_opt_out }), this.Rs = !!t.autocapture_opt_out, this.startIfEnabled();
		}
		setElementSelectors(t) {
			this.Ls = t;
		}
		getElementSelectors(t) {
			var e, i = [];
			return null == (e = this.Ls) || e.forEach(((e) => {
				(null == r ? void 0 : r.querySelectorAll(e))?.forEach(((r) => {
					t === r && i.push(e);
				}));
			})), i;
		}
		get isEnabled() {
			var t, e, i = null == (t = this.instance.persistence) ? void 0 : t.props[gi];
			if (Y(this.Rs) && !X(i) && !this.instance.mr()) return !1;
			var r = null !== (e = this.Rs) && void 0 !== e ? e : !!i;
			return !!this.instance.config.autocapture && !r;
		}
		As(e, i) {
			if (void 0 === i && (i = "$autocapture"), this.isEnabled) {
				var r, s = ds(e);
				ss(s) && (s = s.parentNode || null), "$autocapture" === i && "click" === e.type && e instanceof MouseEvent && this.instance.config.rageclick && null != (r = this.rageclicks) && r.isRageClick(e.clientX, e.clientY, e.timeStamp || (/* @__PURE__ */ new Date()).getTime()) && ws(s, this.instance.config.rageclick) && this.As(e, "$rageclick");
				var n = i === Ea;
				if (s && function(e, i, r, s, n, o) {
					var a, l, u, h, d, v;
					if (void 0 === r && (r = void 0), !t || Es(e)) return !1;
					if (null != (a = r) && a.url_allowlist && !as(r.url_allowlist, o)) return !1;
					if (null != (l = r) && l.url_ignorelist && as(r.url_ignorelist, o)) return !1;
					if (null != (u = r) && u.dom_event_allowlist) {
						var c = r.dom_event_allowlist;
						if (c && !c.some(((t) => i.type === t))) return !1;
					}
					var { parentIsUsefulElement: p, targetElementList: f } = xs(e, s);
					if (!function(t, e) {
						var i = null == e ? void 0 : e.element_allowlist;
						if (V(i)) return !0;
						var r, s = function(t) {
							if (i.some(((e) => t.tagName.toLowerCase() === e))) return { v: !0 };
						};
						for (var n of t) if (r = s(n)) return r.v;
						return !1;
					}(f, r)) return !1;
					if (!cs(f, null == (h = r) ? void 0 : h.css_selector_allowlist)) return !1;
					if (cs(f, null !== (d = null == (v = r) ? void 0 : v.css_selector_ignorelist) && void 0 !== d ? d : fs)) return !1;
					try {
						var _ = t.getComputedStyle(e);
						if (_ && "pointer" === _.getPropertyValue("cursor") && "click" === i.type) return !0;
					} catch (t) {}
					var g = e.tagName.toLowerCase();
					switch (g) {
						case "html": return !1;
						case "form": return (n || ["submit"]).indexOf(i.type) >= 0;
						case "input":
						case "select":
						case "textarea": return (n || ["change", "click"]).indexOf(i.type) >= 0;
						default: return p ? (n || ["click"]).indexOf(i.type) >= 0 : (n || ["click"]).indexOf(i.type) >= 0 && (vs.indexOf(g) > -1 || "true" === e.getAttribute("contenteditable"));
					}
				}(s, e, this.Se, n, n ? ["copy", "cut"] : void 0, this.instance)) {
					var { props: o, explicitNoCapture: a } = $a(s, {
						e,
						maskAllElementAttributes: this.instance.config.mask_all_element_attributes,
						maskAllText: this.instance.config.mask_all_text,
						elementAttributeIgnoreList: this.Se.element_attribute_ignorelist,
						elementsChainAsString: this.Os,
						disableCaptureUrlHashes: this.instance.config.disable_capture_url_hashes
					});
					if (a) return !1;
					var l = this.getElementSelectors(s);
					if (l && l.length > 0 && (o.$element_selectors = l), i === Ea) {
						var u, h = us(null == t || null == (u = t.getSelection()) ? void 0 : u.toString()), d = e.type || "clipboard";
						if (!h) return !1;
						o.$selected_content = h, o.$copy_type = d;
					}
					return this.instance.capture(i, o), !0;
				}
			}
		}
		isBrowserSupported() {
			return z(null == r ? void 0 : r.querySelectorAll);
		}
	},
	historyAutocapture: class {
		constructor(e) {
			var i;
			this._instance = e, this.$s = (null == t || null == (i = t.location) ? void 0 : i.pathname) || "";
		}
		initialize() {
			this.startIfEnabled();
		}
		get isEnabled() {
			return "history_change" === this._instance.config.capture_pageview;
		}
		startIfEnabled() {
			this.isEnabled && (li.info("History API monitoring enabled, starting..."), this.monitorHistoryChanges());
		}
		stop() {
			this.Ds && this.Ds(), this.Ds = void 0, li.info("History API monitoring stopped");
		}
		monitorHistoryChanges() {
			t && t.history && (this.Ns("pushState"), this.Ns("replaceState"), this.qs());
		}
		Ns(e) {
			var i;
			if (t && (null == (i = t.history[e]) || !i.__posthog_wrapped__)) {
				var r = this;
				(function(t, e, i) {
					try {
						if (!(e in t)) return () => {};
						var r = t[e], s = i(r);
						return z(s) && (s.prototype = s.prototype || {}, Object.defineProperties(s, { __posthog_wrapped__: {
							enumerable: !1,
							value: !0
						} })), t[e] = s, () => {
							t[e] === s && (t[e] = r);
						};
					} catch (t) {
						return () => {};
					}
				})(t.history, e, ((t) => function(i, s, n) {
					t.call(this, i, s, n), r.Bs(e);
				}));
			}
		}
		Bs(e) {
			try {
				var i, r = null == t || null == (i = t.location) ? void 0 : i.pathname;
				if (!r) return;
				r !== this.$s && this.isEnabled && this._instance.capture(mr, { navigation_type: e }), this.$s = r;
			} catch (t) {
				li.error("Error capturing " + e + " pageview", t);
			}
		}
		qs() {
			if (!this.Ds) {
				var e = () => {
					this.Bs("popstate");
				};
				Or(t, "popstate", e), this.Ds = () => {
					t && t.removeEventListener("popstate", e);
				};
			}
		}
	},
	heatmaps: class {
		get Se() {
			return this.instance.config;
		}
		constructor(t) {
			var e;
			this.js = !1, this.Ps = !1, this.Hs = null, this.instance = t, this.js = !(null == (e = this.instance.persistence) || !e.props[mi]), this.rageclicks = new wa(t.config.rageclick);
		}
		initialize() {
			this.startIfEnabled();
		}
		get flushIntervalMilliseconds() {
			var t = 5e3;
			return H(this.Se.capture_heatmaps) && this.Se.capture_heatmaps.flush_interval_milliseconds && (t = this.Se.capture_heatmaps.flush_interval_milliseconds), t;
		}
		get isEnabled() {
			return K(this.Se.capture_heatmaps) ? K(this.Se.enable_heatmaps) ? this.js : this.Se.enable_heatmaps : !1 !== this.Se.capture_heatmaps;
		}
		startIfEnabled() {
			if (this.isEnabled) {
				if (this.Ps) return;
				La.info("starting..."), this.Us(), this.ke();
			} else {
				var t;
				clearInterval(null !== (t = this.Hs) && void 0 !== t ? t : void 0), this.zs(), this.getAndClearBuffer();
			}
		}
		onRemoteConfig(t) {
			if ("heatmaps" in t) {
				var e = !!t.heatmaps;
				this.instance.persistence && this.instance.persistence.register({ [mi]: e }), this.js = e, this.startIfEnabled();
			}
		}
		getAndClearBuffer() {
			var t = this.R;
			return this.R = void 0, t;
		}
		Vs(t) {
			this.fe(t.originalEvent, "deadclick");
		}
		ke() {
			this.Hs && clearInterval(this.Hs), this.Hs = "visible" === (null == r ? void 0 : r.visibilityState) ? setInterval(this.Lr.bind(this), this.flushIntervalMilliseconds) : null;
		}
		Us() {
			t && r && (this.Ws = this.Lr.bind(this), Or(t, gr, this.Ws), this.Gs = (e) => this.fe(e || (null == t ? void 0 : t.event)), Or(r, "click", this.Gs, { capture: !0 }), this.Zs = (e) => this.Qs(e || (null == t ? void 0 : t.event)), Or(r, "mousemove", this.Zs, { capture: !0 }), this.Js = new js(this.instance, Ns, this.Vs.bind(this)), this.Js.startIfEnabledOrStop(), this.Ys = this.ke.bind(this), Or(r, _r, this.Ys), this.Ps = !0);
		}
		zs() {
			var e;
			t && r && (this.Ws && t.removeEventListener(gr, this.Ws), this.Gs && r.removeEventListener("click", this.Gs, { capture: !0 }), this.Zs && r.removeEventListener("mousemove", this.Zs, { capture: !0 }), this.Ys && r.removeEventListener(_r, this.Ys), clearTimeout(this.Ks), null == (e = this.Js) || e.stop(), this.Ps = !1);
		}
		Xs(e, i) {
			var r = this.instance.scrollManager.scrollY(), s = this.instance.scrollManager.scrollX(), n = this.instance.scrollManager.scrollElement(), o = function(e, i, r) {
				for (var s = e; s && is(s) && !rs(s, "body");) {
					if (s === r) return !1;
					var n = void 0;
					try {
						var o, a, l;
						n = null == (o = null !== (a = null == (l = s.ownerDocument) ? void 0 : l.defaultView) && void 0 !== a ? a : t) ? void 0 : o.getComputedStyle(s).position;
					} catch (t) {
						return !1;
					}
					if (M(i, n)) return !0;
					s = ps(s);
				}
				return !1;
			}(ds(e), ["fixed", "sticky"], n);
			return {
				x: e.clientX + (o ? 0 : s),
				y: e.clientY + (o ? 0 : r),
				target_fixed: o,
				type: i
			};
		}
		fe(t, e) {
			var i;
			if (void 0 === e && (e = "click"), !es(t.target) && Na(t)) {
				var r = this.Xs(t, e);
				null != (i = this.rageclicks) && i.isRageClick(t.clientX, t.clientY, (/* @__PURE__ */ new Date()).getTime()) && ws(ds(t), this.instance.config.rageclick) && this.eo(f({}, r, { type: "rageclick" })), this.eo(r);
			}
		}
		Qs(t) {
			!es(t.target) && Na(t) && (clearTimeout(this.Ks), this.Ks = setTimeout((() => {
				this.eo(this.Xs(t, "mousemove"));
			}), 500));
		}
		eo(e) {
			if (t) {
				var i = this.Se.disable_capture_url_hashes ? _e(t.location.href) : t.location.href, r = this.Se.custom_personal_data_properties, n = Xs(i, this.Se.mask_personal_data_properties ? [...en, ...r || []] : [], sn);
				this.R = this.R || {}, this.R[n] || (this.R[n] = []), this.R[n].push(e);
			}
		}
		Lr() {
			this.R && !q(this.R) && this.instance.capture("$$heatmap", { $heatmap_data: this.getAndClearBuffer() });
		}
	},
	deadClicksAutocapture: js,
	webVitalsAutocapture: class {
		constructor(t) {
			var e;
			this.js = !1, this.Ps = !1, this.R = {
				url: void 0,
				metrics: [],
				firstMetricTimestamp: void 0
			}, this.ro = () => {
				clearTimeout(this.io), 0 !== this.R.metrics.length && (this._instance.capture("$web_vitals", this.R.metrics.reduce(((t, e) => f({}, t, {
					["$web_vitals_" + e.name + "_event"]: f({}, e),
					["$web_vitals_" + e.name + "_value"]: e.value
				})), {})), this.R = {
					url: void 0,
					metrics: [],
					firstMetricTimestamp: void 0
				});
			}, this.no = (t) => {
				var e;
				this.R = this.R || {
					url: void 0,
					metrics: [],
					firstMetricTimestamp: void 0
				};
				var i = this.so();
				if (!V(i)) if (K(null == t ? void 0 : t.name) || K(null == t ? void 0 : t.value)) Pa.error("Invalid metric received", t);
				else if (!this.oo || this.oo > t.value) {
					this.R.url !== i && (this.ro(), this.io = setTimeout(this.ro, this.flushToCaptureTimeoutMs)), V(this.R.url) && (this.R.url = i), this.R.firstMetricTimestamp = V(this.R.firstMetricTimestamp) ? Date.now() : this.R.firstMetricTimestamp, t.attribution && t.attribution.interactionTargetElement && (t.attribution.interactionTargetElement = void 0);
					var r = null == (e = this._instance.sessionManager) ? void 0 : e.checkAndGetSessionAndWindowId(!0), s = f({}, t, {
						$current_url: i,
						timestamp: Date.now()
					});
					V(r) || (s.$session_id = r.sessionId, s.$window_id = r.windowId), this.R.metrics.push(s), this.R.metrics.length === this.allowedMetrics.length && this.ro();
				} else Pa.error("Ignoring metric with value >= " + this.oo, t);
			}, this.ao = () => {
				if (!this.Ps) {
					var t, e, i, r, s = h.__PosthogExtensions__;
					V(s) || V(s.postHogWebVitalsCallbacks) || ({onLCP: t, onCLS: e, onFCP: i, onINP: r} = s.postHogWebVitalsCallbacks), t && e && i && r ? (this.allowedMetrics.indexOf("LCP") > -1 && t(this.no.bind(this)), this.allowedMetrics.indexOf("CLS") > -1 && e(this.no.bind(this)), this.allowedMetrics.indexOf("FCP") > -1 && i(this.no.bind(this)), this.allowedMetrics.indexOf("INP") > -1 && r(this.no.bind(this)), this.Ps = !0) : Pa.error("web vitals callbacks not loaded - not starting");
				}
			}, this._instance = t, this.js = !(null == (e = this._instance.persistence) || !e.props[Ei]), this.startIfEnabled();
		}
		get lo() {
			return this._instance.config.capture_performance;
		}
		get allowedMetrics() {
			var t, e, i = H(this.lo) ? null == (t = this.lo) ? void 0 : t.web_vitals_allowed_metrics : void 0;
			return K(i) ? (null == (e = this._instance.persistence) ? void 0 : e.props[Ti]) || [
				"CLS",
				"FCP",
				"INP",
				"LCP"
			] : i;
		}
		get flushToCaptureTimeoutMs() {
			return (H(this.lo) ? this.lo.web_vitals_delayed_flush_ms : void 0) || 5e3;
		}
		get useAttribution() {
			var t = H(this.lo) ? this.lo.web_vitals_attribution : void 0;
			return null != t && t;
		}
		get oo() {
			var t = H(this.lo) && J(this.lo.__web_vitals_max_value) ? this.lo.__web_vitals_max_value : Ia;
			return t > 0 && 6e4 >= t ? Ia : t;
		}
		get isEnabled() {
			var t = null == s ? void 0 : s.protocol;
			if ("http:" !== t && "https:" !== t) return Pa.info("Web Vitals are disabled on non-http/https protocols"), !1;
			var e = H(this.lo) ? this.lo.web_vitals : X(this.lo) ? this.lo : void 0;
			return X(e) ? e : this.js;
		}
		startIfEnabled() {
			this.isEnabled && !this.Ps && (Pa.info("enabled, starting..."), this.Mt(this.ao));
		}
		onRemoteConfig(t) {
			if ("capturePerformance" in t) {
				var e = H(t.capturePerformance) && !!t.capturePerformance.web_vitals, i = H(t.capturePerformance) ? t.capturePerformance.web_vitals_allowed_metrics : void 0;
				this._instance.persistence && (this._instance.persistence.register({ [Ei]: e }), this._instance.persistence.register({ [Ti]: i })), this.js = e, this.startIfEnabled();
			}
		}
		Mt(t) {
			var e, i;
			null != (e = h.__PosthogExtensions__) && e.postHogWebVitalsCallbacks ? t() : null == (i = h.__PosthogExtensions__) || null == i.loadExternalDependency || i.loadExternalDependency(this._instance, this.useAttribution ? "web-vitals-with-attribution" : "web-vitals", ((e) => {
				e ? Pa.error("failed to load script", e) : t();
			}));
		}
		so() {
			var e = t ? this._instance.config.disable_capture_url_hashes ? _e(t.location.href) : t.location.href : void 0;
			if (e) {
				var i = this._instance.config.custom_personal_data_properties;
				return Xs(e, this._instance.config.mask_personal_data_properties ? [...en, ...i || []] : [], sn);
			}
			Pa.error("Could not determine current URL");
		}
	}
}, pl = {
	exceptionObserver: class {
		constructor(e) {
			var i, r, s;
			this.ao = () => {
				var e;
				if (t && this.isEnabled && null != (e = h.__PosthogExtensions__) && e.errorWrappingFunctions) {
					var i = h.__PosthogExtensions__.errorWrappingFunctions.wrapOnError, r = h.__PosthogExtensions__.errorWrappingFunctions.wrapUnhandledRejection, s = h.__PosthogExtensions__.errorWrappingFunctions.wrapConsoleError;
					try {
						!this.uo && this.Se.capture_unhandled_errors && (this.uo = i(this.captureException.bind(this))), !this.ho && this.Se.capture_unhandled_rejections && (this.ho = r(this.captureException.bind(this))), !this.do && this.Se.capture_console_errors && (this.do = s(this.captureException.bind(this)));
					} catch (t) {
						ka.error("failed to start", t), this.co();
					}
				}
			}, this._instance = e, this.vo = !(null == (i = this._instance.persistence) || !i.props[yi]), this.fo = new ut({
				refillRate: null !== (r = this._instance.config.error_tracking.__exceptionRateLimiterRefillRate) && void 0 !== r ? r : 1,
				bucketSize: null !== (s = this._instance.config.error_tracking.__exceptionRateLimiterBucketSize) && void 0 !== s ? s : 10,
				refillInterval: 1e4,
				Ae: ka
			}), this.Se = this.po(), this.startIfEnabledOrStop();
		}
		po() {
			var t = this._instance.config.capture_exceptions, e = {
				capture_unhandled_errors: !1,
				capture_unhandled_rejections: !1,
				capture_console_errors: !1
			};
			return H(t) ? e = f({}, e, t) : (V(t) ? this.vo : t) && (e = f({}, e, {
				capture_unhandled_errors: !0,
				capture_unhandled_rejections: !0
			})), e;
		}
		get isEnabled() {
			return this.Se.capture_console_errors || this.Se.capture_unhandled_errors || this.Se.capture_unhandled_rejections;
		}
		startIfEnabledOrStop() {
			this.isEnabled ? (ka.info("enabled"), this.co(), this.Mt(this.ao)) : this.co();
		}
		Mt(t) {
			var e, i;
			null != (e = h.__PosthogExtensions__) && e.errorWrappingFunctions ? t() : null == (i = h.__PosthogExtensions__) || null == i.loadExternalDependency || i.loadExternalDependency(this._instance, "exception-autocapture", ((e) => {
				if (e) return ka.error("failed to load script", e);
				t();
			}));
		}
		co() {
			var t, e, i;
			null == (t = this.uo) || t.call(this), this.uo = void 0, null == (e = this.ho) || e.call(this), this.ho = void 0, null == (i = this.do) || i.call(this), this.do = void 0;
		}
		onRemoteConfig(t) {
			"autocaptureExceptions" in t && (this.vo = !!t.autocaptureExceptions || !1, this._instance.persistence && this._instance.persistence.register({ [yi]: this.vo }), this.Se = this.po(), this.startIfEnabledOrStop());
		}
		onConfigChange() {
			this.Se = this.po();
		}
		captureException(t) {
			var e, i, r, s = null !== (e = null == t || null == (i = t.$exception_list) || null == (i = i[0]) ? void 0 : i.type) && void 0 !== e ? e : "Exception";
			this.fo.consumeRateLimit(s) ? ka.info("Skipping exception capture because of client rate limiting.", { exception: s }) : null == (r = this._instance.exceptions) || r.sendExceptionEvent(t);
		}
	},
	exceptions: class {
		constructor(t) {
			var e, i;
			this.mo = [], this.yo = new Oe([
				new He(),
				new Ze(),
				new Ve(),
				new qe(),
				new Qe(),
				new Je(),
				new We(),
				new Xe()
			], function(t) {
				for (var e = arguments.length, i = new Array(e > 1 ? e - 1 : 0), r = 1; e > r; r++) i[r - 1] = arguments[r];
				return function(e, r) {
					void 0 === r && (r = 0);
					for (var s = [], n = e.split("\n"), o = r; n.length > o; o++) {
						var a = n[o];
						if (1024 >= a.length) {
							var l = ze.test(a) ? a.replace(ze, "$1") : a;
							if (!l.match(/\S*Error: /)) {
								for (var u of i) {
									var h = u(l, t);
									if (h) {
										s.push(h);
										break;
									}
								}
								if (s.length >= 50) break;
							}
						}
					}
					return function(t) {
						if (!t.length) return [];
						var e = Array.from(t);
						return e.reverse(), e.slice(0, 50).map(((t) => {
							return f({}, t, {
								filename: t.filename || (i = e, i[i.length - 1] || {}).filename,
								function: t.function || Ce
							});
							var i;
						}));
					}(s);
				};
			}("web:javascript", Ne, Be)), this._instance = t, this.mo = null !== (e = null == (i = this._instance.persistence) ? void 0 : i.get_property(bi)) && void 0 !== e ? e : [], this.bo = si(this._o()), this.wo = new ni(this.bo);
		}
		onConfigChange() {
			this.bo = si(this._o()), this.wo.setConfig(this.bo);
		}
		onRemoteConfig(t) {
			var e, i, r;
			if ("errorTracking" in t) {
				var s = null !== (e = null == (i = t.errorTracking) ? void 0 : i.suppressionRules) && void 0 !== e ? e : [], n = null == (r = t.errorTracking) ? void 0 : r.captureExtensionExceptions;
				this.mo = s, this._instance.persistence && this._instance.persistence.register({
					[bi]: this.mo,
					[wi]: n
				});
			}
		}
		get xo() {
			var t, e = !!this._instance.get_property(wi), i = this._instance.config.error_tracking.captureExtensionExceptions;
			return null !== (t = null != i ? i : e) && void 0 !== t && t;
		}
		buildProperties(t, e) {
			return this.yo.buildFromUnknown(t, {
				syntheticException: null == e ? void 0 : e.syntheticException,
				mechanism: { handled: null == e ? void 0 : e.handled }
			});
		}
		addExceptionStep(t, e) {
			if (this.bo.enabled) try {
				if (!G(t) || 0 === t.trim().length) return void sl.warn("Ignoring exception step because message must be a non-empty string");
				var { sanitizedProperties: r, droppedKeys: s } = function(t) {
					if (!t) return {
						sanitizedProperties: {},
						droppedKeys: []
					};
					var e = [];
					return {
						sanitizedProperties: Object.keys(t).reduce(((i, r) => ii.has(r) ? (e.push(r), i) : (i[r] = t[r], i)), {}),
						droppedKeys: e
					};
				}(this.ko(e));
				s.length > 0 && sl.warn("Ignoring reserved exception step fields", { droppedKeys: s }), this.wo.add(f({
					[ti]: t,
					[ei]: (/* @__PURE__ */ new Date()).toISOString()
				}, r));
			} catch (t) {
				sl.error("Failed to add exception step. Ignoring breadcrumb.", t);
			}
		}
		sendExceptionEvent(t) {
			try {
				var e = t.$exception_list;
				if (this.So(e)) {
					if (this.Co(e)) return this.Io("Exception dropped: matched a suppression rule"), void sl.info("Skipping exception capture because a suppression rule matched");
					if (!this.xo && this.To(e)) return this.Io("Exception dropped: thrown by a browser extension"), void sl.info("Skipping exception capture because it was thrown by an extension");
					if (!this._instance.config.error_tracking.__capturePostHogExceptions && this.Eo(e)) return this.Io("Exception dropped: thrown by the PostHog SDK"), void sl.info("Skipping exception capture because it was thrown by the PostHog SDK");
				}
				var i = this.bo.enabled && K(t.$exception_steps) ? this.Mo(t) : t;
				try {
					var r = this._instance.capture("$exception", i, {
						_noTruncate: !0,
						_batchKey: "exceptionEvent",
						Zi: !0
					});
					return r && this.wo.clear(), r;
				} catch (t) {
					sl.error("Failed to capture exception event. Dropping this exception.", t), this.wo.clear();
					return;
				}
			} catch (t) {
				sl.error("Failed to process exception event. Ignoring this exception.", t);
				return;
			}
		}
		Mo(t) {
			try {
				var e = this.wo.getAttachable();
				return 0 === e.length ? t : f({}, t, { $exception_steps: e });
			} catch (e) {
				return sl.error("Failed to read buffered exception steps. Capturing exception without steps.", e), t;
			}
		}
		Io(t) {
			this.bo.enabled && this.wo.add({
				[ti]: t,
				[ei]: (/* @__PURE__ */ new Date()).toISOString()
			});
		}
		ko(t) {
			return H(t) ? f({}, t) : {};
		}
		_o() {
			var t, e;
			return null !== (t = null == (e = this._instance.config.error_tracking) ? void 0 : e.exception_steps) && void 0 !== t ? t : {};
		}
		Co(t) {
			if (0 === t.length) return !1;
			var e = t.reduce(((t, e) => {
				var { type: i, value: r } = e;
				return G(i) && i.length > 0 && t.$exception_types.push(i), G(r) && r.length > 0 && t.$exception_values.push(r), t;
			}), {
				$exception_types: [],
				$exception_values: []
			});
			return this.mo.some(((t) => {
				var i = t.values.map(((t) => {
					var i, r = Vo[t.operator], s = B(t.value) ? t.value : [t.value], n = null !== (i = e[t.key]) && void 0 !== i ? i : [];
					return s.length > 0 && r(s, n);
				}));
				return "OR" === t.type ? i.some(Boolean) : i.every(Boolean);
			}));
		}
		To(t) {
			return t.flatMap(((t) => {
				var e, i;
				return null !== (e = null == (i = t.stacktrace) ? void 0 : i.frames) && void 0 !== e ? e : [];
			})).some(((t) => t.filename && t.filename.startsWith("chrome-extension://")));
		}
		Eo(t) {
			if (t.length > 0) {
				var e, i, r, s, n = null !== (e = null == (i = t[0].stacktrace) ? void 0 : i.frames) && void 0 !== e ? e : [], o = n[n.length - 1];
				return null !== (r = null == o || null == (s = o.filename) ? void 0 : s.includes("posthog.com/static")) && void 0 !== r && r;
			}
			return !1;
		}
		So(t) {
			return !K(t) && B(t);
		}
	}
}, fl = f({ productTours: class {
	get zr() {
		return this._instance.persistence;
	}
	constructor(t) {
		this.Po = null, this.Ro = null, this._instance = t;
	}
	initialize() {
		this.loadIfEnabled();
	}
	onRemoteConfig(t) {
		if ("productTours" in t) {
			var e, i;
			if (this.zr && this.zr.register({ [Si]: !!t.productTours }), !ja(this._instance)) return !this.Po && K(null == (e = this.zr) ? void 0 : e.props[Wi]) || Ua.info("product tours disabled; stopping and clearing cached tours"), null == (i = this.Po) || i.stop(), this.Po = null, void this.clearCache();
			this.loadIfEnabled();
		}
	}
	loadIfEnabled() {
		!this.Po && ja(this._instance) && this.Mt((() => this.Oo()));
	}
	Mt(t) {
		var e, i;
		null != (e = h.__PosthogExtensions__) && e.generateProductTours ? t() : null == (i = h.__PosthogExtensions__) || null == i.loadExternalDependency || i.loadExternalDependency(this._instance, "product-tours", ((e) => {
			e ? Ua.error("Could not load product tours script", e) : t();
		}));
	}
	Oo() {
		var t;
		!this.Po && null != (t = h.__PosthogExtensions__) && t.generateProductTours && (this.Po = h.__PosthogExtensions__.generateProductTours(this._instance, !0));
	}
	getProductTours(t, e) {
		if (void 0 === e && (e = !1), !B(this.Ro) || e) {
			var i = this.zr;
			if (i) {
				var r = i.props[Wi];
				if (B(r) && !e) return this.Ro = r, void t(r, { isLoaded: !0 });
			}
			this._instance._send_request({
				url: this._instance.requestRouter.endpointFor("api", "/api/product_tours/?token=" + this._instance.config.token),
				method: "GET",
				callback: (e) => {
					if (ja(this._instance)) {
						var r = e.statusCode;
						if (200 !== r || !e.json) {
							var s = "Product Tours API could not be loaded, status: " + r;
							Ua.error(s), t([], {
								isLoaded: !1,
								error: s
							});
							return;
						}
						var n = B(e.json.product_tours) ? e.json.product_tours : [];
						this.Ro = n, i && i.register({ [Wi]: n }), t(n, { isLoaded: !0 });
					} else t([], { isLoaded: !0 });
				}
			});
		} else t(this.Ro, { isLoaded: !0 });
	}
	getActiveProductTours(t) {
		K(this.Po) ? t([], {
			isLoaded: !1,
			error: "Product tours not loaded"
		}) : this.Po.getActiveProductTours(t);
	}
	showProductTour(t) {
		var e;
		null == (e = this.Po) || e.showTourById(t);
	}
	previewTour(t) {
		this.Po ? this.Po.previewTour(t) : this.Mt((() => {
			var e;
			this.Oo(), null == (e = this.Po) || e.previewTour(t);
		}));
	}
	dismissProductTour() {
		var t;
		null == (t = this.Po) || t.dismissTour("user_clicked_skip");
	}
	nextStep() {
		var t;
		null == (t = this.Po) || t.nextStep();
	}
	previousStep() {
		var t;
		null == (t = this.Po) || t.previousStep();
	}
	clearCache() {
		var t;
		this.Ro = null, null == (t = this.zr) || t.unregister(Wi);
	}
	resetTour(t) {
		var e;
		null == (e = this.Po) || e.resetTour(t);
	}
	resetAllTours() {
		var t;
		null == (t = this.Po) || t.resetAllTours();
	}
	cancelPendingTour(t) {
		var e;
		null == (e = this.Po) || e.cancelPendingTour(t);
	}
} }, dl), _l = { siteApps: class {
	constructor(t) {
		this.Lo = 0, this._instance = t, this.Fo = [], this.apps = {};
	}
	get isEnabled() {
		return !!this._instance.config.opt_in_site_apps;
	}
	Ao(t, e) {
		if (e) {
			var i = this.globalsForEvent(e);
			this.Fo.push(i), this.Fo.length > 1e3 && (this.Fo = this.Fo.slice(10));
		}
	}
	get siteAppLoaders() {
		var t;
		return null == (t = h._POSTHOG_REMOTE_CONFIG) || null == (t = t[this._instance.config.token]) ? void 0 : t.siteApps;
	}
	initialize() {
		if (this.isEnabled) {
			var t = this._instance._addCaptureHook(this.Ao.bind(this));
			this.$o = () => {
				t(), this.Fo = [], this.$o = void 0;
			};
		}
	}
	globalsForEvent(t) {
		var e, i, r, s, n, o, a;
		if (!t) throw new Error("Event payload is required");
		var l = {}, u = this._instance.get_property("$groups") || [], h = this._instance.get_property("$stored_group_properties") || {};
		for (var [d, v] of Object.entries(h)) l[d] = {
			id: u[d],
			type: d,
			properties: v
		};
		var { $set_once: c, $set: p } = t;
		return {
			event: f({}, _(t, Ba), {
				properties: f({}, t.properties, p ? { $set: f({}, null !== (e = null == (i = t.properties) ? void 0 : i.$set) && void 0 !== e ? e : {}, p) } : {}, c ? { $set_once: f({}, null !== (r = null == (s = t.properties) ? void 0 : s.$set_once) && void 0 !== r ? r : {}, c) } : {}),
				elements_chain: null !== (n = null == (o = t.properties) ? void 0 : o.$elements_chain) && void 0 !== n ? n : "",
				distinct_id: null == (a = t.properties) ? void 0 : a.distinct_id
			}),
			person: { properties: this._instance.get_property("$stored_person_properties") },
			groups: l
		};
	}
	Do(t) {
		var e, i = null == (e = t.tagName) ? void 0 : e.toLowerCase();
		return "style" === i && this._instance.config.prepare_external_dependency_stylesheet ? this._instance.config.prepare_external_dependency_stylesheet(t) || (za.error("prepare_external_dependency_stylesheet returned null"), null) : "script" === i && this._instance.config.prepare_external_dependency_script ? this._instance.config.prepare_external_dependency_script(t) || (za.error("prepare_external_dependency_script returned null"), null) : t;
	}
	No() {
		var t, e, i, s, n, o, a, l;
		if (!this._instance.config.prepare_external_dependency_stylesheet && !this._instance.config.prepare_external_dependency_script) return () => {};
		var u = null == r ? void 0 : r.defaultView, h = null == u || null == (t = u.Node) ? void 0 : t.prototype;
		if (!u || !h) return () => {};
		if (this.Lo++, this.qo) return this.Bo();
		var d = [], v = this, c = /* @__PURE__ */ new WeakSet(), p = (t, e, i) => {
			if (null != t && t[e]) {
				var r = t[e];
				t[e] = i(r), d.push((() => {
					t[e] = r;
				}));
			}
		}, f = (t) => {
			if (c.has(t)) return t;
			var e = v.Do(t);
			return e && c.add(e), e;
		}, _ = (t) => t.map(((t) => "string" == typeof t ? t : f(t))).filter(((t) => !Y(t)));
		return p(h, "appendChild", ((t) => function(e) {
			var i = f(e);
			return i ? t.call(this, i) : e;
		})), p(h, "insertBefore", ((t) => function(e, i) {
			var r = f(e);
			return r ? t.call(this, r, i) : e;
		})), p(h, "replaceChild", ((t) => function(e, i) {
			var r = f(e);
			return r ? t.call(this, r, i) : i;
		})), [
			null == (e = u.Element) ? void 0 : e.prototype,
			null == (i = u.Document) ? void 0 : i.prototype,
			null == (s = u.DocumentFragment) ? void 0 : s.prototype
		].forEach(((t) => {
			p(t, "append", ((t) => function() {
				for (var e = arguments.length, i = new Array(e), r = 0; e > r; r++) i[r] = arguments[r];
				return t.apply(this, _(i));
			})), p(t, "prepend", ((t) => function() {
				for (var e = arguments.length, i = new Array(e), r = 0; e > r; r++) i[r] = arguments[r];
				return t.apply(this, _(i));
			}));
		})), [
			null == (n = u.Element) ? void 0 : n.prototype,
			null == (o = u.CharacterData) ? void 0 : o.prototype,
			null == (a = u.DocumentType) ? void 0 : a.prototype
		].forEach(((t) => {
			p(t, "before", ((t) => function() {
				for (var e = arguments.length, i = new Array(e), r = 0; e > r; r++) i[r] = arguments[r];
				return t.apply(this, _(i));
			})), p(t, "after", ((t) => function() {
				for (var e = arguments.length, i = new Array(e), r = 0; e > r; r++) i[r] = arguments[r];
				return t.apply(this, _(i));
			})), p(t, "replaceWith", ((t) => function() {
				for (var e = arguments.length, i = new Array(e), r = 0; e > r; r++) i[r] = arguments[r];
				var s = _(i);
				return i.length && !s.length ? void 0 : t.apply(this, s);
			}));
		})), p(null == (l = u.Element) ? void 0 : l.prototype, "insertAdjacentElement", ((t) => function(e, i) {
			var r = f(i);
			return r ? t.call(this, e, r) : null;
		})), this.qo = () => {
			d.forEach(((t) => t())), this.qo = void 0;
		}, this.Bo();
	}
	Bo() {
		var t = !1;
		return () => {
			var e;
			t || (t = !0, this.Lo--, 0 === this.Lo && (null == (e = this.qo) || e.call(this)));
		};
	}
	jo(t, e) {
		void 0 === e && (e = !0);
		var i = this.No();
		try {
			var r = t(i);
			return e && i(), r;
		} catch (t) {
			throw i(), t;
		}
	}
	setupSiteApp(t) {
		var e = this.apps[t.id], i = () => {
			var i;
			!e.errored && this.Fo.length && (za.info("Processing " + this.Fo.length + " events for site app with id " + t.id), this.Fo.forEach(((t) => this.jo((() => null == e.processEvent ? void 0 : e.processEvent(t))))), e.processedBuffer = !0), Object.values(this.apps).every(((t) => t.processedBuffer || t.errored)) && (null == (i = this.$o) || i.call(this));
		}, r = !1, s = (s) => {
			e.errored = !s, e.loaded = !0, za.info("Site app with id " + t.id + " " + (s ? "loaded" : "errored")), r && i();
		};
		try {
			var { processEvent: n } = this.jo(((e) => t.init({
				posthog: this._instance,
				callback(t) {
					e(), s(t);
				}
			})), !1);
			n && (e.processEvent = n), r = !0;
		} catch (e) {
			za.error(Ha + t.id, e), s(!1);
		}
		if (r && e.loaded) try {
			i();
		} catch (i) {
			za.error("Error while processing buffered events PostHog app with config id " + t.id, i), e.errored = !0;
		}
	}
	Ho() {
		var t = this.siteAppLoaders || [];
		for (var e of t) this.apps[e.id] = {
			id: e.id,
			loaded: !1,
			errored: !1,
			processedBuffer: !1
		};
		for (var i of t) this.setupSiteApp(i);
	}
	Uo(t) {
		var e = this;
		if (0 !== Object.keys(this.apps).length) {
			var i = this.globalsForEvent(t), r = function(r) {
				try {
					e.jo((() => null == r.processEvent ? void 0 : r.processEvent(i)));
				} catch (e) {
					za.error("Error while processing event " + t.event + " for site app " + r.id, e);
				}
			};
			for (var s of Object.values(this.apps)) r(s);
		}
	}
	onRemoteConfig(t) {
		var e, i, r, s = this;
		if (null != (e = this.siteAppLoaders) && e.length) return this.isEnabled ? (this.Ho(), void this._instance.on("eventCaptured", ((t) => this.Uo(t)))) : void za.error("PostHog site apps are disabled. Enable the \"opt_in_site_apps\" config to proceed.");
		if (null == (i = this.$o) || i.call(this), null != (r = t.siteApps) && r.length) if (this.isEnabled) {
			var n = function(t) {
				var e;
				h["__$$ph_site_app_" + t] = s._instance, null == (e = h.__PosthogExtensions__) || null == e.loadSiteApp || e.loadSiteApp(s._instance, a, ((e) => {
					if (e) return za.error(Ha + t, e);
				}));
			};
			for (var { id: o, url: a } of t.siteApps) n(o);
		} else za.error("PostHog site apps are disabled. Enable the \"opt_in_site_apps\" config to proceed.");
	}
} }, gl = { tracingHeaders: class {
	constructor(t) {
		this.zo = void 0, this.Vo = void 0, this.Wo = void 0, this.ao = () => {
			var t, e, i = this.Go();
			i ? (V(this.zo) && (this.zo = null == (t = h.__PosthogExtensions__) || null == (t = t.tracingHeadersPatchFns) ? void 0 : t._patchXHR(i, (() => this._instance.get_distinct_id()), this._instance.sessionManager)), V(this.Vo) && (this.Vo = null == (e = h.__PosthogExtensions__) || null == (e = e.tracingHeadersPatchFns) ? void 0 : e._patchFetch(i, (() => this._instance.get_distinct_id()), this._instance.sessionManager))) : this.co();
		}, this._instance = t;
	}
	initialize() {
		this.startIfEnabledOrStop();
	}
	Mt(t) {
		var e, i;
		null != (e = h.__PosthogExtensions__) && e.tracingHeadersPatchFns ? t() : null == (i = h.__PosthogExtensions__) || null == i.loadExternalDependency || i.loadExternalDependency(this._instance, "tracing-headers", ((e) => {
			if (e) return Ra.error("failed to load script", e);
			t();
		}));
	}
	Zo() {
		var t, e;
		return null !== (t = null !== (e = this._instance.config.tracing_headers) && void 0 !== e ? e : this._instance.config.addTracingHeaders) && void 0 !== t ? t : this._instance.config.__add_tracing_headers;
	}
	Go() {
		var t = this.Zo();
		return B(t) ? (B(this.Wo) ? this.Wo.splice(0, this.Wo.length, ...t) : this.Wo = [...t], t.length > 0 ? this.Wo : void 0) : (B(this.Wo) && this.Wo.splice(0), this.Wo = t || void 0, this.Wo);
	}
	co() {
		var t, e;
		null == (t = this.zo) || t.call(this), null == (e = this.Vo) || e.call(this), this.zo = void 0, this.Vo = void 0;
	}
	startIfEnabledOrStop() {
		this.Go() ? this.Mt(this.ao) : this.co();
	}
} }, ml = f({ surveys: class {
	get Se() {
		return this._instance.config;
	}
	constructor(t) {
		this.Qo = void 0, this._surveyManager = null, this.Jo = !1, this.Yo = [], this.Ko = null, this.Xo = null, this._instance = t, this._surveyEventReceiver = null;
	}
	initialize() {
		this.loadIfEnabled();
	}
	onRemoteConfig(t) {
		if (!this.Se.disable_surveys) {
			var e = t.surveys;
			if (K(e)) return Xo.warn("Flags not loaded yet. Not loading surveys.");
			var i = B(e);
			this.Qo = i ? e.length > 0 : e, Xo.info("flags response received, isSurveysEnabled: " + this.Qo), this.loadIfEnabled();
		}
	}
	reset() {
		try {
			var t;
			null == (t = this._surveyEventReceiver) || t.reset(), localStorage.removeItem("lastSeenSurveyDate");
			for (var e = [], i = 0; i < localStorage.length; i++) {
				var r = localStorage.key(i);
				(null != r && r.startsWith(Zo) || null != r && r.startsWith("inProgressSurvey_")) && e.push(r);
			}
			e.forEach(((t) => localStorage.removeItem(t)));
		} catch (t) {}
	}
	loadIfEnabled() {
		if (!this._surveyManager) if (this.Jo) Xo.info("Already initializing surveys, skipping...");
		else if (this.Se.disable_surveys) Xo.info(Ka);
		else if (this.Se.cookieless_mode && this._instance.consent.isOptedOut()) Xo.info("Not loading surveys in cookieless mode without consent.");
		else {
			var t = null == h ? void 0 : h.__PosthogExtensions__;
			if (t) {
				if (!V(this.Qo) || this.Se.advanced_enable_surveys) {
					var e = this.Qo || this.Se.advanced_enable_surveys;
					this.Jo = !0;
					try {
						var i = t.generateSurveys;
						if (i) return void this.ea(i, e);
						var r = t.loadExternalDependency;
						if (!r) return void this.ta(hr);
						r(this._instance, "surveys", ((i) => {
							i || !t.generateSurveys ? this.ta("Could not load surveys script", i) : this.ea(t.generateSurveys, e);
						}));
					} catch (t) {
						throw this.ta("Error initializing surveys", t), t;
					} finally {
						this.Jo = !1;
					}
				}
			} else Xo.error("PostHog Extensions not found.");
		}
	}
	ea(t, e) {
		this._surveyManager = t(this._instance, e), this._surveyEventReceiver = new Wa(this._instance), Xo.info("Surveys loaded successfully"), this.ra({ isLoaded: !0 });
	}
	ta(t, e) {
		Xo.error(t, e), this.ra({
			isLoaded: !1,
			error: t
		});
	}
	onSurveysLoaded(t) {
		return this.Yo.push(t), this._surveyManager && this.ra({ isLoaded: !0 }), () => {
			this.Yo = this.Yo.filter(((e) => e !== t));
		};
	}
	getSurveys(t, e) {
		if (void 0 === e && (e = !1), this.Se.disable_surveys) return Xo.info(Ka), t([]);
		var i, r = this._instance.get_property(qi);
		if (r && !e) return t(r, { isLoaded: !0 }), void (this.ia() && this.getSurveys((() => {}), !0));
		"undefined" != typeof Promise && this.Ko ? this.Ko.then(((e) => {
			var { surveys: i, context: r } = e;
			return t(i, r);
		})) : ("undefined" != typeof Promise && (this.Ko = new Promise(((t) => {
			i = t;
		}))), this._instance._send_request({
			url: this._instance.requestRouter.endpointFor("api", "/api/surveys/?token=" + this.Se.token),
			method: "GET",
			timeout: this.Se.surveys_request_timeout_ms,
			callback: (e) => {
				var r;
				this.Ko = null;
				var s = e.statusCode;
				if (200 !== s || !e.json) {
					var n = "Surveys API could not be loaded, status: " + s;
					Xo.error(n), this.Xo = Date.now();
					var o = {
						isLoaded: !1,
						error: n
					};
					t([], o), i?.({
						surveys: [],
						context: o
					});
					return;
				}
				this.Xo = null;
				var a, l = e.json.surveys || [], u = l.filter(((t) => function(t) {
					return !(!t.start_date || t.end_date);
				}(t) && (function(t) {
					var e;
					return !(null == (e = t.conditions) || null == (e = e.events) || null == (e = e.values) || !e.length);
				}(t) || function(t) {
					var e;
					return !(null == (e = t.conditions) || null == (e = e.actions) || null == (e = e.values) || !e.length);
				}(t))));
				u.length > 0 && (null == (a = this._surveyEventReceiver) || a.register(u)), null == (r = this._instance.persistence) || r.register({
					[qi]: l,
					[Vi]: Date.now()
				});
				var h = { isLoaded: !0 };
				t(l, h), i?.({
					surveys: l,
					context: h
				});
			}
		}));
	}
	ia() {
		return this.na() && !this.Ko && !this.sa();
	}
	na() {
		var t = this._instance.get_property(Vi);
		return J(t) && Date.now() - t > 3e5;
	}
	sa() {
		return J(this.Xo) && 3e5 > Date.now() - this.Xo;
	}
	markSurveyAsSeen(t, e) {
		var i;
		ta({
			id: t,
			current_iteration: null !== (i = null == e ? void 0 : e.iteration) && void 0 !== i ? i : null
		});
		try {
			localStorage.setItem("lastSeenSurveyDate", (/* @__PURE__ */ new Date()).toISOString());
		} catch (t) {}
	}
	ra(t) {
		for (var e of this.Yo) try {
			if (!t.isLoaded) return e([], t);
			this.getSurveys(e);
		} catch (t) {
			Xo.error("Error in survey callback", t);
		}
	}
	getActiveMatchingSurveys(t, e) {
		if (void 0 === e && (e = !1), !K(this._surveyManager)) return this._surveyManager.getActiveMatchingSurveys(t, e);
		Xo.warn("init was not called");
	}
	oa(t) {
		var e = null;
		return this.getSurveys(((i) => {
			var r;
			e = null !== (r = i.find(((e) => e.id === t))) && void 0 !== r ? r : null;
		})), e;
	}
	aa(t) {
		if (K(this._surveyManager)) return {
			eligible: !1,
			reason: Ya
		};
		var e = "string" == typeof t ? this.oa(t) : t;
		return e ? this._surveyManager.checkSurveyEligibility(e) : {
			eligible: !1,
			reason: "Survey not found"
		};
	}
	canRenderSurvey(t) {
		if (K(this._surveyManager)) return Xo.warn("init was not called"), {
			visible: !1,
			disabledReason: Ya
		};
		var e = this.aa(t);
		return {
			visible: e.eligible,
			disabledReason: e.reason
		};
	}
	canRenderSurveyAsync(t, e) {
		return K(this._surveyManager) ? (Xo.warn("init was not called"), Promise.resolve({
			visible: !1,
			disabledReason: Ya
		})) : new Promise(((i) => {
			this.getSurveys(((e) => {
				var r, s = null !== (r = e.find(((e) => e.id === t))) && void 0 !== r ? r : null;
				if (s) {
					var n = this.aa(s);
					i({
						visible: n.eligible,
						disabledReason: n.reason
					});
				} else i({
					visible: !1,
					disabledReason: "Survey not found"
				});
			}), e);
		}));
	}
	renderSurvey(t, e, i) {
		var s;
		if (K(this._surveyManager)) Xo.warn("init was not called");
		else {
			var n = "string" == typeof t ? this.oa(t) : t;
			if (null != n && n.id) if (ea.includes(n.type)) {
				var o = null == r ? void 0 : r.querySelector(e);
				if (o) return null != (s = n.appearance) && s.surveyPopupDelaySeconds ? (Xo.info("Rendering survey " + n.id + " with delay of " + n.appearance.surveyPopupDelaySeconds + " seconds"), void setTimeout((() => {
					var t, e;
					Xo.info("Rendering survey " + n.id + " with delay of " + (null == (t = n.appearance) ? void 0 : t.surveyPopupDelaySeconds) + " seconds"), null == (e = this._surveyManager) || e.renderSurvey(n, o, i), Xo.info("Survey " + n.id + " rendered");
				}), 1e3 * n.appearance.surveyPopupDelaySeconds)) : void this._surveyManager.renderSurvey(n, o, i);
				Xo.warn("Survey element not found");
			} else Xo.warn("Surveys of type " + n.type + " cannot be rendered in the app");
			else Xo.warn("Survey not found");
		}
	}
	displaySurvey(t, e) {
		var i;
		if (K(this._surveyManager)) Xo.warn("init was not called");
		else {
			var r = this.oa(t);
			if (r) {
				var s = r;
				if (null != (i = r.appearance) && i.surveyPopupDelaySeconds && e.ignoreDelay && (s = f({}, r, { appearance: f({}, r.appearance, { surveyPopupDelaySeconds: 0 }) })), e.displayType !== In.Popover && e.initialResponses && Xo.warn("initialResponses is only supported for popover surveys. prefill will not be applied."), !1 === e.ignoreConditions) {
					var n = this.canRenderSurvey(r);
					if (!n.visible) return void Xo.warn("Survey is not eligible to be displayed: ", n.disabledReason);
				}
				e.displayType !== In.Inline ? this._surveyManager.handlePopoverSurvey(s, e) : this.renderSurvey(s, e.selector, e.properties);
			} else Xo.warn("Survey not found");
		}
	}
	cancelPendingSurvey(t) {
		K(this._surveyManager) ? Xo.warn("init was not called") : this._surveyManager.cancelSurvey(t);
	}
	handlePageUnload() {
		var t;
		null == (t = this._surveyManager) || t.handlePageUnload();
	}
} }, dl), yl = { toolbar: class {
	constructor(t) {
		this.instance = t;
	}
	la(t) {
		h.ph_toolbar_state = t;
	}
	ua() {
		var t;
		return null !== (t = h.ph_toolbar_state) && void 0 !== t ? t : 0;
	}
	initialize() {
		return this.maybeLoadToolbar();
	}
	maybeLoadToolbar(e, i, s) {
		if (void 0 === e && (e = void 0), void 0 === i && (i = void 0), void 0 === s && (s = void 0), Cr(this.instance.config)) return !1;
		if (!t || !r) return !1;
		e = null != e ? e : t.location, s = null != s ? s : t.history;
		try {
			if (!i) {
				try {
					t.localStorage.setItem("test", "test"), t.localStorage.removeItem("test");
				} catch (t) {
					return !1;
				}
				i = null == t ? void 0 : t.localStorage;
			}
			var n, o = Ja || Zs(e.hash, "__posthog") || Zs(e.hash, "state"), a = o ? $r((() => JSON.parse(atob(decodeURIComponent(o))))) || $r((() => JSON.parse(decodeURIComponent(o)))) : null;
			return a && "ph_authorize" === a.action ? ((n = a).source = "url", n && Object.keys(n).length > 0 && (a.desiredHash ? e.hash = a.desiredHash : s ? s.replaceState(s.state, "", e.pathname + e.search) : e.hash = "")) : ((n = JSON.parse(i.getItem(Qa) || "{}")).source = "localstorage", delete n.userIntent), !(!n.token || this.instance.config.token !== n.token || (this.loadToolbar(n), 0));
		} catch (t) {
			return !1;
		}
	}
	ha(t) {
		var e = h.ph_load_toolbar || h.ph_load_editor;
		!K(e) && z(e) ? e(t, this.instance) : Xa.warn("No toolbar load function found");
	}
	loadToolbar(e) {
		var i = !(null == r || !r.getElementById(nr));
		if (!t || i) return !1;
		var s = "custom" === this.instance.requestRouter.region && this.instance.config.advanced_disable_toolbar_metrics, n = f({ token: this.instance.config.token }, e, { apiURL: this.instance.requestRouter.endpointFor("ui") }, s ? { instrument: !1 } : {});
		if (t.localStorage.setItem(Qa, JSON.stringify(f({}, n, { source: void 0 }))), 2 === this.ua()) this.ha(n);
		else if (0 === this.ua()) {
			var o;
			this.la(1), null == (o = h.__PosthogExtensions__) || null == o.loadExternalDependency || o.loadExternalDependency(this.instance, "toolbar", ((t) => {
				if (t) return Xa.error("[Toolbar] Failed to load", t), void this.la(0);
				this.la(2), this.ha(n);
			})), Or(t, "turbolinks:load", (() => {
				this.la(0), this.loadToolbar(n);
			}));
		}
		return !0;
	}
	da(t) {
		return this.loadToolbar(t);
	}
	maybeLoadEditor(t, e, i) {
		return void 0 === t && (t = void 0), void 0 === e && (e = void 0), void 0 === i && (i = void 0), this.maybeLoadToolbar(t, e, i);
	}
} }, bl = f({ experiments: al }, dl), wl = f({}, dl, vl, cl, pl, fl, _l, ml, gl, yl, bl, { conversations: class {
	constructor(t) {
		this.ca = void 0, this._conversationsManager = null, this.va = !1, this.fa = null, this._instance = t;
	}
	initialize() {
		this.loadIfEnabled();
	}
	onRemoteConfig(t) {
		if (!this._instance.config.disable_conversations) {
			var e = t.conversations;
			K(e) || (X(e) ? this.ca = e : (this.ca = e.enabled, this.fa = e), this.loadIfEnabled());
		}
	}
	reset() {
		var t;
		null == (t = this._conversationsManager) || t.reset(), this._conversationsManager = null, this.ca = void 0, this.fa = null;
	}
	loadIfEnabled() {
		if (!(this._conversationsManager || this.va || this._instance.config.disable_conversations || Cr(this._instance.config) || this._instance.config.cookieless_mode && this._instance.consent.isOptedOut())) {
			var t = null == h ? void 0 : h.__PosthogExtensions__;
			if (t && !V(this.ca) && this.ca) if (this.fa && this.fa.token) {
				this.va = !0;
				try {
					var e = t.initConversations;
					if (e) return this.pa(e), void (this.va = !1);
					var i = t.loadExternalDependency;
					if (!i) return void this.ga(hr);
					i(this._instance, "conversations", ((e) => {
						e || !t.initConversations ? this.ga("Could not load conversations script", e) : this.pa(t.initConversations), this.va = !1;
					}));
				} catch (t) {
					this.ga("Error initializing conversations", t), this.va = !1;
				}
			} else ll.error("Conversations enabled but missing token in remote config.");
		}
	}
	pa(t) {
		if (this.fa) try {
			this._conversationsManager = t(this.fa, this._instance), ll.info("Conversations loaded successfully");
		} catch (t) {
			this.ga("Error completing conversations initialization", t);
		}
		else ll.error("Cannot complete initialization: remote config is null");
	}
	ga(t, e) {
		ll.error(t, e), this._conversationsManager = null, this.va = !1;
	}
	show() {
		this._conversationsManager ? this._conversationsManager.show() : ll.warn("Conversations not loaded yet.");
	}
	hide() {
		this._conversationsManager && this._conversationsManager.hide();
	}
	isAvailable() {
		return !0 === this.ca && !Y(this._conversationsManager);
	}
	isVisible() {
		var t, e;
		return null !== (t = null == (e = this._conversationsManager) ? void 0 : e.isVisible()) && void 0 !== t && t;
	}
	sendMessage(t, e, i) {
		var r = this;
		return p((function* () {
			return r._conversationsManager ? r._conversationsManager.sendMessage(t, e, i) : (ll.warn(ul), null);
		}))();
	}
	getMessages(t, e) {
		var i = this;
		return p((function* () {
			return i._conversationsManager ? i._conversationsManager.getMessages(t, e) : (ll.warn(ul), null);
		}))();
	}
	markAsRead(t) {
		var e = this;
		return p((function* () {
			return e._conversationsManager ? e._conversationsManager.markAsRead(t) : (ll.warn(ul), null);
		}))();
	}
	getTickets(t) {
		var e = this;
		return p((function* () {
			return e._conversationsManager ? e._conversationsManager.getTickets(t) : (ll.warn(ul), null);
		}))();
	}
	requestRestoreLink(t) {
		var e = this;
		return p((function* () {
			return e._conversationsManager ? e._conversationsManager.requestRestoreLink(t) : (ll.warn(ul), null);
		}))();
	}
	restoreFromToken(t) {
		var e = this;
		return p((function* () {
			return e._conversationsManager ? e._conversationsManager.restoreFromToken(t) : (ll.warn(ul), null);
		}))();
	}
	restoreFromUrlToken() {
		var t = this;
		return p((function* () {
			return t._conversationsManager ? t._conversationsManager.restoreFromUrlToken() : (ll.warn(ul), null);
		}))();
	}
	getCurrentTicketId() {
		var t, e;
		return null !== (t = null == (e = this._conversationsManager) ? void 0 : e.getCurrentTicketId()) && void 0 !== t ? t : null;
	}
	getWidgetSessionId() {
		var t, e;
		return null !== (t = null == (e = this._conversationsManager) ? void 0 : e.getWidgetSessionId()) && void 0 !== t ? t : null;
	}
	en() {
		var t;
		null == (t = this._conversationsManager) || t.setIdentity();
	}
	tn() {
		var t;
		null == (t = this._conversationsManager) || t.clearIdentity();
	}
} }, { logs: class {
	constructor(e) {
		var i;
		this.ma = !1, this.ya = !1, this.Ae = ui("[logs]"), this._r = [], this.ba = [], this._a = () => {
			var t, e;
			null == (t = this.wa) || t.onReconnect(), null == (e = this.xa) || e.onReconnect();
		}, this._instance = e, this._instance && null != (i = this._instance.config.logs) && i.captureConsoleLogs && (this.ma = !0), t && Or(t, "online", this._a);
	}
	ka(t, e, i, r) {
		var s, n = function(t, e) {
			var i, r, s, n, o, a, l, u = null !== (i = null == t ? void 0 : t.flushIntervalMs) && void 0 !== i ? i : 3e3, h = null !== (r = null == t ? void 0 : t.maxBufferSize) && void 0 !== r ? r : 100, d = null != e && e.consoleCapture ? void 0 : null !== (s = null == t ? void 0 : t.maxLogsPerInterval) && void 0 !== s ? s : 1e3, v = V(d) ? Math.max(h, 2048) : Math.max(h, d), c = null == t ? void 0 : t.resourceAttributes;
			return {
				serviceName: null !== (n = null !== (o = null == c ? void 0 : c["service.name"]) && void 0 !== o ? o : null == t ? void 0 : t.serviceName) && void 0 !== n ? n : null == e ? void 0 : e.serviceNameDefault,
				serviceVersion: null !== (a = null == c ? void 0 : c["service.version"]) && void 0 !== a ? a : null == t ? void 0 : t.serviceVersion,
				environment: null !== (l = null == c ? void 0 : c["deployment.environment"]) && void 0 !== l ? l : null == t ? void 0 : t.environment,
				resourceAttributes: c,
				beforeSend: null == t ? void 0 : t.beforeSend,
				flushIntervalMs: u,
				maxBufferSize: h,
				maxQueueSize: v,
				maxBatchRecordsPerPost: 100,
				rateCapWindowMs: u,
				maxLogsPerInterval: d,
				backgroundFlushBudgetMs: 0,
				terminationFlushBudgetMs: 0
			};
		}(null == (s = this._instance) || null == (s = s.config) ? void 0 : s.logs, i);
		return [new $e(this.Sa(t, e), n, this.Ae, (() => this.Ca()), ((t) => t()), void 0, r), n];
	}
	Ia() {
		var t, e, i = null == (t = this._instance) || null == (t = t.config) ? void 0 : t.logs;
		return this.wa && this.Ta === i || (null == (e = this.wa) || e.reset(), this.Ta = i, [this.wa, this.Ea] = this.ka((() => this._r), ((t) => {
			this._r = t;
		}))), this.wa;
	}
	Ma() {
		var t, e, i = null == (t = this._instance) || null == (t = t.config) ? void 0 : t.logs;
		return this.xa && this.Pa === i || (null == (e = this.xa) || e.reset(), this.Pa = i, [this.xa, this.Ra] = this.ka((() => this.ba), ((t) => {
			this.ba = t;
		}), {
			serviceNameDefault: "posthog-browser-logs",
			consoleCapture: !0
		}, hl)), this.xa;
	}
	initialize() {
		this.loadIfEnabled();
	}
	onRemoteConfig(t) {
		var e, i = null == (e = t.logs) ? void 0 : e.captureConsoleLogs;
		!K(i) && i && (this.ma = !0, this.loadIfEnabled());
	}
	reset() {
		var t, e;
		this._r = [], null == (t = this.wa) || t.reset(), this.ba = [], null == (e = this.xa) || e.reset();
	}
	captureLog(t) {
		this.Ia().captureLog(t);
	}
	le(t) {
		this.Ma().captureLog(t);
	}
	get logger() {
		return this.Oa || (this.Oa = {
			trace: (t, e) => this.captureLog({
				body: t,
				level: "trace",
				attributes: e
			}),
			debug: (t, e) => this.captureLog({
				body: t,
				level: "debug",
				attributes: e
			}),
			info: (t, e) => this.captureLog({
				body: t,
				level: "info",
				attributes: e
			}),
			warn: (t, e) => this.captureLog({
				body: t,
				level: "warn",
				attributes: e
			}),
			error: (t, e) => this.captureLog({
				body: t,
				level: "error",
				attributes: e
			}),
			fatal: (t, e) => this.captureLog({
				body: t,
				level: "fatal",
				attributes: e
			})
		}), this.Oa;
	}
	flushLogs(t) {
		t ? this.La(t) : (this.wa && this.wa.flush().catch(((t) => this.Ae.error("PostHog logs flush failed:", t))), this.xa && this.xa.flush().catch(((t) => this.Ae.error("PostHog logs flush failed:", t))));
	}
	loadIfEnabled() {
		if (this.ma && !this.ya) {
			var t = null == h ? void 0 : h.__PosthogExtensions__;
			if (t) {
				var e = t.loadExternalDependency;
				e ? e(this._instance, "logs", ((e) => {
					var i;
					e || null == (i = t.logs) || !i.initializeLogs ? this.Ae.error("Could not load logs script", e) : (t.logs.initializeLogs(this._instance), this.ya = !0);
				})) : this.Ae.error(hr);
			} else this.Ae.error("PostHog Extensions not found.");
		}
	}
	Sa(t, e) {
		var i = this._instance;
		return {
			get isDisabled() {
				return !1;
			},
			get optedOut() {
				return !i.is_capturing();
			},
			getPersistedProperty: (e) => e === w.LogsQueue ? t() : void 0,
			setPersistedProperty(t, i) {
				var r;
				t === w.LogsQueue && e(null !== (r = i) && void 0 !== r ? r : []);
			},
			ht: (t) => this.ht(t),
			getLibraryId: () => v.LIB_NAME,
			getLibraryVersion: () => v.LIB_VERSION
		};
	}
	ht(t) {
		return new Promise(((e) => {
			var i = !1, r = (t) => {
				i || (i = !0, clearTimeout(s), e(t));
			}, s = setTimeout((() => r({
				kind: "retry-later",
				error: /* @__PURE__ */ new Error("logs request timed out")
			})), 9e4);
			this._instance._send_request({
				method: "POST",
				url: this.Fa(),
				data: t,
				compression: "best-available",
				batchKey: "logs",
				fireCallbackOnDrop: !0,
				callback(t) {
					var e = t.statusCode;
					if (e >= 200 && 300 > e) r({ kind: "ok" });
					else if (413 === e) r({ kind: "too-large" });
					else if (0 !== e && 429 !== e && 500 > e) r({
						kind: "fatal",
						error: /* @__PURE__ */ new Error("logs request failed with status " + e)
					});
					else {
						var i;
						r({
							kind: "retry-later",
							error: null !== (i = t.error) && void 0 !== i ? i : /* @__PURE__ */ new Error("logs request failed with status " + e)
						});
					}
				}
			});
		}));
	}
	La(t) {
		this._r.length > 0 && this.Aa(t, this._r, this.Ea, v.LIB_NAME, ((t) => {
			this._r = t;
		})), this.ba.length > 0 && this.Aa(t, this.ba, this.Ra, hl, ((t) => {
			this.ba = t;
		}));
	}
	Aa(t, e, i, r, s) {
		if (0 !== e.length) {
			var n = e.map(((t) => t.record));
			s([]);
			var o = Te(n, Se(i, v.LIB_NAME, v.LIB_VERSION), r, v.LIB_VERSION);
			this._instance._send_request({
				method: "POST",
				url: this.Fa(),
				data: o,
				compression: "best-available",
				batchKey: "logs",
				transport: t
			});
		}
	}
	Fa() {
		return this._instance.requestRouter.endpointFor("api", "/i/v1/logs") + "?token=" + encodeURIComponent(this._instance.config.token);
	}
	Ca() {
		var t, e = {};
		if (e.distinctId = this._instance.get_distinct_id(), this._instance.sessionManager) {
			var { sessionId: i, windowId: r, sessionStartTimestamp: s, lastActivityTimestamp: n } = this._instance.sessionManager.checkAndGetSessionAndWindowId(!0);
			e.sessionId = i, e.windowId = r, K(s) || (e.sessionStartTimestamp = s), K(n) || (e.lastActivityTimestamp = n);
		}
		if (null != h && null != (t = h.location) && t.href && (e.currentUrl = this._instance.config.disable_capture_url_hashes ? _e(h.location.href) : h.location.href), this._instance.featureFlags) {
			var o = this._instance.featureFlags.getFlags();
			o && o.length > 0 && (e.activeFeatureFlags = o);
		}
		return e;
	}
} });
ba.__defaultExtensionClasses = f({}, wl);
var El = function() {
	v.SDK_DIST_CHANNEL = "npm";
	var e = aa[pa] = new ba();
	return function() {
		function e() {
			e.done || (e.done = !0, fa = !1, xr(aa, (function(t) {
				t._dom_loaded();
			})));
		}
		null != r && r.addEventListener ? "complete" === r.readyState ? e() : Or(r, "DOMContentLoaded", e, { capture: !1 }) : t && li.error("Browser doesn't support `document.addEventListener` so PostHog couldn't be initialized");
	}(), e;
}();
//#endregion
//#region node_modules/posthog-js/react/dist/esm/index.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var defaultPostHogInstance;
function setDefaultPostHogInstance(instance) {
	defaultPostHogInstance = instance;
}
function getDefaultPostHogInstance() {
	return defaultPostHogInstance;
}
var PostHogContext = (0, import_react.createContext)({
	get client() {
		return getDefaultPostHogInstance();
	},
	bootstrap: void 0
});
function isDeepEqual(obj1, obj2, visited) {
	if (visited === void 0) visited = /* @__PURE__ */ new WeakMap();
	if (obj1 === obj2) return true;
	if (typeof obj1 !== "object" || obj1 === null || typeof obj2 !== "object" || obj2 === null) return false;
	if (visited.has(obj1) && visited.get(obj1) === obj2) return true;
	visited.set(obj1, obj2);
	var keys1 = Object.keys(obj1);
	var keys2 = Object.keys(obj2);
	if (keys1.length !== keys2.length) return false;
	for (var _i = 0, keys1_1 = keys1; _i < keys1_1.length; _i++) {
		var key = keys1_1[_i];
		if (!keys2.includes(key)) return false;
		if (!isDeepEqual(obj1[key], obj2[key], visited)) return false;
	}
	return true;
}
function PostHogProvider(_a) {
	var _b, _c;
	var children = _a.children, client = _a.client, apiKey = _a.apiKey, options = _a.options;
	var previousInitializationRef = (0, import_react.useRef)(null);
	var posthog = (0, import_react.useMemo)(function() {
		if (client) {
			if (apiKey) console.warn("[PostHog.js] You have provided both `client` and `apiKey` to `PostHogProvider`. `apiKey` will be ignored in favour of `client`.");
			if (options) console.warn("[PostHog.js] You have provided both `client` and `options` to `PostHogProvider`. `options` will be ignored in favour of `client`.");
			return client;
		}
		var defaultInstance = getDefaultPostHogInstance();
		if (apiKey) return defaultInstance;
		console.warn("[PostHog.js] No `apiKey` or `client` were provided to `PostHogProvider`. Using default global `window.posthog` instance. You must initialize it manually. This is not recommended behavior.");
		return defaultInstance;
	}, [
		client,
		apiKey,
		JSON.stringify(options)
	]);
	(0, import_react.useEffect)(function() {
		if (client || !apiKey) return;
		var defaultInstance = getDefaultPostHogInstance();
		var previousInitialization = previousInitializationRef.current;
		if (!previousInitialization) {
			if (defaultInstance.__loaded) console.warn("[PostHog.js] `posthog` was already loaded elsewhere. This may cause issues.");
			defaultInstance.init(apiKey, options);
			previousInitializationRef.current = {
				apiKey,
				options: options !== null && options !== void 0 ? options : {}
			};
		} else {
			if (apiKey !== previousInitialization.apiKey) console.warn("[PostHog.js] You have provided a different `apiKey` to `PostHogProvider` than the one that was already initialized. This is not supported by our provider and we'll keep using the previous key. If you need to toggle between API Keys you need to control the `client` yourself and pass it in as a prop rather than an `apiKey` prop.");
			if (options && !isDeepEqual(options, previousInitialization.options)) defaultInstance.set_config(options);
			previousInitializationRef.current = {
				apiKey,
				options: options !== null && options !== void 0 ? options : {}
			};
		}
	}, [
		client,
		apiKey,
		JSON.stringify(options)
	]);
	return import_react.createElement(PostHogContext.Provider, { value: {
		client: posthog,
		bootstrap: (_b = options === null || options === void 0 ? void 0 : options.bootstrap) !== null && _b !== void 0 ? _b : (_c = client === null || client === void 0 ? void 0 : client.config) === null || _c === void 0 ? void 0 : _c.bootstrap
	} }, children);
}
var isFunction = function(f) {
	return typeof f === "function";
};
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
var extendStatics = function(d, b) {
	extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
		d.__proto__ = b;
	} || function(d, b) {
		for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
	};
	return extendStatics(d, b);
};
function __extends(d, b) {
	if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
	extendStatics(d, b);
	function __() {
		this.constructor = d;
	}
	d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var INITIAL_STATE = {
	componentStack: null,
	exceptionEvent: null,
	error: null
};
var __POSTHOG_ERROR_MESSAGES = { INVALID_FALLBACK: "[PostHog.js][PostHogErrorBoundary] Invalid fallback prop, provide a valid React element or a function that returns a valid React element." };
(function(_super) {
	__extends(PostHogErrorBoundary, _super);
	function PostHogErrorBoundary(props) {
		var _this = _super.call(this, props) || this;
		_this.state = INITIAL_STATE;
		return _this;
	}
	PostHogErrorBoundary.prototype.componentDidCatch = function(error, errorInfo) {
		var additionalProperties = this.props.additionalProperties;
		var currentProperties;
		if (isFunction(additionalProperties)) currentProperties = additionalProperties(error);
		else if (typeof additionalProperties === "object") currentProperties = additionalProperties;
		var exceptionEvent = this.context.client.captureException(error, currentProperties);
		var componentStack = errorInfo.componentStack;
		this.setState({
			error,
			componentStack: componentStack !== null && componentStack !== void 0 ? componentStack : null,
			exceptionEvent
		});
	};
	PostHogErrorBoundary.prototype.render = function() {
		var _a = this.props, children = _a.children, fallback = _a.fallback;
		var state = this.state;
		if (state.componentStack == null) return isFunction(children) ? children() : children;
		var element = isFunction(fallback) ? import_react.createElement(fallback, {
			error: state.error,
			componentStack: state.componentStack,
			exceptionEvent: state.exceptionEvent
		}) : fallback;
		if (import_react.isValidElement(element)) return element;
		console.warn(__POSTHOG_ERROR_MESSAGES.INVALID_FALLBACK);
		return import_react.createElement(import_react.Fragment, null);
	};
	PostHogErrorBoundary.contextType = PostHogContext;
	return PostHogErrorBoundary;
})(import_react.Component);
setDefaultPostHogInstance(El);
//#endregion
export { El as n, PostHogProvider as t };
