//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Uhuv7dNs.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Users/st_umar/Documents/pmtriangle/src/routes/__root.tsx",
		children: [
			"/",
			"/simulate",
			"/sitemap.xml"
		],
		preloads: ["/assets/index-BH7Vf8Bk.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BH7Vf8Bk.js"
		} }]
	},
	"/": {
		filePath: "/Users/st_umar/Documents/pmtriangle/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DLXX1ggm.js", "/assets/theme-toggle-Do90_W8U.js"]
	},
	"/simulate": {
		filePath: "/Users/st_umar/Documents/pmtriangle/src/routes/simulate.tsx",
		children: void 0,
		preloads: ["/assets/simulate-D78DPenQ.js", "/assets/theme-toggle-Do90_W8U.js"]
	}
} });
//#endregion
export { tsrStartManifest };
