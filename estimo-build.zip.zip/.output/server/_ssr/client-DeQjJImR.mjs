import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as El } from "../_libs/posthog-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/client-DeQjJImR.js
var import_jsx_runtime = require_jsx_runtime();
/** Konstanta brand ESTIMO — aset resmi produksi. */
var BRAND_NAME = "ESTIMO";
/** Warna aksen brand (selaras dengan share-card-theme.text.accent). */
var BRAND_THEME_COLOR = "#2d8a6a";
var LOGO_WORDMARK_SVG = "/estimo-logo.svg";
var LOGO_WORDMARK_PNG = "/estimo-logo.png";
/** Rasio viewBox wordmark SVG (1080 × 300). */
var LOGO_WORDMARK_ASPECT = 1080 / 300;
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
/** Logo resmi ESTIMO — SVG vektor dengan fallback PNG, skala proporsional. */
function EstimoLogo({ className, height = 28 }) {
	const width = Math.round(height * LOGO_WORDMARK_ASPECT);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("picture", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", {
		srcSet: LOGO_WORDMARK_SVG,
		type: "image/svg+xml"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: LOGO_WORDMARK_PNG,
		alt: BRAND_NAME,
		width,
		height,
		className: cn("h-auto max-w-full object-contain object-left dark:brightness-0 dark:invert", className),
		decoding: "async",
		draggable: false
	})] });
}
/** Versi aplikasi — disertakan di setiap event analytics. */
var APP_VERSION = "1.0.0-beta";
var ACQUISITION_STORAGE_KEY = "estimo_acquisition_v1";
function sanitizeParam(value, maxLength = 100) {
	if (!value?.trim()) return void 0;
	return value.trim().slice(0, maxLength);
}
function getReferrerHost() {
	if (typeof document === "undefined" || !document.referrer) return void 0;
	try {
		return new URL(document.referrer).hostname.slice(0, 100);
	} catch {
		return;
	}
}
/** Tangkap UTM & referrer sekali per tab — tanpa data pribadi. */
function getAcquisitionContext() {
	if (typeof window === "undefined") return {};
	const stored = sessionStorage.getItem(ACQUISITION_STORAGE_KEY);
	if (stored) try {
		return JSON.parse(stored);
	} catch {
		sessionStorage.removeItem(ACQUISITION_STORAGE_KEY);
	}
	const params = new URLSearchParams(window.location.search);
	const context = {};
	const utm_source = sanitizeParam(params.get("utm_source"));
	const utm_medium = sanitizeParam(params.get("utm_medium"));
	const utm_campaign = sanitizeParam(params.get("utm_campaign"));
	const referrer = getReferrerHost();
	if (utm_source) context.utm_source = utm_source;
	if (utm_medium) context.utm_medium = utm_medium;
	if (utm_campaign) context.utm_campaign = utm_campaign;
	if (referrer) context.referrer = referrer;
	sessionStorage.setItem(ACQUISITION_STORAGE_KEY, JSON.stringify(context));
	return context;
}
function getBaseEventProperties() {
	return {
		app_version: APP_VERSION,
		...getAcquisitionContext()
	};
}
var initialized = false;
function getPostHogClient() {
	if (typeof window === "undefined") return null;
	return El;
}
function initAnalyticsClient() {
	if (typeof window === "undefined" || initialized) return getPostHogClient();
	El.init("phc_xxxxxxxxx", {
		api_host: "https://us.i.posthog.com",
		capture_pageview: false,
		capture_pageleave: true,
		autocapture: false,
		persistence: "localStorage",
		disable_session_recording: false,
		session_recording: {
			maskAllInputs: true,
			maskTextSelector: "input, textarea, [contenteditable='true']"
		},
		capture_exceptions: true
	});
	El.register(getBaseEventProperties());
	const acquisition = getAcquisitionContext();
	if (Object.keys(acquisition).length > 0) El.register_once(acquisition);
	setupGlobalErrorTracking();
	initialized = true;
	return El;
}
function setupGlobalErrorTracking() {
	window.addEventListener("error", (event) => {
		captureClientEvent("javascript_error", {
			message: String(event.message ?? "unknown_error").slice(0, 200),
			source: event.filename,
			line: event.lineno
		});
	});
	window.addEventListener("unhandledrejection", (event) => {
		const reason = event.reason;
		captureClientEvent("javascript_error", {
			message: (reason instanceof Error ? reason.message : typeof reason === "string" ? reason : "unhandled_rejection").slice(0, 200),
			type: "unhandledrejection"
		});
	});
}
function captureClientEvent(event, properties) {
	const payload = {
		...getBaseEventProperties(),
		...properties
	};
	if (initialized) El.capture(event, payload);
}
//#endregion
export { captureClientEvent as a, LOGO_WORDMARK_PNG as i, BRAND_THEME_COLOR as n, initAnalyticsClient as o, EstimoLogo as r, BRAND_NAME as t };
