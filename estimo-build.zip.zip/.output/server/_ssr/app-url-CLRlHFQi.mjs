import { i as LOGO_WORDMARK_PNG } from "./client-DeQjJImR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-url-CLRlHFQi.js
/** URL publik aplikasi — set via VITE_APP_URL (mis. https://estimo.kodekoding.com). */
function getAppUrl() {
	const fromEnv = "https://estimo.kodekoding.com";
	if (fromEnv.trim().length > 0) return fromEnv.trim().replace(/\/$/, "");
	if (typeof window !== "undefined") return window.location.origin;
	return "";
}
var LOGO_EXPORT_FILE = LOGO_WORDMARK_PNG.replace(/^\//, "");
/** URL absolut logo wordmark PNG untuk ekspor kartu (html-to-image). */
function getLogoAssetUrl() {
	if (typeof window !== "undefined") return `${window.location.origin}/${LOGO_EXPORT_FILE}`;
	const appUrl = getAppUrl();
	return appUrl ? `${appUrl}/${LOGO_EXPORT_FILE}` : `/${LOGO_EXPORT_FILE}`;
}
/** URL absolut untuk metadata Open Graph / Twitter. */
function getOgImageUrl() {
	const appUrl = getAppUrl();
	if (appUrl) return `${appUrl}/${LOGO_EXPORT_FILE}`;
	return `/${LOGO_EXPORT_FILE}`;
}
//#endregion
export { getLogoAssetUrl as n, getOgImageUrl as r, getAppUrl as t };
